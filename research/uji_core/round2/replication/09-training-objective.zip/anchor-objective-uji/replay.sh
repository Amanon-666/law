#!/bin/sh
# Run from the directory containing law/ and data_raw/. All arguments required.
set -eu
if [ "$#" -ne 5 ]; then
    echo "Usage: sh replay.sh COMMIT G_SHA K_SHA COMMITTED_G_PATH COMMITTED_K_PATH" >&2
    exit 2
fi
commit=$1
gain_sha=$2
knn_sha=$3
gain_receipt=$4
knn_receipt=$5
out_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
results_root=${RESULTS_ROOT:-/tmp/uji-round2}
source_fit=${SOURCE_FIT:-$results_root/anchor-objective}
repo=${REPO:-law}
uji_data=${UJI_DATA:-data_raw/UJIndoorLoc}
old_results=${OLD_RESULTS:-$repo/research/uji_core/results}
field_refs=${PAIRED_MAP:-$results_root/paired-map}
orders=${FRESH_DRAWS:-$results_root/fresh-draws}
period_refs=${PERIOD_WKNN:-$results_root/period-wknn}
raw_phone=${FIXED_PHONE:-$results_root/decision-audit/fixed_wknn_phone.csv}
previous=${PREVIOUS_OBJECTIVE:-$results_root/anchor-transfer}
api_path=${ANCHOR_API:-research/uji_core/round2/route/anchor_trial/anchor_readout.py}
receipt_sha() {
    git -C "$repo" show "$commit:$1" | sha256sum | cut -d " " -f 1
}
test "$(git -C "$repo" rev-parse --verify "$commit^{commit}")" = "$commit"
test "$(receipt_sha "$gain_receipt")" = "$gain_sha"
test "$(receipt_sha "$knn_receipt")" = "$knn_sha"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python "$out_dir/score_uji.py" --repo "$repo" --data "$uji_data" --old "$old_results" \
    --fresh "$orders" --paired "$field_refs" --out "$out_dir" \
    --params "$source_fit/frozen.json" --params-sha "$gain_sha" \
    --knn-params "$source_fit/wknn_frozen.json" --knn-sha "$knn_sha" \
    --freeze-commit "$commit" --freeze-receipt "$gain_receipt"
python "$out_dir/verify.py" --repo "$repo" --data "$uji_data" --old "$old_results" \
    --fresh "$orders" --out "$out_dir" --period "$period_refs" --fixed-phone "$raw_phone" \
    --freeze-commit "$commit" --freeze-receipt "$gain_receipt" --api-path "$api_path"
python "$out_dir/compare_objectives.py" --out "$out_dir" --previous "$previous"
