"""Check the committed public readout and all archived old-draw WKNN arms."""
from pathlib import Path
import io, json, sys, subprocess, types, argparse
import numpy as np
import pandas as pd
from score_uji import manifests

IDX=['building','floor','draw','K']
def from_commit(repo, sha, path):
    return subprocess.check_output(['git','-C',str(repo),'show',sha+':'+path])
def verify(a):
    sys.path.insert(0,str(a.repo.resolve()))
    from research.uji_core.protocol import read_floors,position_weights
    from research.uji_core.smooth_scale import local_rows
    m=types.ModuleType('committed_anchor_readout');sys.modules[m.__name__]=m
    exec(compile(from_commit(a.repo,a.freeze_commit,a.api_path),'<committed API>','exec'),m.__dict__)
    params=json.loads(from_commit(a.repo,a.freeze_commit,a.freeze_receipt))
    tr=read_floors(a.data,'trainingData.csv');v=read_floors(a.data,'validationData.csv');ph=pd.read_csv(a.data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    d={(mode,g):pd.read_csv(a.out/f'{mode}_{g}.csv').set_index(IDX) for mode in ('official','phone') for g in ('old','new')}
    errors=[]; jobs,_=manifests(a)
    for j, orders in jobs:
        b,f,mode,device=j['building'],j['floor'],j['mode'],j['device']
        h=[];gaps=[]
        for (bb,ff),hh in sorted(tr.items()):
            if bb!=b or ff==f:continue
            ix=np.ones(len(hh['ids']),bool) if device is None else ph[hh['ids']]!=device
            if ix.any():
                h.append({k:v[ix] for k,v in hh.items()})
                gaps.append(abs(f-ff))
        t=tr[b,f];src=(t if mode=='phone' else v[b,f]);qi=local_rows(src,j['qids']);qw=position_weights(src['xy'][qi])
        for draw,group in [(0,'old'),(10,'new')]:
            for budget in (1,20):
                si=local_rows(t,orders[draw][:budget]);s={k:v[si] for k,v in t.items()};api=m.fit_anchor_readout(h,s,floor_gaps=gaps)
                for name,g in [('fixed0.0',0.),('fixed1.0',1.),('per_K',params['g_by_K'][str(budget)]),('scalar',params['g_scalar'])]:
                    xy=api.map_for(g).predict(src['rss'][qi]);risk=qw@np.linalg.norm(xy-src['xy'][qi],axis=1)
                    errors.append(abs(float(risk)-float(d[mode,group].loc[(b,f,draw,budget),name])))
    assert max(errors)<1e-8
    refs=['strong_wknn','old_same_map_wknn','same_forecast_map_wknn','library_same_forecast_wknn','library_raw_anchor_map_wknn','library_direct_wknn']
    bycell=[]
    for (mode,group),t in d.items():
        z=t[refs+['per_K']]
        if group=='old':
            for p in [a.period/f'period_wknn_{mode}.csv',a.old/'wknn_events.csv' if mode=='official' else a.fixed_phone]:
                orig=pd.read_csv(p).pivot(index=IDX,columns='method',values='mde').sort_index()
                assert z.index.equals(orig.index)
                z=z.join(orig,rsuffix='_dup')
        z=z.groupby(['building','floor','K']).mean().groupby(['building','K']).mean()
        model=z.pop('per_K')
        rr=z.idxmin(axis=1);err=model-z.min(axis=1)
        for (b,k),delta in err.items():bycell.append(dict(mode=mode,orders=group,building=b,K=k,per_K=model[b,k],reference=rr[b,k],best_MDE=z.min(axis=1)[b,k],delta=delta,number_WKNN=len(z.columns)))
    bd=pd.DataFrame(bycell);bd.to_csv(a.out/'all_archived_WKNN.csv',index=False)
    result=dict(sha=a.freeze_commit,public_api_comparisons=len(errors),public_api_max_abs_MDE_difference=float(max(errors)),scope='Per K, scalar, raw and full posterior across 13 floors x two UJI regimes x draw 0 or 10 x K=1 or 20. WKNN includes every archived direct method on initial 10, six prespecified controls on fresh 40.')
    (a.out/'committed_api_parity.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result);print(bd[bd.delta>0].to_string(index=False))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for x in ['repo','data','old','fresh','out','period','fixed-phone']:p.add_argument('--'+x,type=Path,required=True)
    p.add_argument('--freeze-commit',required=True)
    p.add_argument('--freeze-receipt',required=True)
    p.add_argument('--api-path',default='research/uji_core/round2/route/anchor_trial/anchor_readout.py')
    verify(p.parse_args())
