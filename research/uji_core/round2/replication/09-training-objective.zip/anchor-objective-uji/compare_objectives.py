"""Compare two source objectives without fitting on the target outcomes."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

KEYS = ['building', 'floor', 'draw', 'K']
BUDGETS = [1, 3, 5, 10, 20]


def compare(new_dir, previous_dir):
    macro_rows, cell_rows, diff_rows, checks, full_field = [], [], [], [], []
    for group, draws in [('old', range(10)), ('new', range(10, 50))]:
        n = len(draws)
        repeats = 5000 if group == 'old' else 10000
        rng = np.random.default_rng(20261101 if group == 'old' else 261101)
        if group == 'old':
            weights = rng.multinomial(n, np.ones(n)/n, size=(repeats, 13)).transpose(1, 0, 2) / n
        else:
            weights = np.stack([rng.multinomial(n, np.ones(n)/n, size=repeats)/n for _ in range(13)])
        for mode in ['official', 'phone']:
            file = f'{mode}_{group}.csv'
            now = pd.read_csv(new_dir/file).set_index(KEYS).sort_index()
            prev = pd.read_csv(previous_dir/file).set_index(KEYS).sort_index()
            assert now.index.equals(prev.index) and len(now) == 13*n*5
            fixed = [name for name in now if name.startswith('fixed')] + ['parent', 'strong_wknn', 'old_same_map_wknn']
            parity = np.max(np.abs(now[fixed].values-prev[fixed].values), axis=0)
            assert np.max(parity) < 1e-8
            checks.append(dict(mode=mode, draws=group, n=len(now), max_control_diff=parity.max()))
            for budget in BUDGETS:
                ties = now.xs(budget, level='K')
                delta = ties['per_K'] - ties['fixed1.0']
                assert (ties['scalar'] == ties['fixed1.0']).all()
                if budget >= 3:
                    assert (delta == 0.).all()
                xy = delta.to_numpy().reshape(13,n)
                raw = (weights @ xy[:, :, None])[:, :, 0]
                boot = np.stack([raw[:4].mean(0),raw[4:8].mean(0),raw[8:].mean(0)]).mean(0)
                lo,hi=np.quantile(boot,[.025,.975])
                full_field.append(dict(mode=mode,draw_set=group,K=budget,pairs=len(delta),exact_ties=int((delta==0).sum()),
                    per_K_minus_full=delta.groupby(level='building').mean().mean(), lo=lo, hi=hi,
                    max_abs_delta=delta.abs().max()))
            for name in ['per_K', 'scalar']:
                v = (now[name]-prev[name]).to_numpy().reshape(13, n, 5)
                sample_floor = weights @ v
                building = np.repeat(range(3), [4, 4, 5])
                sample = np.stack([sample_floor[building==i].mean(0) for i in range(3)])
                point = np.stack([v[building==i].mean((0,1)) for i in range(3)])
                interval = np.quantile(sample.mean((0,2)), [.025,.975])
                macro_rows.append(dict(mode=mode, draw_set=group, estimated=name,
                    mde_minus_forecast=point.mean(), lo=interval[0], hi=interval[1],
                    building_K_wins=(point < -1e-9).sum(), floor_K_wins=(v.mean(1) < -1e-9).sum(),
                    event_wins=(v < -1e-9).sum(), event_ties=(np.abs(v)<=1e-9).sum(), events=v.size))
                for i in range(3):
                    for k, budget in enumerate(BUDGETS):
                        lo,hi=np.quantile(sample[i,:,k], [.025,.975])
                        cell_rows.append(dict(mode=mode, draw_set=group, estimated=name, building=i, K=budget,
                                              mde_minus_forecast=point[i,k], lo=lo, hi=hi))
                delta=(now[name]-prev[name]).rename('mde_minus_forecast').reset_index()
                delta['mode'],delta['draw_set'],delta['estimated']=mode,group,name
                diff_rows.append(delta)
    pd.DataFrame(macro_rows).to_csv(new_dir/'objective_contrasts.csv',index=False)
    pd.DataFrame(cell_rows).to_csv(new_dir/'objective_building_K.csv',index=False)
    pd.concat(diff_rows,ignore_index=True).to_csv(new_dir/'objective_event_delta.csv',index=False)
    pd.DataFrame(full_field).to_csv(new_dir/'full_field_ties.csv',index=False)
    pd.DataFrame(checks).to_csv(new_dir/'common_control_parity.csv',index=False)
    table=pd.read_csv(new_dir/'building_K.csv')
    flat=pd.read_csv(new_dir/'contrasts.csv')
    arms=['per_K',*sorted(flat.reference.unique())]
    table.groupby(['mode','draw_set','K'])[arms].mean().to_csv(new_dir/'macro_K.csv')
    print(pd.DataFrame(macro_rows).round(5).to_string(index=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--previous', required=True, type=Path)
    args=parser.parse_args()
    compare(args.out,args.previous)
