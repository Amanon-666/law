# Does fitting the existing anchor blend on source location error help?

This frozen head-to-head changes the source fitting objective. The same seven early UJI Library visit pairs, same observed support scans, same map and same interpolation formula serve both objectives. The spatial objective uses four source query coordinates outside the entire nested set of 20 supports, with 48 future-visit scans per event. Its fitted posterior fractions are .942835 at K=1 and 1 at the four larger budgets. The pooled coefficient is 1.

## Replay

Run from the parent of the law checkout and data_raw. The exact source and scored UJI inputs can be overridden with the environment variables in replay.sh. The command checks that the Git receipt and both checksums match before running the scorer:

```sh
sh /tmp/uji-round2/anchor-objective-uji/replay.sh \
  2b42968a634774c6c50df9c7ed209d5335ceb9c6 \
  01016b76f1beeed6116c3ba5b432063d3f56ef6bc615dfa0a1598e67321df5ed \
  2a4a60d30b4fbb491849efd45f5af2081ed09a838db3dd8d61433908ecdaab1c \
  research/uji_core/round2/route/anchor_trial/spatial/frozen.json \
  research/uji_core/round2/route/anchor_trial/spatial/wknn_frozen.json
```

## Evidence

- At K≥3 the spatially trained rule and fixed full-field anchor agree in all 5,200 paired test events. The pooled scalar also agrees exactly with the full field in all 6,500 events. The remaining K=1 effect is negligible on 40 additional support draws in both official and phone settings.
- Versus the earlier fingerprint-forecast objective, the spatial objective changes mean error by −0.0122 U on the official additional draws and +0.0076 U on held-phone additional draws. Every building-level budget step improves. WKNN wins two held-phone building×budget cells both on initial and extra draws. The learning rule fails to outperform fixed .75 in both extra-draw regimes.
- The original and additional draws share query coordinates and RSS. Intervals condition on those queries and represent nested support-order resampling.

See summary.json and contrasts.csv for A/B/C and all matched controls, objective_contrasts.csv for signed comparisons between training objectives, full_field_ties.csv for checks for every K, and all_archived_WKNN.csv for the strongest available WKNN in every building×K cell. Source fractions were locked before scoring. The earlier score directory is read-only to this replay.
