"""Report every frozen arm on every available site/floor. No refitting."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

def main(out):
    ev=pd.concat([pd.read_csv(out/f'{d}_gate_events.csv') for d in ('tau','sod')],ignore_index=True)
    contrasts=pd.concat([pd.read_csv(out/f'{d}_contrasts.csv') for d in ('tau','sod')],ignore_index=True)
    wid=ev.pivot(index=['site','floor','seed','K'],columns='method',values='mde')
    assert len(wid)==300 and wid.notna().all().all()
    assert np.max(abs(wid.source_fixed-wid.fixed_gap2))<1e-10
    assert np.max(abs(wid['fixed0.0']-wid.fixed_gap2))<1e-10
    floor=wid.groupby(level=['site','floor','K']).mean()
    site=floor.groupby(level=['site','K']).mean()
    fixed=['fixed0.0','fixed0.25','fixed0.5','fixed0.75','fixed1.0','fixed_rising','fixed_falling']
    entries=[]
    for name,c in site.groupby(level='site'):
        c=c.droplevel('site')
        strongest=c[fixed].mean().idxmin()
        z=contrasts[(contrasts.site==name)&(contrasts.K=='mean_K')].set_index('comparator')
        nfloor=len(floor.loc[name].index.unique('floor'))
        perf=c.mean().to_dict()
        fields=dict(site=name,target_floors=nfloor,eligibility='mean over ten draws and available target floors, meters',
                    budgets=list(c.index),gate_curve=c.conditional_gate.tolist(),parent_curve=c.fixed_gap2.tolist(),
                    scalar_curve=c.tied_scalar.tolist(),period_WKNN_curve=c.period_floor_wknn.tolist(),
                    strongest_fixed=strongest,strongest_fixed_curve=c[strongest].tolist(),means_m=perf,
                    strict_K_decreases=int(np.sum(np.diff(c.conditional_gate)<0)))
        held=floor.loc[name]
        deltas={}
        for comparator in ['fixed_gap2',strongest,'tied_scalar','strong_wknn','floor_wknn','period_floor_wknn','same_map_wknn']:
            d=c.conditional_gate-c[comparator]
            deltas[comparator]=dict(mean=float(d.mean()),pointwise_wins=int((d< -1e-9).sum()),
                                    paired_floor_K_wins=int((held.conditional_gate-held[comparator]< -1e-9).sum()),
                                    conditional_95=[float(z.loc[comparator,'mc95_lo']),float(z.loc[comparator,'mc95_hi'])])
        fields['contrasts']=deltas;entries.append(fields)
    fixed_oracle=site[fixed].min(axis=1)
    short=site[['conditional_gate','fixed_gap2','tied_scalar','source_fixed','strong_wknn','floor_wknn','period_floor_wknn','same_map_wknn']].copy()
    short['best_fixed_in_cell']=site[fixed].idxmin(axis=1)
    short['best_fixed_value']=fixed_oracle
    short['gate_minus_best_fixed_in_cell']=site.conditional_gate-fixed_oracle
    short['gate_minus_scalar']=site.conditional_gate-site.tied_scalar
    short['gate_minus_strongest_wknn']=site.conditional_gate-site[['strong_wknn','floor_wknn','period_floor_wknn','same_map_wknn']].min(axis=1)
    short.to_csv(out/'site_results.csv');site.to_csv(out/'site_all_arms.csv');floor.to_csv(out/'floor_all_arms.csv')
    contrasts.to_csv(out/'contrasts_all.csv',index=False)
    report=dict(permanent_freeze_commit='0eb447c261f29834de6218c8282d1a5c2c22e7ff',
       consumed=True,scope='Once-only prospective evaluation of one all-UJI calibrated model. All three sites now consumed by this comparison; future fitting against these outcomes is exploratory.',
       n_events=len(wid),sites=entries,
       coverage='TIE1 tests F0 only (50 distinct Q). SAH1 tests F1/F2 (96 and 60 Q). CETC331 tests F1/F2/F3 (280/320/240 scans, 28/32/24 positions). S/H training records at CETC331 are means of 30 scans; Finnish records are individual survey fingerprints.',
       interval_scope='Paired resampling of entire 10-draw K curves within each fixed floor; no population inference over buildings or people. Min fixed per cell or per site is descriptive, not a deployable rule. No reporting-driven change to any fit.')
    (out/'challenge_summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(short.round(3).to_string())
    for r in entries:print(r['site'],r['strict_K_decreases'],r['strongest_fixed'],r['contrasts'])

if __name__=='__main__':main(Path(__file__).resolve().parent)
