"""HCXY/SYL publisher compression audit. Development, previously studied sites.

No fitting or new validation model. Change only the representation of H on the
same H coordinates; the same measured single scans provide S and Q in both arms.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import random

import numpy as np
import pandas as pd

from residual_probe.episode_rows import nested_rows
from ..protocol import BUDGETS, SEEDS, position_weights
from ..round2.conditional_map import BAND_EDGES, EXTERNAL_GATE, fit_conditional_map, historical_moments
from .external import METRES_PER_UJI_UNIT as UNIT


XY = ['ECoord','NCoord']


def cross_bands(raw, compressed):
    a = np.searchsorted(BAND_EDGES, raw, side='right')
    b = np.searchsorted(BAND_EDGES, compressed, side='right')
    transitions = np.bincount((3*a+b).ravel(), minlength=9).reshape(3,3)
    return dict(n_ap_times_positions=int(a.size),mean_raw=float(raw.mean()),
        mean_avg=float(compressed.mean()),mae=float(np.mean(np.abs(raw-compressed))),
        fraction_any_band_change=float(np.mean(a!=b)),
        fraction_toggle_middle=float(np.mean((a==1)!=(b==1))),
        raw_fraction_middle=float(np.mean(a==1)),avg_fraction_middle=float(np.mean(b==1)),
        matrix_raw_rows_avg_columns=transitions.tolist())


def numerical_recipe(raw, avg, macs):
    group = [raw[k] for k in XY]
    by_xy = raw.groupby(XY)
    av = avg.set_index(XY).sort_index()
    if not np.all(by_xy.size()==30) or not np.all(avg.groupby(XY).size()==1) or not av.index.equals(by_xy.size().index):
        raise ValueError('Raw/Avg reference locations or repeats do not align')
    if set(raw.SampleTimes.unique())!=set(range(1,31)) or not np.all(by_xy.SampleTimes.nunique()==30):
        raise ValueError('Raw repeat IDs inconsistent')
    r=raw[macs]; n=r.ne(100).groupby(group).sum().to_numpy()
    summ=r.replace(100,-105).groupby(group).sum().to_numpy()
    # For the released negative numbers, use integer half away from zero.
    computed=-((-summ+15)//30)
    obs=av[macs].to_numpy()
    np.testing.assert_array_equal(computed,obs)
    if np.any(obs==100) or np.any(r.to_numpy()==-105):
        raise ValueError('Unexpected representation')
    overlap = {int(level):sorted({int(x) for x in n[obs==level]}) for level in np.unique(obs)}
    partial=(n>0)&(n<30)
    duplicate_levels={k:v for k,v in overlap.items() if len(v)>1}
    return dict(n_mac=int(len(macs)),n_sites=int(len(av)),n_ap_xy=int(n.size),raw_rows=len(raw),avg_rows=len(avg),
        raw_detected_RSS_range=[int(r.mask(r==100).min().min()),int(r.mask(r==100).max().max())],
        allmiss=int((n==0).sum()),partial=int(partial.sum()),always=int((n==30).sum()),
        round_filled_105_max_abs_error=int(np.max(abs(computed-obs))),
        avg_contains_positive_100=int((obs==100).sum()),one_or_more_detections_hidden_by_rounding=int(((n>0)&(obs==-105)).sum()),
        completely_missing_yet_not_minus_105=int(((n==0)&(obs!=-105)).sum()),
        count_ambiguous_observed_rss_levels=len(duplicate_levels),
        empirical_counts_for_averaged_minus95=overlap.get(-95,[]),
        unsmoothed_site_frequency=cross_bands(n/30.,(obs!=-105).astype(float)),
        raw_detection_count_histogram={int(k):int(v) for k,v in sorted(Counter(n.ravel()).items())})


def select(frame, points):
    return frame.loc[[tuple(p) in points for p in frame[XY].to_numpy()]]


def sample(frame, macs, author_avg=False):
    r=frame[macs].to_numpy(np.int16)
    if author_avg:
        r=np.where(r==-105,100,r)
    return dict(rss=r,xy=frame[XY].to_numpy(float))


def run(directory,out):
    out.mkdir(parents=True,exist_ok=True)
    report=dict(source_commit='bfe8f63f55957cc25b23ba91c408ae345a3fb0b7',doi='10.1186/s43020-022-00086-y',
        scope='Development diagnostics on two previously examined single-floor buildings. The official testing table supplies Q, equal weighting by its coordinates; any coincident training positions are excluded from both H and S. In each site choose one fixed seeded 1/5 pool of grid points for S, the rest for H. The same 10 nested R=1 draws and all five budgets for both H representations. H and S come from the same training survey (location holdout), not different floors or a prospective new survey.',
        encoding='Raw +100 denotes missing. Published one-row Avg exactly equals round-half-away-from-zero(mean(raw with missing mapped to -105)). Feed the compressed inputs back to the model as: -105 -> 100 (no recoverable evidence); any other integer retained as published (an imputed unconditional mean, not the conditional detected mean). No attempt to recreate lost repeated scans.',
        inferred_p='For raw H a local AP frequency n/30 enters the current half10 historical smoother. For decoded Avg H the same method begins with 1[Avg>-105]. A literal +100-only reader applied to these published negative-only Avg tables would produce p=1 everywhere, high-band only, zero conditional-mean correction.',
        bands=list(BAND_EDGES),gate=list(EXTERNAL_GATE),coords_units_per_uji=UNIT,
        choices='All inputs, R=1 S/Q, H split, coordinate conversion, fixed 10/0.5+40/1 field, threshold and observation scale, deployment coefficients, and evaluation weights shared. Only H representation (30 scans vs 1 published Avg per identical XY) differs.',
        sites={})
    scores=[]
    for site in ('HCXY','SYL'):
        d=directory/site
        files=[d/f'Training_{site}_AP_30.csv',d/f'Training_{site}_AP_Avg.csv',d/f'Testing_{site}_AP.csv']
        raw,avg,q=(pd.read_csv(f) for f in files)
        macs=[c for c in raw if c.startswith('MAC')]
        if any([c for c in v if c.startswith('MAC')]!=macs for v in (avg,q)):
            raise ValueError('AP axes differ')
        audit=numerical_recipe(raw,avg,macs);report['sites'][site]=audit
        audit['hashes']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
        train_xy=set(map(tuple,raw[XY].to_numpy())); qxy=set(map(tuple,q[XY].to_numpy()))
        pool=sorted(train_xy-qxy)
        random.Random('sod-history-compression-v1/'+site+'/split').shuffle(pool)
        p=len(pool)//5
        sp=set(pool[:p]); hp=set(pool[p:])
        raw_h=sample(select(raw,hp),macs); avg_h=sample(select(avg,hp),macs,True)
        support=select(raw,sp); s=sample(support,macs); query=sample(q,macs)
        if hp&sp or hp&qxy or sp&qxy:raise ValueError('History, support and queries must occupy disjoint XY')
        active=(raw_h['rss']!=100).any(0)|(avg_h['rss']!=100).any(0)
        floors=np.unique(np.r_[raw.FloorID,avg.FloorID,q.FloorID])
        if len(floors)!=1:raise ValueError('Expected a single floor')
        history={'raw30':raw_h,'author_avg':avg_h}
        moments={}
        for name,h in history.items():
            _,xy,ph,_=historical_moments([dict(rss=h['rss'],xy=h['xy']/UNIT)],None)
            moments[name]=(xy,ph)
        np.testing.assert_array_equal(moments['raw30'][0],moments['author_avg'][0])
        audit.update(floor=int(floors[0]),n_history_XY=len(hp),n_support_pool_XY=len(sp),
            n_query_XY=len(qxy),n_query_scans=len(q),dropped_train_XY_overlaps=len(train_xy&qxy),
            inactive_history_aps=int((~active).sum()),history_smoothed=cross_bands(moments['raw30'][1][:,active],moments['author_avg'][1][:,active]),
            history_xy=sorted(hp),support_pool_xy=sorted(sp),support_draws=[])
        w=position_weights(query['xy'])
        for seed in SEEDS:
            order=nested_rows(s['xy'],range(len(s['xy'])),BUDGETS,0,f'sod-history-compression-v1/{site}/S/{seed}')['support_rows'][20]
            audit['support_draws'].append(dict(seed=seed,raw_csv_rows=support.index[order].tolist()))
            for k in BUDGETS:
                chosen={col:v[order[:k]] for col,v in s.items()}
                for name,h in history.items():
                    model=fit_conditional_map([h],chosen,coordinate_units_per_uji=UNIT)
                    base=model.base.predict(query['rss']);pred=model.predict(query['rss'])
                    if seed==0 and k in (1,20):
                        np.testing.assert_allclose(base,model.predict(query['rss'],(0.,0.,0.)),rtol=0.,atol=1e-8)
                    fixed=float(w@np.linalg.norm(base-query['xy'],axis=1))
                    gate=float(w@np.linalg.norm(pred-query['xy'],axis=1))
                    scores.append(dict(site=site,seed=seed,K=k,history=name,parent=fixed,gate=gate,gate_minus_parent=gate-fixed))
    frame=pd.DataFrame(scores)
    if len(frame)!=200 or not np.isfinite(frame[['gate','parent']].to_numpy()).all():
        raise ValueError('Incomplete comparison')
    frame.to_csv(out/'events.csv',index=False)
    vals=['parent','gate','gate_minus_parent']
    frame.groupby(['site','history','K'])[vals].mean().to_csv(out/'by_K.csv')
    summary=frame.groupby(['site','history'])[vals].mean()
    summary.to_csv(out/'summary.csv')
    evidence=[]
    for site,t in report['sites'].items():
        hist=t['history_smoothed']
        dr=summary.loc[(site,'raw30'),'gate_minus_parent']
        da=summary.loc[(site,'author_avg'),'gate_minus_parent']
        evidence.append(dict(site=site,matched_ap_xy=t['n_ap_xy'],raw_repeat_count=30,
            reproduction_max_dB=t['round_filled_105_max_abs_error'],
            h_p_raw=hist['mean_raw'],h_p_avg=hist['mean_avg'],
            h_switch_any_band_pct=100*hist['fraction_any_band_change'],
            h_toggle_active_gate_pct=100*hist['fraction_toggle_middle'],
            h_active_raw_pct=100*hist['raw_fraction_middle'],h_active_avg_pct=100*hist['avg_fraction_middle'],
            gate_minus_parent_raw_m=dr,gate_minus_parent_avg_m=da,compression_change_m=da-dr))
    pd.DataFrame(evidence).to_csv(out/'evidence.csv',index=False)
    (out/'provenance.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(summary.round(5).to_string(),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('data',type=Path);p.add_argument('out',type=Path);a=p.parse_args()
    run(a.data,a.out)
