"""Data expansion only: refit the same learned RSS matching table with UAH/CAR."""
import argparse
import json
from pathlib import Path
from collections import defaultdict
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from refi import fit_map
from .additional_sources import episodes
from .learned_match import data_stream, design_matrix, error, parameter_map, N
from .transport import source_design
from ..protocol import read_floors,position_weights


def extra_rows(prepared):
    rows=[]
    for m,h,s,q in episodes(prepared):
        gap=[abs(f-m['floor']) for f in m['history_floors']]
        model=fit_map(h,s,floor_gaps=gap)
        x=design_matrix(model.prototypes,q['rss'][:,model.visible])
        site={'UAH':3,'CAR':4}[m['site']]
        label=(site,m['floor'],2,0,m['draw'],m['K'])
        rows.append((label,(x,model.xy-model.xy[0],q['xy']-model.xy[0],position_weights(q['xy']))))
    return rows


def estimate(rows,kind,reg):
    # Existing relative weighting, with each physical building equally weighted
    # irrespective of its number of eligible source protocols or draws.
    ix=pd.DataFrame([s for s,e in rows],columns=['b','f','reg','dev','draw','K'])
    weights=np.ones(len(ix));groups=[]
    for c in ('b','reg','f','dev','draw','K'):
        weights/=ix.groupby(groups)[c].transform('nunique').values if groups else ix[c].nunique()
        groups.append(c)
    matrix=parameter_map(kind);prior=np.zeros(N);prior[0]=1.
    def calc(t):
        a=matrix@t;v=0.;g=np.zeros(N)
        for w,(_,ep) in zip(weights,rows):
            l,grad=error(ep,a,True);v+=w*l;g+=w*grad
        d=a-prior
        return v+reg*(d@d),matrix.T@(g+2*reg*d)
    start=np.zeros(matrix.shape[1]);start[0]=1.
    r=minimize(calc,start,jac=True,method='L-BFGS-B',bounds=[(.4,2.)]+[(-1.5,1.5)]*(len(start)-1),options=dict(maxiter=75,ftol=2e-8,gtol=1e-5))
    if not r.success:raise RuntimeError(str(r.message))
    return (matrix@r.x).tolist()


def main(data,design,prepared,out):
    out.mkdir(exist_ok=True,parents=True)
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    js=[dict(building=b,floor=f) for b,f in tr]
    rows=list(data_stream(tr,va,phone,js,True,True))+list(data_stream(tr,va,phone,source_design(tr,phone),False,True))
    other=extra_rows(prepared)
    fits={}
    for held in (0,1,2,'external'):
        old=[r for r in rows if r[0][0]!=held]
        conf={'identity':[1.]+[0.]*(N-1)}
        for train_name,subset in [('original',old),('expanded',old+other)]:
            for kind in ('temperature','detection','full'):
                conf[train_name+'_'+kind]=estimate(subset,kind,.1)
        fits[str(held)]=conf
    fp=out/'fit.json';fp.write_text(json.dumps(dict(configs=fits,independent_added_sites=['CAR','UAH'],events=len(other)),indent=2)+'\n')
    fits=json.loads(fp.read_text())['configs'];del rows
    for name,period,src in [('official',True,js),('phone',False,json.loads(design.read_text())['events'])]:
        rec=[]
        for (b,f,_,_,d,k),ep in data_stream(tr,va,phone,src,period,False):
            for arm,v in fits[str(b)].items():
                rec.append((b,f,d,k,arm,error(ep,np.asarray(v))))
        pd.DataFrame(rec,columns=['building','floor','draw','K','method','mde']).to_csv(out/(name+'.csv'),index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','design','prepared','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.design,a.prepared,a.out)
