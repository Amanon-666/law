"""Half-smoothed history means and empirical variance from the same mixture.

A historical component is a real scan drawn uniformly within a source floor
and XY. Floor-level prototypes at the same XY have equal weight. The half10
spatial smoother gives the last mixture. These are variances of filled RSS;
after S calibration they are used as effective scoring variances, not full
Bayesian posterior variances. S changes the mean map only.
"""
from dataclasses import dataclass
import numpy as np
from scipy.special import log_ndtr, softmax
from external_baselines import tpm_adapter as tpm
from refi import smooth_history, _scans

SIGMAS=(12.,6.,9.,15.,18.)
GAINS=(0.,.25,1.,2.)


@dataclass
class Field:
    prototypes: np.ndarray
    xy: np.ndarray
    visible: np.ndarray
    within: np.ndarray
    between: np.ndarray
    detection_probability: np.ndarray

    def statistics(self,law):
        if law=='local':
            return self.within,self.between
        if law=='AP_mean':
            return self.within.mean(0,keepdims=True),self.between.mean(0,keepdims=True)
        if law=='shuffled':
            # Apply the same index to both components within an AP. Every H
            # candidate and real S candidate participates; the variance
            # histogram and component association are exactly preserved.
            ids=np.flatnonzero(self.visible)
            columns=[]
            for ap in ids:
                permutation=np.random.default_rng(611780+int(ap)).permutation(len(self.xy))
                index=np.empty_like(permutation)
                index[permutation]=np.roll(permutation,1)
                columns.append(index)
            ix=np.column_stack(columns) if columns else np.empty(self.prototypes.shape,dtype=int)
            return np.take_along_axis(self.within,ix,axis=0),np.take_along_axis(self.between,ix,axis=0)
        raise ValueError('Unknown variance control')

    def predict(self, q, coeff, law='local'):
        q=np.asarray(q,dtype=float)
        if q.ndim!=2 or q.shape[1]!=len(self.visible) or not np.isfinite(q).all():
            raise ValueError('Expected finite aligned query RSS')
        terms=QueryTerms(q[:,self.visible])
        v=variance(*self.statistics(law),coeff)
        p=softmax(terms.scores(self.prototypes,v),axis=1)
        return p@(self.xy-self.xy[0])+self.xy[0]


def variance(w,b,coeff):
    s,u,v=coeff
    if s<=0 or min(u,v)<0 or not np.isfinite(coeff).all():
        raise ValueError('Scoring floor must be positive and component scales nonnegative')
    return s*s + u*w + v*b


class QueryTerms:
    def __init__(self,rss):
        seen=rss!=100
        self.detected=seen.astype(float)
        self.missing=(~seen).astype(float)
        # Centered for the Gaussian expansion; does not change any distance.
        self.r=np.where(seen,rss+75.,0.)
        self.r2=self.r**2

    def scores(self,m,var):
        p=m+75.
        iv=1./var
        # Includes the normalization term. Only the universal log(2π) is dropped.
        a=-.5*self.r2 @ np.broadcast_to(iv,m.shape).T
        a+=self.r @ (p*iv).T
        a-=.5*self.detected @ (p*p*iv + np.log(var)).T
        a+=self.missing @ log_ndtr((-85.-m)*np.sqrt(iv)).T
        return a


class VarianceBank:
    def __init__(self,histories,unit=1.):
        hs=[h for h in histories if len(h['rss'])]
        if not hs or unit<=0 or not np.isfinite(unit):
            raise ValueError('Need historical scans and a positive spatial conversion')
        axis=np.asarray(hs[0]['rss'])
        if axis.ndim!=2:
            raise ValueError('Expected 2D fingerprint scans')
        hs=[_scans(h,axis.shape[1]) for h in hs]
        self.unit=unit
        self.active=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
        maps=[];coords=[]
        for h in hs:
            y=tpm.dbm(h['rss'])
            z,loc=tpm.position_map(np.column_stack((y,y*y,h['rss']!=100)),h['xy'])
            mean,second,rate=np.hsplit(z,3)
            # Finite empirical distribution; singleton histories contribute zero
            # observed within-cell variance rather than an invented repeat.
            within=np.maximum(second-mean*mean,0.)
            maps.append(np.column_stack((mean,within,mean*mean,rate)))
            coords.append(loc)
        pooled=tpm.position_map(np.vstack(maps),np.vstack(coords))
        values,self.xy=smooth_history(pooled,10.*unit,.5)
        self.mean,self.within,mean2,self.rate=np.hsplit(values,4)
        self.between=np.maximum(mean2-self.mean*self.mean,0.)

    def condition(self,support):
        raw=np.asarray(support['rss'])
        xy=np.asarray(support['xy'],dtype=float)
        if raw.ndim!=2 or raw.shape[1]!=len(self.active) or xy.shape!=(len(raw),2):
            raise ValueError('Expected aligned support RSS and XY')
        if not np.isfinite(raw).all() or not np.isfinite(xy).all():
            raise ValueError('Nonfinite support')
        active=self.active|(raw!=100).any(0)
        m,locations=tpm.calibrate((self.mean[:,active],self.xy),dict(rss=raw[:,active],xy=xy),(40.*self.unit,1.))
        w,b,p=self.within[:,active],self.between[:,active],self.rate[:,active]
        if len(raw):
            sxy=np.unique(xy,axis=0)
            if not np.array_equal(sxy,locations[len(self.xy):]):
                raise ValueError('Anchor coordinate mismatch')
            feature=tpm.lookup(sxy,self.xy,np.column_stack((w,b,p)))
            sw,sb,sp=np.hsplit(feature,3)
            w,b,p=np.vstack((w,sw)),np.vstack((b,sb)),np.vstack((p,sp))
        return Field(m,locations,active,w,b,p)
