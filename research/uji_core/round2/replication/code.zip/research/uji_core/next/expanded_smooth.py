"""Same source-trained history smoother, comparing only the known source corpus.

Train: python -m research.uji_core.next.expanded_smooth fit UJI IPIN FROZEN OUT
Test:  python -m research.uji_core.next.expanded_smooth evaluate UJI IPIN FROZEN OUT
Optional --early-library ARCHIVE adds a separately labelled sensitivity. All
deployment parameters are frozen by fit before evaluate scores the UJI folds.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
import multiprocessing as mp
from pathlib import Path

import numpy as np
import pandas as pd

from . import additional_sources as ipin
from . import longitudinal as lib
from . import history_smooth_study as original
from .history_smooth import HistorySmoother,NAMES
from .transport import source_design
from ..protocol import BUDGETS, read_floors, position_weights
from ..summarize import INDEX
from .variance_pool_audit import summary

EXTRA={}
HEADS=('scalar','full')
RECIPES={'uji':(), 'ipin':('UAH','CAR'), 'early_library':('UAH','CAR','LIB_early')}


def select_query(q,key):
    # One true acquisition at each of at most 24 distinct XY locations.
    xy,group=np.unique(q['xy'],axis=0,return_inverse=True)
    rng=np.random.default_rng(int.from_bytes(hashlib.sha256(key.encode()).digest()[:8],'little'))
    chosen=rng.choice(len(xy),min(24,len(xy)),replace=False)
    qi=np.array([rng.choice(np.flatnonzero(group.ravel()==i)) for i in chosen])
    return {k:q[k][qi] for k in ('rss','xy','ids')}


def pack(meta,hs,gaps,s,q):
    bank=HistorySmoother(hs,gaps)
    # K20 identifies all retained columns for STORAGE, the reused inner case
    # builder recalculates H union CURRENT S for scoring each lower K.
    columns=bank.hseen|(s['rss']!=100).any(0)
    q=select_query(q,'expanded-smooth-v1/'+str(meta))
    cases=[original.prepare_case(bank,s,np.arange(k),q,columns) for k in original.SOURCE_K]
    record=dict(site=meta[0],floor=meta[1],episode=list(meta),H_scans=[len(h['rss']) for h in hs],
                H_xy=[len(np.unique(h['xy'],axis=0)) for h in hs],H_id_sha256=[
                    hashlib.sha256(json.dumps(h['ids'].tolist()).encode()).hexdigest() for h in hs],
                gaps=list(gaps),support_order=s['ids'].tolist(),query_ids=q['ids'].tolist(),
                permitted_APs_by_K=[int(c.mask.sum()) for c in cases])
    data=(bank.raw[:,columns].copy(),bank.contrast[:,columns].copy(),bank.features[:,columns].copy(),cases)
    return (meta,data),record


def prepare_extra(directory,library):
    records=[];sites={'UAH':[],'CAR':[]}
    for m,hs,s,q in ipin.episodes(directory,draws=5):
        if m['K']!=max(BUDGETS):continue
        site=m['site']
        key=(site,m['floor'],m['query_route'],m['query_phone'],m['draw'])
        gaps=[abs(f-m['floor']) for f in m['history_floors']] if site=='UAH' else [0]*len(hs)
        gr,entry=pack(key,hs,gaps,s,q)
        entry['seconds_Q_after_latest_S']=m['delta_seconds']
        sites[site].append(gr);records.append(entry)
    if len(sites['UAH'])!=5 or len(sites['CAR'])!=5:raise ValueError('Incomplete IPIN training draws')
    if library is not None:
        sites['LIB_early']=[]
        for m,h,s,q in lib.episodes(library,'source',seeds=(0,1)):
            if m['K']!=max(BUDGETS):continue
            if m['month']>7 or m['query_stream']!='trn':raise ValueError('Reserved library campaign')
            key=('LIB_early',m['floor'],m['month'],m['draw'])
            # Library native coordinates are already metric; IPIN is preconverted.
            scale=ipin.METRES_PER_UJI_UNIT
            def normalized(scans):
                return dict(scans,xy=scans['xy']/scale)
            gr,entry=pack(key,[normalized(h)],[0],normalized(s),normalized(q))
            sites['LIB_early'].append(gr);records.append(entry)
        if len(sites['LIB_early'])!=20:raise ValueError('Incomplete early training draws')
    return sites,records


def hierarchy(held,recipe):
    eligible=original.groups_for(held)
    n_uji=len({key[1] for _,(key,_) in eligible})
    sites=RECIPES[recipe]
    total=n_uji+len(sites)
    weighted=[(w*n_uji/total,g) for w,g in eligible]
    for name in sites:
        groups=EXTRA[name]
        floors={k[1] for k,d in groups}
        per_floor={f:sum(k[1]==f for k,d in groups) for f in floors}
        weighted.extend((1/(total*len(floors)*per_floor[k[1]]),(k,d)) for k,d in groups)
    np.testing.assert_allclose(sum(w for w,g in weighted),1.,rtol=0.,atol=1e-12)
    if held!='external' and any(k[1]==held for w,(k,d) in eligible):
        raise ValueError('Held building included')
    return weighted


def fit_one(job):
    held,recipe,head=job
    groups=hierarchy(held,recipe)
    r=original.fit_groups(groups,head)
    r['source_events']=sum(len(g[-1]) for w,(k,g) in groups)
    print(f"fit {held} {recipe} {head}: {r['iterations']} steps",flush=True)
    return str(held),recipe,head,r


def load_uji(directory):
    tr=read_floors(directory,'trainingData.csv');va=read_floors(directory,'validationData.csv')
    ph=pd.read_csv(directory/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    return tr,va,ph


def fit(args):
    tr,va,ph=load_uji(args.uji)
    original.GROUPS.clear()
    for reg,jobs in [('period',[dict(building=b,floor=f) for b,f in tr]),('device',source_design(tr,ph))]:
        original.GROUPS.extend(original.data_group(tr,va,ph,j,reg) for j in jobs)
    extra,records=prepare_extra(args.ipin,args.early_library)
    EXTRA.clear();EXTRA.update(extra)
    recipes=['uji','ipin']+(['early_library'] if args.early_library else [])
    (args.out/'extra_source_rows.json').write_text(json.dumps(records,allow_nan=False)+'\n')
    keys=[(held,name,h) for held in (0,1,2,'external') for name in recipes for h in HEADS]
    with ProcessPoolExecutor(max_workers=args.workers,mp_context=mp.get_context('fork')) as pool:
        solutions=list(pool.map(fit_one,keys))
    folds={}
    for b,r,h,v in solutions:folds.setdefault(b,{}).setdefault(r,{})[h]=v
    diff=None
    if args.previous:
        previous=json.loads((args.previous/'fit.json').read_text())['folds']
        diff=max(np.max(abs(np.asarray(v['uji'][h]['theta'])-previous[b]['fits'][h]['theta']))
                 for b,v in folds.items() for h in HEADS)
        if diff>1e-8:raise ValueError(f'Original source optimization changed: {diff}')
    output=dict(folds=folds,recipes={k:RECIPES[k] for k in recipes},features=NAMES,
         unchanged_optimization=dict(penalty=original.PENALTY,K=original.SOURCE_K,bounds=[-3,3],start='zero',
             model='raw gap2 per-XY map + sigmoid(theta·Hfeatures)*(10U gap-weighted neighbor mean minus raw). Recondition S with original 40U/ridge1 and differentiate UJI-unit MDE through complete readout.'),
         weighting='Every eligible physical site has equal weight. UJI within-site keeps the original equal regime/floor/phone/draw/K/Q protocol. Each new site uses equal floors, then prepared episodes, K and Q positions. LIB_early is a separately weighted same-campus campaign-source sensitivity; not claimed geographically independent.',
         prevented_leakage='Each LOBO fold excludes all target-building source groups including later labels. Only actual K visible APs scored. Extra IPIN publisher training logs only. Optional library uses training months 1..7 only. No later library, TAU, SOD or independent challenge result is computed by this job.',
         UJI_source_groups=len(original.GROUPS),extra_source_groups={s:len(v) for s,v in EXTRA.items()},
         previous_UJI_max_parameter_difference=diff,IPIN_input_sha=ipin.SHA,
         early_library_input_sha=lib.SHA256 if args.early_library else None,
         source_fit_code_sha256={Path(p).name:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in
             [__file__,original.__file__,ipin.__file__,Path(__file__).with_name('history_smooth.py')]})
    (args.out/'fit.json').write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')


def evaluate(args):
    frozen=json.loads((args.out/'fit.json').read_text())
    folds=frozen['folds'];tr,va,ph=load_uji(args.uji)
    fs=[dict(building=b,floor=f) for b,f in tr]
    tiers=[]
    for mode,reg,jobs in [('official','period',fs),('phone','device',
            json.loads((args.frozen/'device_stress_design.json').read_text())['events'])]:
        rows=[]
        for job in jobs:
            b,f=job['building'],job['floor']
            bank,t,q,orders=original.task_data(tr,va,ph,job,reg,False)
            models=folds[str(b)]
            prior={r+'_'+h:bank.prior(m[h]['theta']) for r,m in models.items() for h in HEADS}
            prior['fixed75']=bank.raw+.75*bank.contrast
            prior['fixed50']=bank.raw+.5*bank.contrast
            prior['ipin_shuffled']=bank.prior(models['ipin']['full']['theta'],'shuffled')
            prior['ipin_APmean']=bank.prior(models['ipin']['full']['theta'],'AP_mean')
            for draw,order in enumerate(orders):
                for k in BUDGETS:
                    sr=order[:k]
                    case=original.prepare_case(bank,t,sr,q,np.ones_like(bank.hseen))
                    rec=dict(building=b,floor=f,draw=draw,K=k)
                    rec.update({name:original.evaluate_prior(p,case,False) for name,p in prior.items()})
                    if draw==0 and k==5:
                        model=bank.condition(dict(rss=t['rss'][sr],xy=t['xy'][sr]),models['ipin']['full']['theta'])
                        np.testing.assert_allclose(rec['ipin_full'],case.weight@np.linalg.norm(
                            model.predict(q['rss'])-q['xy'],axis=1),atol=1e-8,rtol=0.)
                    rows.append(rec)
        d=pd.DataFrame(rows)
        if len(d)!=650 or not np.isfinite(d.to_numpy()).all():raise ValueError('Incomplete test')
        if args.previous:
            index=d.set_index(INDEX).sort_index()
            old=pd.read_csv(args.previous/(mode+'.csv')).set_index(INDEX).sort_index()
            fixed=pd.read_csv(args.previous/(mode+'_fixed_controls.csv')).set_index(INDEX).sort_index()
            np.testing.assert_allclose(index[['uji_full','uji_scalar','fixed50']],old[['full','scalar','half']],atol=1e-8,rtol=0.)
            np.testing.assert_allclose(index.fixed75,fixed.fixed75,atol=1e-8,rtol=0.)
        if args.floor_reference:
            wk=pd.read_csv(args.floor_reference/('floor_wknn_'+mode+'.csv')).query("method=='gap_fit'").set_index(INDEX).mde
            d=d.set_index(INDEX).join(wk.rename('floor_wknn'),validate='one_to_one').reset_index()
        d.to_csv(args.out/(mode+'.csv'),index=False)
        refs=['uji_full','ipin_scalar','fixed75','fixed50','ipin_shuffled','ipin_APmean']+(['floor_wknn'] if args.floor_reference else [])
        tiers+=summary(d,mode,'ipin_full',refs)
        tiers+=summary(d,mode,'ipin_scalar',['uji_scalar','fixed75','fixed50'])
        if 'early_library_full' in d:
            tiers+=summary(d,mode,'early_library_full',['ipin_full','uji_full','early_library_scalar','fixed75'])
            tiers+=summary(d,mode,'early_library_scalar',['ipin_scalar','uji_scalar','fixed75'])
        print(mode,d.groupby(['building','K']).mean().groupby('building').mean().round(3),flush=True)
    pd.DataFrame(tiers).to_csv(args.out/'tiers.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['fit','evaluate'])
    for n in ('uji','ipin','frozen','out'):p.add_argument(n,type=Path)
    p.add_argument('--early-library',type=Path)
    p.add_argument('--previous',type=Path)
    p.add_argument('--floor-reference',type=Path)
    p.add_argument('--workers',type=int,default=5)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    (fit if a.stage=='fit' else evaluate)(a)
