"""Conditional calibration-draw uncertainty of paired risk differences.

Inputs are one complete method-vs-method event table. Query positions, floors
and buildings were not resampled; these intervals do not describe new sites.
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

from ..protocol import BUDGETS, SEEDS


def estimate(events, method, comparator, reps=10000):
    data=events[events.method.isin([method,comparator])]
    levels=['site','floor','seed','K']
    paired=data.pivot(index=levels,columns='method',values='mde')
    delta=(paired[method]-paired[comparator]).rename('delta').reset_index()
    if delta.delta.isna().any():
        raise ValueError('Incomplete paired comparison')
    rows=[]
    for site,group in delta.groupby('site'):
        floors=[]
        for _,floor in group.groupby('floor'):
            block=floor.pivot(index='seed',columns='K',values='delta').reindex(index=SEEDS,columns=BUDGETS)
            if block.isna().any().any(): raise ValueError('Incomplete nested-budget draw')
            floors.append(block.to_numpy())
        # One draw index selects its whole K curve. Each floor's draw sequence
        # has independent, floor-specific random seeds; give each floor equal weight.
        rng=np.random.default_rng(261101)
        boots=np.mean([values[rng.integers(len(SEEDS),size=(reps,len(SEEDS)))].mean(1)
                       for values in floors],axis=0)
        means=np.mean(floors,axis=(0,1))
        for k,point,rep in zip([*BUDGETS,'mean_K'],[*means,means.mean()],list(boots.T)+[boots.mean(1)]):
            lo,hi=np.quantile(rep,[.025,.975])
            rows.append(dict(site=site,K=k,method=method,comparator=comparator,mean_diff=point,
                             mc95_lo=lo,mc95_hi=hi,floors=len(floors),draws_per_floor=len(SEEDS),
                             strict_floor_wins=int(sum((f.mean(0)[BUDGETS.index(k)] if k!='mean_K' else f.mean())<0 for f in floors))))
    return pd.DataFrame(rows)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('events',type=Path); parser.add_argument('out',type=Path)
    parser.add_argument('method'); parser.add_argument('comparator')
    a=parser.parse_args()
    estimate(pd.read_csv(a.events),a.method,a.comparator).to_csv(a.out,index=False)
