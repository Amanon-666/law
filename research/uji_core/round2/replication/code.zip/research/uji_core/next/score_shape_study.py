"""Fit the same readout families on true source-building later labels and pseudo tasks."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from external_baselines import tpm_adapter as tpm
from residual_probe.episode_rows import nested_rows
from refi import smooth_history,FingerprintMap
from ..protocol import BUDGETS,SEEDS,read_floors,history_floors,position_weights,split_rows
from ..smooth_scale import local_rows
from .transport import source_design
from .ap_reliability import Episode,objective
from .score_shape import features,NAMES,predict

FAMILIES=dict(temperature=(0,0,0,0,0),rss_miss=(0,0,0,0,1),symmetric=(0,1,0,1,2),
              sign_only=(0,0,1,1,2),asymmetric=(0,1,2,3,4))
FIXED=dict(default=[1.,1.,1.,1.,1.],huber=[1.,0.,1.,0.,1.],half_tail=[1.,.5,1.,.5,1.],
           positive_half_tail=[1.,.5,1.,1.,1.],fixed_sign=[.75,.75,1.25,1.25,1.])
PENALTY=.1


def data_rows(train,valid,phones,jobs,regime,source):
    for j in jobs:
        b,f=j['building'],j['floor']
        target=train[b,f]
        hs=history_floors(train,b,f)
        dev=j.get('phone',-1)
        if regime=='period':
            q=valid[b,f]
            if source:
                orders=[nested_rows(target['xy'],range(len(target['xy'])),BUDGETS,0,f'early-late-src/{b}/{f}/{d}')['support_rows'][20] for d in range(3)]
            else:
                orders=[split_rows(target,b,f,d)[0] for d in SEEDS]
        else:
            hs=[{k:v[phones[h['ids']]!=dev] for k,v in h.items()} for h in hs]
            hs=[h for h in hs if len(h['rss'])]
            qr=local_rows(target,np.asarray(j['query_ids']))
            q={k:v[qr] for k,v in target.items()}
            orders=local_rows(target,np.asarray(j['support_orders']))
            if source:orders=orders[:3]
        hmask=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
        base,hxy=smooth_history(tpm.history_map(hs,None,None),10.,.5)
        weights=position_weights(q['xy'])
        for draw,order in enumerate(orders):
            for k in BUDGETS:
                sr=order[:k]
                active=hmask|(target['rss'][sr]!=100).any(0)
                s=dict(rss=target['rss'][sr][:,active],xy=target['xy'][sr])
                m,xy=tpm.calibrate((base[:,active],hxy),s,(40.,1.))
                x=features(m,q['rss'][:,active])
                x-=x.mean(1,keepdims=True)
                ep=Episode(x,xy-hxy[0],q['xy']-hxy[0],weights)
                yield (regime,b,f,dev,draw,k),ep,FingerprintMap(m,xy,active),q


def weighted(rows):
    idx=pd.DataFrame([s for s,_ in rows],columns=['regime','b','f','dev','draw','K'])
    w=np.ones(len(idx))
    for groups,key in (([],'regime'),(['regime'],'b'),(['regime','b'],'f'),(['regime','b','f'],'dev'),
                       (['regime','b','f','dev'],'draw'),(['regime','b','f','dev','draw'],'K')):
        w/=idx.groupby(groups)[key].transform('nunique').to_numpy() if groups else idx[key].nunique()
    np.testing.assert_allclose(w.sum(),1.,atol=1e-12,rtol=0.)
    return [(weight,ep) for weight,(_,ep) in zip(w,rows)]


def optimize(rows,family):
    mapping=np.asarray(FAMILIES[family])
    size=mapping.max()+1
    def calculation(v):
        c=v[mapping]
        g=np.zeros(5)
        val=0.
        for w,ep in rows:
            loss,grad=objective(c,ep,True)
            val+=w*loss;g+=w*grad
        gap=c-1.
        return val+PENALTY*(gap@gap),np.bincount(mapping,weights=g+2*PENALTY*gap,minlength=size)
    r=minimize(calculation,np.ones(size),jac=True,method='L-BFGS-B',
               bounds=[(.25,2.)]*size,options=dict(maxiter=60,ftol=1e-10,gtol=1e-6))
    if not r.success or not np.isfinite(r.fun) or not np.isfinite(r.x).all():
        raise RuntimeError(f'Unfinished source fit: {family} {r.message}')
    return r.x[mapping].tolist(),dict(iterations=int(r.nit),objective=float(r.fun),success=bool(r.success))


def fit(rows,held):
    chosen=[(key,ep) for key,ep in rows if held=='external' or key[1]!=held]
    buildings=sorted(set(k[1] for k,_ in chosen))
    if held in buildings:raise ValueError('Forbidden target source supervision')
    a=weighted(chosen);params=dict(FIXED);quality={}
    for family in FAMILIES:
        params[family],quality[family]=optimize(a,family)
    for reg in ('period','device'):
        one=weighted([(k,e) for k,e in chosen if k[0]==reg])
        for family in ('symmetric','asymmetric'):
            label=f'{reg}_{family}'
            params[label],quality[label]=optimize(one,family)
    full=np.array(params['asymmetric'])
    params['sign_swapped']=full[[2,3,0,1,4]].tolist()
    shared=(full[:2]+full[2:4])/2
    params['remove_direction']=[*shared,*shared,full[4]]
    # Post-hoc compact diagnostics, not predeclared target-blind challengers.
    params['fixed_weak_core']=[.5,1.,.5,1.,.5]
    params['fixed_cool']=[.8]*5
    return str(held),dict(coefficients=params,checks=quality,source_buildings=buildings,n_source_events=len(chosen))


def main(data,frozen,out,workers):
    out.mkdir(parents=True,exist_ok=True)
    train=read_floors(data,'trainingData.csv')
    valid=read_floors(data,'validationData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    fs=[dict(building=b,floor=f) for b,f in train]
    rows=[]
    for reg,jobs in [('period',fs),('device',source_design(train,phone))]:
        rows.extend((k,ep) for k,ep,_,_ in data_rows(train,valid,phone,jobs,reg,True))
    print('prepared',len(rows),'source events',flush=True)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        fits=dict(pool.map(lambda h:fit(rows,h),[0,1,2,'external']))
    record=dict(folds=fits,features=NAMES,cutoff_dB=12.,ridge_to_one=PENALTY,bounds=[.25,2.],
        supervision='Extra genuine later official query locations from the OTHER two buildings, plus phone-separated earlier-training-file pseudo episodes in those buildings. The actual held building supplies no training or regularization selection labels in its fold. Three fresh nested support draws/source task, all K. Equal regime/building/floor/device/draw/K, equal query position. External fit uses all three UJI buildings (including later labels).',
        profile='r=(observed−prototype)/12. For u=max(+r,0) or max(−r,0), core=u²−max(u−1,0)², tail=max(u−1,0)². Score is minus half of the weighted sums, plus the weighted old nondetection log-CDF. Each side is nondecreasing in error magnitude. Equal unit weights recover the fixed matcher.',
        controls='Common bounds, ridge on expanded 5 weights, optimizer and source folds for all fits. Huber floors the tail coefficient at zero by prior definition. Sign swap exchanges both core/tail pairs but keeps all fitted values. Follow-up remove_direction averages these two pairs without refitting. fixed_weak_core and fixed_cool are post-hoc simple approximations after viewing source-trained shapes; do not treat them as prospective comparisons.')
    path=out/'fit.json'
    path.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    del rows
    cfg=json.loads(path.read_text())['folds']
    manifest=json.loads((frozen/'device_stress_design.json').read_text())['events']
    for reg,jobs,outname in [('period',fs,'official'),('device',manifest,'phone')]:
        records=[];api_gap=0.
        for (r,b,f,dev,d,k),ep,model,q in data_rows(train,valid,phone,jobs,reg,False):
            v={n:float(objective(np.asarray(c),ep)) for n,c in cfg[str(b)]['coefficients'].items()}
            if d==0 and k==5:
                public=predict(model,q['rss'],cfg[str(b)]['coefficients']['asymmetric'])
                gap=abs(v['asymmetric'] - ep.qw@np.linalg.norm(public-q['xy'],axis=1))
                api_gap=max(api_gap,float(gap))
            records.append(dict(building=b,floor=f,draw=d,K=k,**v))
        res=pd.DataFrame(records);ix=['building','floor','draw','K']
        ref=pd.read_csv(frozen/('smooth_scale_official.csv' if outname=='official' else 'smooth_scale_phone.csv'))
        base=ref.query("method=='half10'").set_index(ix).mde.sort_index()
        np.testing.assert_allclose(res.set_index(ix).default.sort_index(),base,rtol=0.,atol=1e-8)
        if len(res)!=650 or not np.isfinite(res.to_numpy()).all() or api_gap>1e-8:
            raise ValueError('Invalid outcome/identity check')
        res.to_csv(out/(outname+'.csv'),index=False)
        print(outname,'api gap',api_gap,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('data','frozen','out'):p.add_argument(name,type=Path)
    p.add_argument('--workers',type=int,default=3)
    a=p.parse_args()
    main(a.data,a.frozen,a.out,a.workers)
