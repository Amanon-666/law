"""Apply frozen UJI-trained competitors to exactly the sealed external episodes.

No new target hyperparameter fits. This entry point only reads recorded
row IDs; it does not own any split-generation code.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from ..protocol import BUDGETS, position_weights
from .external import DATASETS, METRES_PER_UJI_UNIT, read_tau, read_sod
from .external_floor_wknn import GapReference


def main(data, dataset, protocol_path, wknn_path, out, label):
    protocol=json.loads(protocol_path.read_text())
    if protocol['doi']!=DATASETS[dataset]['doi']:
        raise ValueError('Mismatched external protocol')
    choice=json.loads(wknn_path.read_text())['selected']['external']['gap_fit']
    rep,alpha,n=choice
    reader=read_tau if dataset=='tau' else read_sod
    events=[]; predictions=[]
    suffix='' if label=='floor_wknn' else '_period'
    for site in DATASETS[dataset]['sites']:
        train,qset=(reader(data,site,side) for side in ('training','test'))
        for floor,q in sorted(qset.items()):
            cases=[c for c in protocol['events'] if (c['site'],c['floor'])==(site,floor)]
            if not cases: continue
            t=train[floor]
            other=sorted(set(train)-{floor}); hs=[train[f] for f in other]
            gap=GapReference(hs,[abs(f-floor) for f in other],rep)
            matched=gap.query(q['rss'])
            weight=position_weights(q['xy'])
            for c in cases:
                if c['query_ids']!=q['ids'].tolist():
                    raise ValueError('Query rows changed')
                order=c['support_local']
                if t['ids'][order].tolist()!=c['support_ids']:
                    raise ValueError('Support row order changed')
                for k in BUDGETS:
                    s={key:z[order[:k]] for key,z in t.items()}
                    pred=gap.event(matched,s,[alpha])[alpha,n]
                    error=np.linalg.norm(pred-q['xy'],axis=1)*METRES_PER_UJI_UNIT
                    key=dict(site=site,floor=floor,seed=c['seed'],K=k,method=label)
                    events.append(dict(**key,mde=weight@error))
                    predictions.append(pd.DataFrame(dict(**key,row_id=q['ids'],err_m=error,w=weight)))
    out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(events).to_csv(out/f'external_{dataset}{suffix}_challengers.csv',index=False)
    pd.concat(predictions,ignore_index=True).to_csv(out/f'external_{dataset}{suffix}_challenge_queries.csv.gz',index=False)
    hashes={x:hashlib.sha256(f.read_bytes()).hexdigest() for x,f in [('split',protocol_path),('wknn',wknn_path)]}
    (out/f'external_{dataset}{suffix}_challenger_config.json').write_text(json.dumps(dict(hashes=hashes,**{label:choice}),indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('data','protocol','wknn','out'):p.add_argument(name,type=Path)
    p.add_argument('--dataset',choices=DATASETS,required=True)
    p.add_argument('--label',choices=('floor_wknn','period_floor_wknn'),default='floor_wknn')
    a=p.parse_args();main(a.data,a.dataset,a.protocol,a.wknn,a.out,a.label)
