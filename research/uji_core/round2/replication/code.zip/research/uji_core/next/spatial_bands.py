"""A learned, three-coefficient spatial filter for the historical fingerprint map.

Separate fine, near and neighborhood-scale contrast; each is retained by a
learned fraction, recombined into ONE map, then updated using the same S rule.
"""
import argparse
from itertools import product
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap
from .transport import source_design
from ..protocol import BUDGETS,SEEDS,read_floors,split_rows,position_weights
from ..smooth_scale import local_rows
from residual_probe.episode_rows import nested_rows


HALF=(.5,.5,1.)
RETAINS=(0.,.5,1.,1.5)
GRID=tuple(product(RETAINS,repeat=3))
# Includes every half/full single smoother on 5, 10 and 25 units, plus the identity.
SINGLE=((1.,1.,1.),(0.,1.,1.),(.5,1.,1.),(0.,0.,1.),HALF,(0.,0.,0.),(.5,.5,.5))


class Multiscale:
    def __init__(self,hs,unit=1.):
        self.unit=unit
        m,self.xy=tpm.history_map(hs,None,None)
        self.mask=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
        dist=cdist(self.xy,self.xy,'sqeuclidean')/unit**2
        levels=[m]
        for length in (5.,10.,25.):
            k=np.exp(-.5*dist/length**2)
            levels.append((k/k.sum(1,keepdims=True))@m)
        self.slow=levels[-1]
        self.bands=[v-u for v,u in zip(levels[:-1],levels[1:])]

    def conditioned(self,s):
        mask=self.mask|(s['rss']!=100).any(0)
        y,sz=tpm.position_map(tpm.dbm(s['rss'][:,mask]),s['xy'])
        z=self.xy
        cross=np.exp(-cdist(z,sz,'sqeuclidean')/(2*(40*self.unit)**2))
        kss=np.exp(-cdist(sz,sz,'sqeuclidean')/(2*(40*self.unit)**2))
        p=np.linalg.solve(kss+np.eye(len(sz)),cross.T).T
        out=[]
        for v in [self.slow,*self.bands]:
            a=v[:,mask];out.append(a-p@tpm.lookup(sz,z,a))
        out[0]+=p@y
        return mask,np.vstack([z,sz]),y,out

    def condition(self,s,weights):
        mask,xy,y,(slow,*bands)=self.conditioned(s)
        value=slow+sum(w*v for w,v in zip(weights,bands))
        return FingerprintMap(np.vstack([np.clip(value,-110.,0.),y]),xy,mask)


def measure(tr,va,phones,jobs,period,models=None):
    records=[]
    for j in jobs:
        b,f=j['building'],j['floor']; t=tr[b,f]
        hs=[h for (hb,hf),h in tr.items() if hb==b and hf!=f]
        if period:
            q=va[b,f]
            orders=([nested_rows(t['xy'],range(len(t['xy'])),BUDGETS,0,f'bands-source/{b}/{f}/{d}')['support_rows'][20] for d in range(2)]
                    if models is None else [split_rows(t,b,f,d)[0] for d in SEEDS])
        else:
            hs=[{k:v[phones[h['ids']]!=j['phone']] for k,v in h.items()} for h in hs]
            hs=[h for h in hs if len(h['rss'])]
            ix=local_rows(t,np.asarray(j['query_ids'])); q={k:v[ix] for k,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))
            if models is None:orders=orders[:2]
        bank=Multiscale(hs);qw=position_weights(q['xy'])
        arms={str(p):p for p in GRID} if models is None else models[str(b)]
        for draw,order in enumerate(orders):
            for k in BUDGETS:
                s={key:v[order[:k]] for key,v in t.items()}
                mask,xy,y,(slow,a,c,d)=bank.conditioned(s)
                cache={}
                for name,w in arms.items():
                    w=tuple(w)
                    if w not in cache:
                        m=np.vstack([np.clip(slow+w[0]*a+w[1]*c+w[2]*d,-110,0),y])
                        prob=tpm.tobit_weights(q['rss'][:,mask],m,12,-85)
                        err=np.linalg.norm(prob@(xy-xy[0])+(xy[0]-q['xy']),axis=1)
                        cache[w]=qw@err
                    records.append((b,f,draw,k,name,*w,cache[w]))
    return pd.DataFrame(records,columns=['building','floor','draw','K','method','fine','near','broad','mde'])


def main(data,design,out):
    out.mkdir(exist_ok=True,parents=True)
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=[dict(building=b,floor=f) for b,f in tr]
    a=measure(tr,va,phone,jobs,True).assign(regime='period')
    d=measure(tr,va,phone,source_design(tr,phone),False).assign(regime='device')
    keys=['fine','near','broad']
    r=pd.concat([a,d]).groupby(['building','regime','floor',*keys]).mde.mean().groupby(['building','regime',*keys]).mean()
    r.to_csv(out/'source.csv');cfg={}
    for b in (0,1,2,'external'):
        sub=r if b=='external' else r.drop(b,level='building')
        best=lambda tab,grid:min(grid,key=lambda p:(tab.loc[p],np.linalg.norm(np.asarray(p)-np.asarray(HALF))))
        avg=sub.groupby(keys).mean()
        fit=best(avg,GRID)
        cfg[str(b)]=dict(half=HALF,single=best(avg,SINGLE),fixed_multiscale=(0.,.5,1.),
            smooth_fine_preserve_near=(0.,1.,1.),selected=fit,reversed=fit[::-1],
            device_fit=best(sub.xs('device',level='regime').groupby(keys).mean(),GRID),
            time_fit=best(sub.xs('period',level='regime').groupby(keys).mean(),GRID))
    fp=out/'fit.json';fp.write_text(json.dumps(cfg,indent=2)+'\n')
    cfg=json.loads(fp.read_text())
    measure(tr,va,phone,jobs,True,cfg).to_csv(out/'official.csv',index=False)
    measure(tr,va,phone,json.loads(design.read_text())['events'],False,cfg).to_csv(out/'phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','design','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.design,a.out)
