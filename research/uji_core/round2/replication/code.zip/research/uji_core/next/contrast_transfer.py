"""Did a historical peak and a historical hole transfer equally well?

Shrink each toward its spatial neighborhood. Two nonnegative rates distinguish
isolated peaks from holes in a scan map with a detection floor. Fit them on
post-adaptation positioning error in whole OTHER buildings' measured early /
late pairs. Also fit the same hypotheses on device-only pseudo tasks. Never
supply the target building to its own source fit.
"""
import argparse
import json
from pathlib import Path
from itertools import product
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from refi import FingerprintMap
from external_baselines import tpm_adapter as tpm
from ..protocol import BUDGETS, SEEDS, read_floors, split_rows, position_weights
from ..smooth_scale import local_rows
from ..field_shape import conditioned
from .transport import source_design
from residual_probe.episode_rows import nested_rows

STRENGTH=(0.,.25,.5,.75,1.)
GRID=tuple(product(STRENGTH,repeat=2))


class ContrastBank:
    def __init__(self,hist,unit=1.):
        self.unit=unit
        self.m,self.xy=tpm.history_map(hist,None,None)
        self.hmask=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hist])
        w=np.exp(-cdist(self.xy,self.xy,'sqeuclidean')/(2*(10*unit)**2))
        local=(w/w.sum(1,keepdims=True)) @ self.m
        d=local-self.m
        self.peaks=np.minimum(d,0.)
        self.holes=np.maximum(d,0.)

    def basis(self,srss,sxy):
        mask=self.hmask|(srss!=100).any(0)
        sy,sx=tpm.position_map(tpm.dbm(srss[:,mask]),sxy)
        # Scaling coordinates would change the legacy 1/(distance + 1)
        # anchor lookup. Perform lookup in the supplied coordinates, and
        # apply the physical conversion only to the two Gaussian lengths.
        m=self.m[:,mask]
        cross=np.exp(-cdist(self.xy,sx,'sqeuclidean')/(2*(40*self.unit)**2))
        ss=np.exp(-cdist(sx,sx,'sqeuclidean')/(2*(40*self.unit)**2))
        proj=np.linalg.solve(ss+np.eye(len(sx)),cross.T).T
        base=m+proj@(sy-tpm.lookup(sx,self.xy,m))
        components=[v[:,mask]-proj@tpm.lookup(sx,self.xy,v[:,mask]) for v in (self.peaks,self.holes)]
        return mask,sy,sx,base,*components

    def condition(self,s,peak,hole):
        mask,sy,sx,base,d1,d2=self.basis(s['rss'],s['xy'])
        proto=np.vstack((np.clip(base+peak*d1+hole*d2,-110.,0.),sy))
        return FingerprintMap(proto,np.vstack((self.xy,sx)),mask)


def jobs(tr,va,phone,entries,mode,grid,source=False):
    records=[]
    for j in entries:
        b,f=j['building'],j['floor'];t=tr[b,f]
        hs=[h for (hb,hf),h in tr.items() if hb==b and hf!=f]
        if mode=='period':
            q=va[b,f]
            if source:
                # All later Q positions are included, draw new early S paths.
                orders=[nested_rows(t['xy'],range(len(t['xy'])),BUDGETS,0,f'early-late-src/{b}/{f}/{i}')['support_rows'][20] for i in range(3)]
            else:orders=[split_rows(t,b,f,d)[0] for d in SEEDS]
        else:
            hs=[{k:v[phone[h['ids']]!=j['phone']] for k,v in h.items()} for h in hs]
            hs=[h for h in hs if len(h['rss'])]
            iq=local_rows(t,np.asarray(j['query_ids']));q={k:v[iq] for k,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))[:3 if source else len(SEEDS)]
        bank=ContrastBank(hs)
        models=grid if source else grid[str(b)]
        qw=position_weights(q['xy'])
        for draw,order in enumerate(orders):
            for k in BUDGETS:
                sr=order[:k]
                mask,sy,sx,base,a,c=bank.basis(t['rss'][sr],t['xy'][sr])
                xy=np.vstack((bank.xy,sx))
                cache={}
                for name,(i,l) in models.items():
                    pair=(i,l)
                    if pair not in cache:
                        proto=np.vstack((np.clip(base+i*a+l*c,-110.,0.),sy))
                        pred=tpm.tobit_weights(q['rss'][:,mask],proto,12.,-85.)@(xy-xy[0])+xy[0]
                        cache[pair]=qw@np.linalg.norm(pred-q['xy'],axis=1)
                    records.append((b,f,draw,k,name,i,l,cache[pair]))
    return pd.DataFrame(records,columns=['building','floor','draw','K','method','peak','hole','mde'])


def fit(src,held):
    r=src if held=='external' else src[src.building!=held]
    if held!='external' and held in r.building.unique():raise AssertionError('outer split')
    by=r.groupby(['regime','building','floor','peak','hole']).mde.mean().groupby(['regime','building','peak','hole']).mean()
    mean=by.groupby(['peak','hole']).mean()
    best=lambda table,opts:min(opts,key=lambda p:(table.loc[p],abs(p[0]-.5)+abs(p[1]-.5)))
    fixed=dict(half=(.5,.5),only_fill=(0.,1.),only_trim=(1.,0.),
               mild_fill=(.25,.75),mild_trim=(.75,.25))
    fixed['selected']=best(mean,GRID)
    fixed['tied']=best(mean,[(g,g) for g in STRENGTH])
    for regime in ['period','device']:
        fixed[regime+'_fit']=best(by.loc[regime].groupby(['peak','hole']).mean(),GRID)
    return fixed


def main(data,design,out):
    out.mkdir(parents=True,exist_ok=True)
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    fs=[dict(building=b,floor=f) for b,f in tr]
    grid={str(p):p for p in GRID}
    earlylate=jobs(tr,va,phone,fs,'period',grid,source=True).assign(regime='period')
    device=jobs(tr,va,phone,source_design(tr,phone),'device',grid,source=True).assign(regime='device')
    src=pd.concat([earlylate,device])
    source=src.groupby(['regime','building','floor','peak','hole'],as_index=False).mde.mean()
    source.to_csv(out/'source.csv',index=False)
    cfg={str(b):fit(source,b) for b in (0,1,2,'external')}
    file=out/'fit.json';file.write_text(json.dumps(cfg,indent=2)+'\n')
    cfg=json.loads(file.read_text())
    jobs(tr,va,phone,fs,'period',cfg).to_csv(out/'official.csv',index=False)
    jobs(tr,va,phone,json.loads(design.read_text())['events'],'device',cfg).to_csv(out/'phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','design','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.design,a.out)
