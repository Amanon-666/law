"""IPIN 2016 UAH and CAR training-log adapter. No blind/competition evaluation input.

python -m research.uji_core.next.additional_sources ARCHIVE PREPARED_DIR
episodes(PREPARED_DIR) yields meta, list of H, S, Q. XY are already UJI-equivalent
distance units (multiply by 0.766 for meters), 100 means an undetected AP.
"""
import argparse
from collections import defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import tempfile
from zipfile import ZipFile

import numpy as np
from scipy.spatial.distance import cdist
from public_corpus.adapter import parse_log
from residual_probe.episode_rows import nested_rows
from ..protocol import BUDGETS, position_weights
from .external import METRES_PER_UJI_UNIT

SHA='9b78ab0aee9544450dc6351a0dad56dfa0b8e0b6f290fced05bbd8318f4a2791'


def insession(path):
    with path.open(encoding='latin-1') as f:
        next(f); header=next(f).split(': ',1)[1].strip()
    normalized=header.replace('GMT','').replace('CEST','+02:00').replace('CET','+01:00')
    return datetime.strptime(normalized,'%a %b %d %H:%M:%S %z %Y')


def prepare(archive,directory):
    directory.mkdir(exist_ok=True,parents=True)
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=SHA:raise ValueError('Unexpected IPIN archive')
    by_site=defaultdict(list);info={}
    with ZipFile(archive) as z, tempfile.TemporaryDirectory() as tmp:
        for n in sorted(z.namelist()):
            path=Path(n)
            match=re.fullmatch(r'logfile_(CAR|UAH)_R(\d+)_(S3mini|S3|S4)\.txt',path.name)
            if not match or '/01-Training/' not in n: continue
            site,route,phone=match.groups()
            source=Path(tmp)/path.name; source.write_bytes(z.read(n))
            start=insession(source); raw=parse_log(source)
            for scan in raw:
                scan.update(route=int(route),phone=phone,session=path.stem,
                            time=start.timestamp()+scan['app_timestamp'])
                by_site[site].append(scan)
            floors,counts=np.unique([r['floor'] for r in raw],return_counts=True)
            info[path.stem]=dict(site=site,route=int(route),phone=phone,creation=start.isoformat(),
                                 scans_by_floor={str(f):int(c) for f,c in zip(floors,counts)})
    summary={}
    for site,rows in by_site.items():
        labels=sorted({ap for r in rows for ap in r['rss']})
        index={a:j for j,a in enumerate(labels)}
        ref=min(rows,key=lambda r:r['time'])
        lat0,lon0=ref['lat'],ref['lon']
        xy=np.array([[(r['lon']-lon0)*111320*np.cos(np.deg2rad(lat0)),(r['lat']-lat0)*111320] for r in rows])
        rss=np.full((len(rows),len(labels)),100,dtype=np.int16)
        for i,r in enumerate(rows):
            for a,v in r['rss'].items():rss[i,index[a]]=int(v)
        np.savez_compressed(directory/(site+'.npz'),rss=rss,xy=xy/METRES_PER_UJI_UNIT,ids=np.arange(len(rows)),
                            **{key:np.array([r[key] for r in rows]) for key in ('time','floor','route','session','phone')})
        summary[site]=dict(scans=len(rows),aps=len(labels),origin_first_prior_scan=[lat0,lon0],
                           raw_building_ids=sorted({r['building'] for r in rows}))
    record=dict(doi='10.5281/zenodo.2791530',primary_paper='10.3390/s17030557',input_sha256=SHA,
                input='17 training logs in release; keep 10 UAH/CAR only, omit UJITI and UJIUB. No official evaluation.',
                units='WGS84 to local east/north meters using 111320*cos(lat0),111320, origin earliest accepted scan per site. Then divide by 0.766.',
                label='Existing parse_log: scans interpolated between same-floor/same-building POSI landmarks no more than 120s apart. Walking labels; R=1 only.',
                independent='Two physical buildings. One cross-floor UAH building and one single-floor same-session-transfer CAR building. Parallel handsets on a route are not independent trajectories.',
                sessions=info,sites=summary)
    (directory/'ipin_manifest.json').write_text(json.dumps(record,indent=2)+'\n')


def subset(table,which):
    return {k:v[which] for k,v in table.items()}


def tasks(t,site):
    candidates=[]
    for route in sorted(set(t['route'])):
        for phone in sorted(set(t['phone'][t['route']==route])):
            query_session=(t['route']==route)&(t['phone']==phone)
            q_start=t['time'][query_session].min()
            # Earlier routes only, regardless of collection filename ordering.
            earlier=[r for r in np.unique(t['route']) if t['time'][t['route']==r].max()<q_start]
            if not earlier: continue
            hpool=np.isin(t['route'],earlier)&(t['phone']!=phone)
            for floor in sorted(set(t['floor'][query_session])):
                target=(t['floor']==floor)
                qi=np.where(query_session&target)[0]
                if site=='UAH':
                    hi=np.where(hpool & ~target)[0]
                    si=np.where(hpool & target)[0]
                else:
                    # H is a truly previous physical trip. Split the two new-route
                    # parallel phone logs into disjoint time windows, not two trips.
                    midpoint=np.median(t['time'][qi])
                    hi=np.where(hpool & target)[0]
                    si=np.where((t['route']==route)&(t['phone']!=phone)&target&(t['time']<midpoint-15.))[0]
                    qi=qi[t['time'][qi]>midpoint+15.]
                if len(hi) and len(np.unique(t['xy'][si],axis=0))>=20 and len(np.unique(t['xy'][qi],axis=0))>=8:
                    candidates.append((int(floor),int(route),str(phone),hi,si,qi))
    # Cover every feasible target floor before repeating one with another phone.
    ordered=[]
    floors=sorted({c[0] for c in candidates})
    groups=[sorted((c for c in candidates if c[0]==f),key=lambda c:c[1:3]) for f in floors]
    for i in range(max(map(len,groups),default=0)):
        ordered.extend(g[i] for g in groups if i<len(g))
    return ordered


def episodes(directory,draws=5):
    if not 1<=draws<=5:raise ValueError('This source design permits 1 to 5 nested draws per building')
    for site in ('UAH','CAR'):
        with np.load(Path(directory)/(site+'.npz'),allow_pickle=False) as file:
            t={k:file[k] for k in file.files}
        candidates=tasks(t,site)
        if not candidates:continue
        for draw in range(draws):
            floor,route,phone,hi,si,qi=candidates[draw%len(candidates)]
            split=f'ipin-extra-v1/{site}/{floor}/{route}/{phone}/{draw}'
            sr=np.array(nested_rows(t['xy'],si,BUDGETS,0,split)['support_rows'][20])
            # Fix Q independently of K. Leave a 0.5 metre buffer to the *entire*
            # reserved 20-position support to suppress GPS/interpolation near-duplicates.
            possible=qi[cdist(t['xy'][qi],t['xy'][sr]).min(1)*METRES_PER_UJI_UNIT>.5]
            pts,first=np.unique(t['xy'][possible],axis=0,return_index=True)
            rng=np.random.default_rng(int.from_bytes(hashlib.sha256((split+'/Q').encode()).digest()[:8],'little'))
            qr=possible[first[rng.choice(len(pts),min(32,len(pts)),replace=False)]]
            if len(qr)<8 or t['time'][sr].max()>=t['time'][qr].min() or t['time'][hi].max()>=t['time'][qr].min():
                raise ValueError('Ineligible chronological/space-separated episode')
            if set(t['phone'][hi])&{phone} or set(t['phone'][sr])&{phone}:
                raise ValueError('Query handset reached H or S')
            hist_rows=[hi[t['floor'][hi]==f] for f in sorted(set(t['floor'][hi]))]
            for k in BUDGETS:
                srows=sr[:k]
                mask=(t['rss'][hi]!=100).any(0)|(t['rss'][srows]!=100).any(0)
                def scans(ids):
                    d=subset(t,ids);d['rss']=d['rss'][:,mask]
                    return d
                q=scans(qr);q['weights']=position_weights(q['xy'])
                meta=dict(site=site,floor=floor,draw=draw,K=k,query_route=route,query_phone=phone,
                          history_floors=[int(t['floor'][ix[0]]) for ix in hist_rows],
                          history_routes=sorted(int(x) for x in set(t['route'][hi])),
                          support_routes=sorted(int(x) for x in set(t['route'][srows])),
                          units='UJI equivalent; XY * 0.766 = meters',delta_seconds=float(t['time'][qr].min()-t['time'][srows].max()))
                yield meta,[scans(ix) for ix in hist_rows],scans(srows),q


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive',type=Path);p.add_argument('directory',type=Path)
    a=p.parse_args();prepare(a.archive,a.directory)
    rows=[]
    for m,h,s,q in episodes(a.directory):
        rows.append(dict(**m,n_H=[len(x['rss']) for x in h],n_Q=len(q['rss']),
                         support_ids=s['ids'].tolist(),query_ids=q['ids'].tolist()))
    (a.directory/'ipin_episodes.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('Prepared',len(rows),'source events',sorted({r['site'] for r in rows}))
