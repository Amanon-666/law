"""Check slope ablations and examine measured target field errors after scoring."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from ..protocol import read_floors
from ..summarize import INDEX
from .vertical import VerticalBank


def checks():
    loc=np.array([[0.,0.],[3.,0.]])
    signal=np.array([[-80.,-65.],[-80.,-65.]])
    h=[dict(rss=signal,xy=loc), dict(rss=signal+np.array([5.,-2.]),xy=loc)]
    bank=VerticalBank(h,[1,2],0)
    expected=signal-np.array([5.,-2.])
    np.testing.assert_allclose(bank.prior(0.),expected,rtol=0.,atol=1e-10)
    other=VerticalBank(list(reversed(h)),[8,9],10)
    # Reflect every original level z -> 10-z and reorder the input sources.
    np.testing.assert_allclose(other.prior(1.),bank.prior(1.),atol=1e-10,rtol=0.)
    one=VerticalBank(h[:1],[1],0)
    np.testing.assert_allclose(one.prior(0.),one.prior(None),rtol=0.,atol=1e-10)
    return bool(True)


def main(data,holders,floor_wknn,out):
    fits=json.loads((out/'fit.json').read_text())['fits']
    summaries=[]
    for mode in ('official','phone'):
        d=pd.read_csv(out/(mode+'.csv')).set_index(INDEX).sort_index()
        wk=pd.read_csv(floor_wknn/('floor_wknn_'+mode+'.csv')).query("method=='gap_fit'").set_index(INDEX).mde
        d['floor_wknn']=wk
        if len(d)!=650 or not np.isfinite(d.to_numpy()).all():
            raise ValueError('Invalid pair')
        f=d.groupby(['building','floor','K']).mean()
        b=f.groupby(['building','K']).mean()
        for method in ('source','H_closed','ridge1'):
            for baseline in ('parent','nearest','ols','ridge1','shared','shuffled','H_closed','floor_wknn'):
                value=b[method]-b[baseline]
                row=dict(mode=mode,method=method,baseline=baseline,mde=b[method].mean(),baseline_mde=b[baseline].mean(),delta=value.mean())
                for name,tab,groups in [('building',b,['building']),('floor',f,['building','floor']),('draw',d,['building','floor','draw'])]:
                    delta=tab[method]-tab[baseline]
                    adj=tab[method].groupby(groups).diff().dropna()
                    row[name+'_K_wins']=int((delta< -1e-8).sum());row[name+'_K_ties']=int((np.abs(delta)<=1e-8).sum())
                    row[name+'_K_n']=len(delta)
                    row[name+'_K_improve']=int((adj< -1e-8).sum());row[name+'_adj_n']=len(adj)
                summaries.append(row)
    pd.DataFrame(summaries).to_csv(out/'tiers.csv',index=False)
    tr=read_floors(data,'trainingData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    stress={(e['building'],e['floor']):e['phone'] for e in json.loads(holders.read_text())['events']}
    results=[]
    for (b,fl),t in tr.items():
        for mode in ('official','phone'):
            dev=stress[b,fl]
            hs,levels=[],[]
            for (bb,ff),z in tr.items():
                if b!=bb or ff==fl:continue
                mask=np.ones(len(z['rss']),dtype=bool) if mode=='official' else phones[z['ids']]!=dev
                if mask.any():
                    hs.append(dict(rss=z['rss'][mask],xy=z['xy'][mask]));levels.append(ff)
            bank=VerticalBank(hs,levels,fl,decay=fits[str(b)]['decay'])
            # Retrospective field diagnosis only: all target training measurements
            # (official scenario) or all available rows of the held device.
            visible=np.ones(len(t['rss']),dtype=bool) if mode=='official' else phones[t['ids']]==dev
            observed,xy=tpm.position_map(tpm.dbm(t['rss'][visible]),t['xy'][visible])
            ix={tuple(p):i for i,p in enumerate(bank.xy)}
            pairs=np.array([(i,ix[tuple(p)]) for i,p in enumerate(xy) if tuple(p) in ix],dtype=int)
            if not len(pairs): continue
            qi,hi=pairs.T
            y=observed[qi][:,bank.hmask]
            base=bank.constant[hi][:,bank.hmask]
            row=dict(mode=mode,building=b,floor=fl,exterior=bool(fl<min(levels) or fl>max(levels)),
                     available_target_xy=len(xy),paired_xy=len(qi),permitted_H_APs=int(bank.hmask.sum()),
                     mse_parent=float(np.mean((y-base)**2)))
            for name,ridge in [('OLS',0.),('source',fits[str(b)]['ridge'])]:
                change=bank.prior(ridge)[hi][:,bank.hmask]-base
                denominator=np.mean(change**2)
                row[name+'_mse']=float(np.mean((y-base-change)**2))
                row[name+'_alignment']=None if denominator<1e-12 else float(np.mean(change*(y-base))/denominator)
                row[name+'_rms_update']=float(np.sqrt(denominator))
            results.append(row)
    pd.DataFrame(results).to_csv(out/'registered_field_check.csv',index=False)
    (out/'checks.json').write_text(json.dumps(dict(linear_recovery_reflection_single_source=checks(),
        fixed_information='Target train labels opened only in post-hoc registered-field check. All shared XY weighted equally, H-visible APs only. No change to fitted method. MSE in squared filled-dBm units.'),indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('data','holders','floor_wknn','out'):p.add_argument(name,type=Path)
    args=p.parse_args()
    main(args.data,args.holders,args.floor_wknn,args.out)
