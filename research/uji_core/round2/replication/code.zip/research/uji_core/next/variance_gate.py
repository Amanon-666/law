"""A query-dependent convex pool of normalized homogeneous and local posterior maps."""
import numpy as np
from scipy.special import softmax
from .map_variance import QueryTerms,variance


def endpoints(field,q,local):
    # Query-only APs are never admitted: use exactly the same H ∪ current S catalogue.
    raw=np.asarray(q,dtype=float)
    if raw.ndim!=2 or raw.shape[1]!=len(field.visible) or not np.isfinite(raw).all():
        raise ValueError('Expected finite query scans on the same AP axis')
    t=QueryTerms(raw[:,field.visible])
    m=field.prototypes
    base=softmax(t.scores(m,np.array([[144.]])),axis=1)
    loc=softmax(t.scores(m,variance(field.within,field.between,local)),axis=1)
    xy=field.xy-field.xy[0]
    # Binary Brier mismatch vs its expected value for a sample drawn from
    # the H receiver profile. Use the neutral positional posterior to average x.
    p=field.detection_probability
    mismatch=t.detected.sum(1,keepdims=True)-2*t.detected@p.T+(p*p).sum(1)[None]
    measured=(base*mismatch).sum(1)
    expected=base@(p*(1.-p)).sum(1)
    novelty=np.clip(.5+.5*np.log2((1.+measured)/(1.+expected)),0.,1.)
    first=base@xy
    return first, loc@xy-first, novelty


def predict(field,query_rss,local_coefficients,gate_endpoints):
    g=np.asarray(gate_endpoints,dtype=float)
    if g.shape!=(2,) or not np.isfinite(g).all() or (g<0).any() or (g>1).any():
        raise ValueError('Expected two mixture weights in [0,1]')
    raw=np.asarray(query_rss,dtype=float)
    out=np.empty((len(raw),2))
    for i in range(0,len(raw),64):
        base,change,c=endpoints(field,raw[i:i+64],local_coefficients)
        gate=(1.-c)*g[0]+c*g[1]
        out[i:i+64]=base+gate[:,None]*change+field.xy[0]
    return out
