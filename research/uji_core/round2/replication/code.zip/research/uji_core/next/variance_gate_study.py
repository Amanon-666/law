"""Nested source-building fitting and row-frozen tests of one novelty proxy."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from ..summarize import INDEX
from . import map_variance_study as base_study
from .transport import source_design
from .variance_gate import endpoints,predict

PENALTY=.02


def training(rows,constant=False,ridge=PENALTY):
    keys=pd.DataFrame([e[0] for e in rows],columns=['regime','building','floor','phone','draw','K'])
    w=np.ones(len(rows))
    for size,key in enumerate(keys.columns):
        groups=list(keys.columns[:size])
        w/=keys.groupby(groups)[key].transform('nunique').to_numpy() if size else keys[key].nunique()
    residual=np.concatenate([e[1] for e in rows]);change=np.concatenate([e[2] for e in rows])
    c=np.concatenate([e[3] for e in rows]);weight=np.concatenate([a*e[4] for a,e in zip(w,rows)])
    np.testing.assert_allclose(weight.sum(),1.,rtol=0.,atol=1e-11)
    basis=np.column_stack((1.-c,c))
    dim=1 if constant else 2
    def loss(v):
        g=np.repeat(v[0],2) if constant else v
        bias=residual+(basis@g)[:,None]*change
        dist=np.linalg.norm(bias,axis=1)
        gradient=basis.T@(weight*(bias*change).sum(1)/np.maximum(dist,1e-9))+2*ridge*(g-.5)
        value=weight@dist+ridge*np.sum((g-.5)**2)
        return value,np.array([gradient.sum()]) if constant else gradient
    res=minimize(loss,np.full(dim,.5),jac=True,method='L-BFGS-B',bounds=[(0.,1.)]*dim,
                 options=dict(ftol=1e-12,gtol=1e-8,maxiter=80))
    if not res.success or not np.isfinite(res.x).all():raise ValueError(f'Unfinished gate fit: {res.message}')
    return res.x.tolist()


def source_fit(train,phones,table,prior):
    buildings=sorted({b for b,f in train})
    heldset=[*buildings,'external']
    choices={}
    for held in heldset:
        valid_sources=[b for b in buildings if b!=held]
        choices[held]={}
        for b in valid_sources:
            fit_sources=[x for x in valid_sources if x!=b]
            if not fit_sources:raise ValueError('Need two eligible source buildings to nest the gate fit')
            restricted=table[table.building.isin(fit_sources)]
            assert held not in restricted.building.unique() and b not in restricted.building.unique()
            choices[held][b]=base_study.select(restricted,'external')['full'][1:]
    rows={held:[] for held in heldset}
    source_jobs={'period':[dict(building=b,floor=f) for b,f in train], 'device':source_design(train,phones)}
    for regime,jobs in source_jobs.items():
        for j in jobs:
            b,f=j['building'],j['floor']
            for draw,k,field,_,q,qw in base_study.episodes(j,regime,True):
                cache={}
                for held in heldset:
                    if held==b:continue
                    param=tuple(choices[held][b])
                    if param not in cache:
                        b0,delta,c=endpoints(field,q['rss'],param)
                        cache[param]=(b0-(q['xy']-field.xy[0]),delta,c)
                    rows[held].append(((regime,b,f,j.get('phone',-1),draw,k),*cache[param],qw))
    fits={}
    for held in heldset:
        fits[str(held)]=dict(endpoints=training(rows[held]),constant=training(rows[held],True)[0],
            training_episodes=len(rows[held]),source_buildings=list(choices[held]),nested_local_experts=choices[held],
            local=prior[str(held)]['full'][1:],constant_sigma=prior[str(held)]['constant'][1:])
    return fits


def error(a,d,g,w):
    return float(w@np.linalg.norm(a+np.broadcast_to(g,(len(w),))[:,None]*d,axis=1))


def main(data,frozen,out):
    base_study.init(data)
    tr=base_study.TR;ph=base_study.PH
    table=pd.read_csv(out/'source_risks.csv')
    prior=json.loads((out/'fit.json').read_text())['choices']
    cfg=source_fit(tr,ph,table,prior)
    file=out/'gate_fit.json'
    file.write_text(json.dumps(dict(folds=cfg,ridge=PENALTY,proxy='H-only historical p(D=1|x) uses same empirical mixture/half10 smoothing as H mean; at S coordinates p is interpolated from H. Neutral fixed12 posterior weights x. c=clip(0.5+0.5 log2[(1+E_x sum(D-p)^2)/(1+E_x sum p(1-p))],0,1). Only current permitted APs. No query metadata.',
        fit='Other source-building true later labels plus phone-separated pseudo tasks. Gate-source local-expert predictions are out-of-fold by entire source building, so the outer target and current inner source labels cannot fit expert coefficients. Deployed local refit on all available sources. Equal regime/building/floor/device/draw/K/query-location. Convex MDE + .02*((g0-.5)^2+(g1-.5)^2), same regularization for tied constant mixture.',
        deployment='Discriminative pool of normalized position probabilities; expectation=(1-g)m0+g*m1. No assumption that g is a prior probability on a physical receiver type. Registry order or protocol labels are never deployed. Permuted control is an evaluation-only same-query histogram shuffle.'),indent=2,allow_nan=False)+'\n')
    cfg=json.loads(file.read_text())['folds']
    for mode,regime,jobs in [('official','period',[dict(building=b,floor=f) for b,f in tr]),
                            ('phone','device',json.loads((frozen/'device_stress_design.json').read_text())['events'])]:
        rows=[];records=[]
        for j in jobs:
            b,f=j['building'],j['floor'];settings=cfg[str(b)]
            for draw,k,field,_,q,w in base_study.episodes(j,regime,False):
                first,change,c=endpoints(field,q['rss'],settings['local'])
                a=first-(q['xy']-field.xy[0])
                pair=settings['endpoints'];g=pair[0]*(1.-c)+pair[1]*c
                order=np.random.default_rng(19860).permutation(len(g))
                perm=np.empty_like(order);perm[order]=np.roll(order,1)
                weights=dict(fixed12=0.,always_local=1.,fixed_half=.5,constant_mix=settings['constant'],
                             conditioned=g,shuffled=g[perm])
                item=dict(building=b,floor=f,draw=draw,K=k,proxy=w@c,gate=w@g,
                          gate_sd=np.sqrt(w@(g-w@g)**2),
                          local_minus_fixed_endpoint=w@(np.linalg.norm(a+change,axis=1)-np.linalg.norm(a,axis=1)))
                item.update({name:error(a,change,v,w) for name,v in weights.items()})
                pred=field.predict(q['rss'],settings['constant_sigma'])
                item['trained_constant_sigma']=float(w@np.linalg.norm(pred-q['xy'],axis=1))
                if draw==0 and k==5:
                    deployment=predict(field,q['rss'],settings['local'],pair)
                    np.testing.assert_allclose(item['conditioned'],w@np.linalg.norm(deployment-q['xy'],axis=1),atol=1e-8,rtol=0.)
                rows.append(item);records.append(((mode,b,f,j.get('phone',-1),draw,k),a,change,c,w))
        # Oracle knows the evaluation population's labels, only descriptive.
        ceiling=training(records,True,ridge=0.)[0]
        for row,(_,a,change,c,w) in zip(rows,records):
            row['diagnostic_regime_oracle']=error(a,change,ceiling,w)
            row['oracle_weight']=ceiling
        result=pd.DataFrame(rows)
        actual=result.set_index(INDEX).sort_index()
        prev=pd.read_csv(out/(mode+'.csv')).set_index(INDEX).sort_index()
        np.testing.assert_allclose(actual[['fixed12','always_local','trained_constant_sigma']],prev[['default','full','constant']],rtol=0.,atol=1e-8)
        if len(result)!=650 or not np.isfinite(result.to_numpy()).all():raise ValueError('Invalid pairs')
        result.to_csv(out/('gate_'+mode+'.csv'),index=False)
        print(mode,actual.groupby(['building','K']).mean().groupby('building').mean().round(3),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','out'):p.add_argument(n,type=Path)
    a=p.parse_args();main(a.data,a.frozen,a.out)
