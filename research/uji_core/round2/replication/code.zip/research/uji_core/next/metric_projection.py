"""Frozen site-specific, coordinate-supervised RSS metric on an existing map.

Learn only a rank-at-most-two Mahalanobis term from *deployment H*, using
within-floor coordinate variation and balanced spatial sampling. A single
extra quadratic term adjusts the original Tobit score. No target data select
its ridge or strength. Matched negative controls share both H and readout.
"""
import argparse
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import log_ndtr, softmax
from external_baselines import tpm_adapter as tpm
from refi import smooth_history
from ..protocol import BUDGETS, HASHES, read_floors, position_weights
from .match_episodes import source_tasks,eval_tasks

RIDGES=(.1,1.,10.,100.)
STRENGTHS=(0.,.25,1.,4.,16.,64.,256.)
PERMS=3


def whiten(b,cov):
    small=b.T@cov@b
    lam,u=np.linalg.eigh((small+small.T)/2)
    ok=lam>max(1e-12,float(lam.max())*1e-8)
    out=np.zeros_like(b)
    out[:,:ok.sum()]=b@u[:,ok]/np.sqrt(lam[ok])
    return out


def fit_directions(histories,ridges=RIDGES,controls=True):
    hs=[h for h in histories if len(h['rss'])]
    if not hs:raise ValueError('A historical fingerprint bank is required')
    active=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs]);na=active.sum()
    cov=np.zeros((na,na));sx=np.zeros((1+(PERMS if controls else 0),na,2));coverage=[]
    for h in hs:
        xy,ix,cnt=np.unique(h['xy'],axis=0,return_inverse=True,return_counts=True)
        ix=ix.ravel();w=1./(len(xy)*cnt[ix]);r=tpm.dbm(h['rss'][:,active]);rc=r-w@r
        cov+=(rc.T*w)@rc/len(hs)
        # Equal mass per location. Label shuffles permute distinct positions,
        # preserving all repeats in each group and both coordinate marginals.
        delta=xy-xy.mean(0);sx[0]+=(rc.T*w)@delta[ix]/len(hs)
        if controls:
            for j in range(PERMS):
                rng=np.random.default_rng(261101+j)
                perm=rng.permutation(len(xy));sx[1+j]+=(rc.T*w)@delta[perm[ix]]/len(hs)
        coverage.append(len(xy))
    result={}
    e,vec=np.linalg.eigh(cov);e=np.maximum(e,0.)
    factor=float(e.mean()) if len(e) else 0.
    def expand(a):
        out=np.zeros((len(active),2));out[active]=a;return out
    for k in range(len(sx)):
        name='true' if k==0 else f'perm{k-1}'
        proj=vec.T@sx[k]
        for ridge in ridges:
            if factor>0.:
                b=vec@(proj/(e+ridge*factor)[:,None]);b=whiten(b,cov)
            else:b=np.zeros((na,2))
            result[name,ridge]=expand(b)
    if controls:
        b=np.zeros((na,2));count=min(2,na)
        if count:b[:,:count]=vec[:,-count:]
        result['pca',0.]=expand(whiten(b,cov))
    return result,dict(visible=int(na),historical_positions_per_floor=coverage,
                       largest_eigenvalues=e[-2:].tolist(),mean_eigenvalue=factor)


def base_logscore(rss,m):
    d=(rss!=100).astype(float);r=np.where(rss!=100,rss.astype(float)+75.,0.);v=m+75.
    return (r@v.T-.5*d@(v*v).T)/12.**2 + (1.-d)@log_ndtr((-85.-m)/12.).T


def distance2(rss,prototypes,b):
    v=(tpm.dbm(rss)+110.)@b;u=(prototypes+110.)@b
    return np.maximum((v*v).sum(1)[:,None]+(u*u).sum(1)-2*v@u.T,0.)


@dataclass
class ProjectionMap:
    prototypes: np.ndarray
    xy: np.ndarray
    mask: np.ndarray
    direction: np.ndarray
    strength: float

    def predict(self,rss):
        q=np.asarray(rss)[:,self.mask];score=base_logscore(q,self.prototypes)
        if self.strength>0:score-=.5*self.strength*distance2(q,self.prototypes,self.direction[self.mask])
        return softmax(score,axis=1)@(self.xy-self.xy[0])+self.xy[0]


def fit_projection_map(histories,support,ridge,strength,coordinate_units_per_uji=1.):
    """External/production fit, requiring only H/S and two frozen parameters."""
    if ridge<=0 or strength<0 or coordinate_units_per_uji<=0:raise ValueError('Invalid metric settings')
    hs=[dict(rss=h['rss'],xy=h['xy']/coordinate_units_per_uji) for h in histories if len(h['rss'])]
    d,_=fit_directions(hs,ridges=(ridge,),controls=False)
    m,xy=smooth_history(tpm.history_map(hs,None,None),10.,.5)
    mask=np.logical_or.reduce([(h['rss']!=100).any(0) for h in [*hs,support]])
    s=dict(rss=support['rss'][:,mask],xy=support['xy']/coordinate_units_per_uji)
    proto,xy=tpm.calibrate((m[:,mask],xy),s,(40.,1.))
    return ProjectionMap(proto,xy*coordinate_units_per_uji,mask,d['true',ridge],strength)


def score(scores,xy,truth,w):
    pred=softmax(scores,axis=-1)@(xy-xy[0])+xy[0]
    err=np.linalg.norm(pred-truth,axis=-1)
    return err@w


def evaluate(train,official,phones,times,design,mode,fit=None):
    rows=[];counts=[]
    for (b,f),target in train.items():
        tasks=source_tasks(train,phones,times,b,f) if mode=='source' else eval_tasks(train,official,phones,design,b,f,mode)
        for dev,hs,draws in tasks:
            directions,info=fit_directions(hs)
            counts.append(dict(building=b,floor=f,device=dev,**info))
            prior,hh=smooth_history(tpm.history_map(hs,None,None),10.,.5)
            hseen=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
            for draw,sr,q in draws:
                w=position_weights(q['xy'])
                for k in BUDGETS:
                    ix=sr[:k];mask=hseen|(target['rss'][ix]!=100).any(0)
                    s=dict(rss=target['rss'][ix][:,mask],xy=target['xy'][ix])
                    prot,xy=tpm.calibrate((prior[:,mask],hh),s,(40.,1.));r=q['rss'][:,mask]
                    base=base_logscore(r,prot);truth=q['xy'];tau=np.asarray(STRENGTHS)
                    meta=(b,f,dev,draw,k)
                    if mode=='source':
                        perm={ridge:np.zeros(len(tau)) for ridge in RIDGES}
                        for (kind,ridge),direction in directions.items():
                            d2=distance2(r,prot,direction[mask]);loss=score(base[None,:,:]-.5*tau[:,None,None]*d2,xy,truth,w)
                            if kind.startswith('perm'):perm[ridge]+=loss/PERMS
                            else:rows.extend((*meta,kind,ridge,t,v) for t,v in zip(tau,loss))
                        for rho,loss in perm.items():rows.extend((*meta,'perm',rho,t,v) for t,v in zip(tau,loss))
                    else:
                        chosen=fit[str(b)];tr,tt=chosen['true'];rr,rt=chosen['perm'];_,pt=chosen['pca']
                        dist={}
                        def evaluate_arm(kind,ridge,strength,base_on=True):
                            key=(kind,ridge)
                            if key not in dist:dist[key]=distance2(r,prot,directions[key][mask])
                            return float(score((base if base_on else 0.)-.5*strength*dist[key],xy,truth,w))
                        results=dict(unit=float(score(base,xy,truth,w)),supervised=evaluate_arm('true',tr,tt),
                                     fixed_supervised=evaluate_arm('true',1.,4.),pca=evaluate_arm('pca',0.,pt),
                                     pca_at_true=evaluate_arm('pca',0.,tt),metric_only=evaluate_arm('true',tr,tt,False))
                        for j in range(PERMS):
                            results[f'perm{j}']=evaluate_arm(f'perm{j}',rr,rt)
                            results[f'perm_at_true{j}']=evaluate_arm(f'perm{j}',tr,tt)
                        rows.extend((*meta,kind,0.,0.,v) for kind,v in results.items())
        print(f'{mode} B{b}F{f} done',flush=True)
    return pd.DataFrame(rows,columns=['building','floor','phone','draw','K','method','ridge','strength','mde']),counts


def main(data,frozen,out,stage):
    out.mkdir(exist_ok=True,parents=True)
    train=read_floors(data,'trainingData.csv');meta=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID','TIMESTAMP'])
    phones,times=meta.PHONEID.to_numpy(),meta.TIMESTAMP.to_numpy()
    if stage=='train':
        a,counts=evaluate(train,None,phones,times,None,'source')
        floor=a.groupby(['building','floor','phone','method','ridge','strength'],as_index=False).mde.mean()
        floor.to_csv(out/'metric_source.csv',index=False)
        group=floor.groupby(['building','floor','method','ridge','strength']).mde.mean().groupby(['building','method','ridge','strength']).mean()
        choices={}
        for held in [*sorted(a.building.unique()),'all']:
            risk=(group if held=='all' else group.drop(index=held,level='building')).groupby(['method','ridge','strength']).mean()
            choices[str(held)]={}
            for kind in ('true','perm','pca'):
                scores=risk.loc[kind];pair=min(scores.index,key=lambda pair:(round(float(scores.loc[pair]),12),pair[1],-pair[0]))
                choices[str(held)][kind]=[float(v) for v in pair]
        record=dict(choices=choices,ridges=RIDGES,strengths=STRENGTHS,sha256=HASHES,source_tasks=counts,
                    estimator='Ridge of xy on -110-filled RSS, center independently per historical floor, equal within-floor position weights, all repeats; ridge times trace(Crr)/A. Whiten within-H projected covariance. New/dropped H AP gets zero projection.',
                    controls='PCA and three distinct-position-permuted coordinates within each floor; means across independent permutation losses. Each control independently source-tuned; also evaluated at supervised settings.',
                    objective='Temporal + device-isolated UJI training tasks, equal floor/device/draw/K within building; exclude all held-building outcomes. Ties within 1e-12 prefer zero/weaker correction, then stronger ridge.')
        (out/'metric_frozen.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(choices,flush=True)
    else:
        choices=json.loads((out/'metric_frozen.json').read_text())['choices'];official=read_floors(data,'validationData.csv')
        for stage,manifest in [('official','manifest.json'),('phone','device_stress_design.json')]:
            design=json.loads((frozen/manifest).read_text());events,_=evaluate(train,official,phones,times,design,stage,choices)
            events.drop(columns=['ridge','strength']).to_csv(out/f'metric_{stage}.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['train','test'])
    for name in ('data','frozen','out'):p.add_argument(name,type=Path)
    args=p.parse_args();main(args.data,args.frozen,args.out,args.stage)
