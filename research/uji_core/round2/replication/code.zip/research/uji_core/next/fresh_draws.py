"""Fresh support-order validation only. Do not fit or select a model."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, fit_map, historical_prior
from residual_probe.episode_rows import nested_rows
from ..inverse import squared, order, vote
from ..protocol import BUDGETS, read_floors, split_rows, position_weights, HASHES
from .external_floor_wknn import GapReference
from .paired_map_wknn import group_ids

DRAWS=range(10,50)


def checksum(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def freeze(data,original,gap_params,mapped_params,output):
    public=Path(__file__).resolve().parents[3]/'refi.py'
    verified={public:'c27cf82d35aecb8fd16cad4d4f8711a94533a34cd9c700c053b22d190500e84f',
              gap_params:'807959e76729adc74db79bf0801cfd7de6e7d73287bea5d6563123a6a1ba279f',
              mapped_params:'09037ad1bb36b8f700f9ac202c0ef2421ea4c5f6ca477257458177fb7ea0f516'}
    if any(checksum(f)!=expected for f,expected in verified.items()):
        raise ValueError('Deployment or a frozen reference changed')
    train,valid=(read_floors(data,name) for name in ('trainingData.csv','validationData.csv'))
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    stress={(r['building'],r['floor']):r for r in json.loads((original/'device_stress_design.json').read_text())['events']}
    old={(r['building'],r['floor'],r['draw']):r for r in json.loads((original/'manifest.json').read_text())['episodes']}
    jobs=[]
    for (b,f),t in train.items():
        id2local={v:i for i,v in enumerate(t['ids'])}
        for mode in ('official','phone'):
            if mode=='official':
                qids=valid[b,f]['ids'].tolist();device=None
                draw=lambda d:split_rows(t,b,f,d)[0]
                assert qids==old[b,f,0]['query_ids']
                legacy=[old[b,f,i]['support_order'] for i in range(10)]
            else:
                enrollment=stress[b,f];qids=enrollment['query_ids'];device=enrollment['phone']
                qr=[id2local[v] for v in qids];qxy=set(map(tuple,t['xy'][qr]))
                keep=[i for i in range(len(t['ids'])) if phones[t['ids'][i]]!=device and tuple(t['xy'][i]) not in qxy]
                draw=lambda d:nested_rows(t['xy'],keep,BUDGETS,0,f'device-stress-v1/{b}/{f}/{device}/support/{d}')['support_rows'][20]
                legacy=enrollment['support_orders']
            if [t['ids'][draw(i)].tolist() for i in range(10)]!=legacy:
                raise ValueError('New seed generator does not replay previous support orders')
            orders=[t['ids'][draw(i)].tolist() for i in DRAWS]
            if len(set(map(tuple,legacy+orders)))!=50:raise ValueError('Repeated max-budget order')
            jobs.append(dict(mode=mode,building=b,floor=f,device=device,qids=qids,orders=orders))
    metadata=dict(sha256={p.name:s for p,s in verified.items()},data_sha256=HASHES,new_draws=list(DRAWS),
       naming='Exact existing official or device seed namespace. 0..9 replay verified only, excluded from estimates. '
       'Original target Q IDs, floor, phone and eligibility held fixed. Accidental matches of short prefixes are retained.',
       estimators='Public gap2 half10 field + unit 40U propagation + Tobit(12,-85); dual-regime LOBO WKNN; same-map LOBO WKNN. '
       'CIs: 10,000 nested paired bootstraps of 40 support orders within each fixed floor; two-sided percentile at each prespecified K, '
       'building equally weights its floors. These are conditional on observed queries/buildings and not population guarantees.',
       gap_wknn=json.loads(gap_params.read_text())['selected'],map_k=json.loads(mapped_params.read_text())['choices'],
       jobs=jobs)
    output.mkdir(parents=True,exist_ok=True)
    (output/'freeze.json').write_text(json.dumps(metadata,separators=(',',':'))+'\n')


def score(data,out,mode):
    config=json.loads((out/'freeze.json').read_text())
    train,valid=(read_floors(data,n) for n in ('trainingData.csv','validationData.csv'))
    ph=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    records=[];qa=[]
    for j in [row for row in config['jobs'] if row['mode']==mode]:
        b,f,dev=j['building'],j['floor'],j['device']
        trainfloor=train[b,f];ix={v:i for i,v in enumerate(trainfloor['ids'])}
        if mode=='phone':
            qr=[ix[r] for r in j['qids']]
            q={key:z[qr] for key,z in trainfloor.items()}
        else:q=valid[b,f]
        assert q['ids'].tolist()==j['qids']
        weights=position_weights(q['xy'])
        hs=[];gaps=[]
        for (bb,ff),h in sorted(train.items()):
            if bb!=b or ff==f:continue
            if dev is not None:h={key:z[ph[h['ids']]!=dev] for key,z in h.items()}
            if len(h['ids']):hs.append(h);gaps.append(abs(ff-f))
        rep,alpha,n=config['gap_wknn'][str(b)]['gap_fit']
        n_map=config['map_k'][str(b)]
        bank=GapReference(hs,gaps,rep);qmatch=bank.query(q['rss'])
        base,hxy=historical_prior(hs,10.,.5,gaps)
        ord_xy,hid=group_ids(np.vstack([h['xy'] for h in hs]),np.concatenate([h['ids'] for h in hs]))
        np.testing.assert_array_equal(ord_xy,hxy)
        for seed,ids in zip(DRAWS,j['orders']):
            for k in BUDGETS:
                sel=[ix[r] for r in ids[:k]]
                s={key:z[sel] for key,z in trainfloor.items()}
                wk=bank.event(qmatch,s,[alpha])[alpha,n]
                mask=bank.hseen | (s['rss']!=100).any(0)
                proto,xy=tpm.calibrate((base[:,mask],hxy),dict(rss=s['rss'][:,mask],xy=s['xy']),(40.,1.))
                pp=FingerprintMap(proto,xy,mask).predict(q['rss'])
                _,sid=group_ids(s['xy'],s['ids'])
                dist=squared(tpm.dbm(q['rss'][:,mask])+110.,proto+110.)
                nearest=order(dist,np.r_[hid,sid],n_map)
                ref=vote(np.take_along_axis(dist,nearest,axis=1),xy[nearest]-xy[0],mask.sum())[0]+xy[0]
                err=lambda p:float(weights@np.linalg.norm(p-q['xy'],axis=1))
                records.append(dict(mode=mode,building=b,floor=f,draw=seed,K=k,public=err(pp),
                                    floor_wknn=err(wk),mapped_wknn=err(ref)))
                if seed==10 and k in (1,20):
                    direct=fit_map(hs,s,floor_gaps=gaps).predict(q['rss'])
                    diff=float(np.abs(direct-pp).max())
                    if diff>1e-8:raise ValueError('Public deployment entry mismatch')
                    qa.append(dict(building=b,floor=f,K=k,max_coordinate_diff=diff))
    pd.DataFrame(records).to_csv(out/(mode+'.csv'),index=False)
    pd.DataFrame(qa).to_csv(out/(mode+'_parity.csv'),index=False)


def summarize(out):
    rng=np.random.default_rng(261101)
    buildings=[];floors=[]; summary={}
    for mode in ('official','phone'):
        d=pd.read_csv(out/(mode+'.csv'))
        if len(d)!=2600 or not d[['public','floor_wknn','mapped_wknn']].notna().all().all():raise ValueError(mode)
        fdata=d.groupby(['building','floor','K'])[['public','floor_wknn','mapped_wknn']].mean()

        results=[]
        for b,g in d.groupby('building'):
            curves=[];boots=[]
            for floor_id,fg in g.groupby('floor'):
                a=fg.sort_values(['draw','K'])[['public','floor_wknn','mapped_wknn']].to_numpy().reshape(40,5,3)
                floor_curve=a.mean(0)
                floor_boot=a[rng.integers(40,size=(10000,40))].mean(1)
                curves.append(floor_curve);boots.append(floor_boot)
                for i,k in enumerate(BUDGETS):
                    row=dict(mode=mode,building=b,floor=floor_id,K=k,
                             public=floor_curve[i,0],floor_wknn=floor_curve[i,1],mapped_wknn=floor_curve[i,2])
                    for col,label in [(1,'gap'),(2,'same_map')]:
                        row[label]=floor_curve[i,0]-floor_curve[i,col]
                        row[label+'_lo'],row[label+'_hi']=np.quantile(floor_boot[:,i,0]-floor_boot[:,i,col],[.025,.975])
                    if i>0:
                        row['adjacent']=floor_curve[i,0]-floor_curve[i-1,0]
                        row['adjacent_lo'],row['adjacent_hi']=np.quantile(floor_boot[:,i,0]-floor_boot[:,i-1,0],[.025,.975])
                    floors.append(row)
            curve=np.mean(curves,axis=0); boot=np.mean(boots,axis=0)
            for i,k in enumerate(BUDGETS):
                row=dict(mode=mode,building=b,K=k,public=curve[i,0],floor_wknn=curve[i,1],mapped_wknn=curve[i,2])
                contrasts={'gap':(curve[i,0]-curve[i,1],boot[:,i,0]-boot[:,i,1]),
                           'same_map':(curve[i,0]-curve[i,2],boot[:,i,0]-boot[:,i,2])}
                if i>0:
                    contrasts['adjacent']=(curve[i,0]-curve[i-1,0],boot[:,i,0]-boot[:,i-1,0])
                for name,(center,sample) in contrasts.items():
                    row[name]=center;row[name+'_lo'],row[name+'_hi']=np.quantile(sample,[.025,.975])
                results.append(row)
        buildings.extend(results)
        br=pd.DataFrame(results);fc=fdata.public.unstack('K')
        summary[mode]=dict(episodes=len(d),building_decreases=int((br.adjacent<0).sum()),building_transitions=12,
                           beats_floor_wknn=int((br.gap<0).sum()),beats_same_map=int((br.same_map<0).sum()),
                           floor_K_beats_wknn=int((fdata.public<fdata.floor_wknn).sum()),
                           floor_K_beats_mapped=int((fdata.public<fdata.mapped_wknn).sum()),
                           floor_adjacent_decreases=int((np.diff(fc,axis=1)<0).sum()),
                           floors_decreasing_at_every_K=int((np.diff(fc,axis=1)<0).all(1).sum()),
                           floors_improve_K1_to_20=int((fc[20]<fc[1]).sum()))
    pd.DataFrame(buildings).to_csv(out/'building_curves.csv',index=False)
    pd.DataFrame(floors).to_csv(out/'floor_curves.csv',index=False)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['freeze','official','phone','summarize'])
    for name in ('data','original','gap_params','mapped_params','out'):p.add_argument(name,type=Path)
    a=p.parse_args()
    if a.stage=='freeze':freeze(a.data,a.original,a.gap_params,a.mapped_params,a.out)
    elif a.stage=='summarize':summarize(a.out)
    else:score(a.data,a.out,a.stage)
