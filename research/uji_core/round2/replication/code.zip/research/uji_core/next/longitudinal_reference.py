"""Frozen field and H+S WKNN baselines for same-floor month-to-month transfer.

Run 'prepare' first to use early trn rows only and freeze both WKNN choices,
then 'validation'. Request lagged held stages separately after research freeze.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import smooth_history
from .external import METRES_PER_UJI_UNIT
from .external_floor_wknn import GapReference
from .longitudinal import STAGES, SHA256, episodes
from ..study import NEIGHBORS


def measure(archive,stage,settings):
    records=[]; current=None; last_q=None
    for m,h,s,q in episodes(archive,stage):
        env=m['month'],m['floor']
        refs=set(r for r,n in settings.values())
        if env!=current:
            current=env; last_q=None
            hist=dict(h,xy=h['xy']/METRES_PER_UJI_UNIT,ids=h['ids'].astype(np.int64))
            banks={r:GapReference([hist],[1],r) for r in refs}
            hseen=(h['rss']!=100).any(0)
            prior,hxy=smooth_history(tpm.history_map([hist],None,None),10.,.5)
        tag=m['draw'] if stage=='source' else 0
        if tag!=last_q:
            matched={r:bank.query(q['rss']) for r,bank in banks.items()}
            last_q=tag
        support=dict(s,xy=s['xy']/METRES_PER_UJI_UNIT,ids=s['ids'].astype(np.int64))
        estimates={}
        for r,bank in banks.items():
            neighbors=bank.event(matched[r],support,[0.])
            for name,(ref,k) in settings.items():
                if ref==r: estimates[name]=neighbors[0.,k]
        visible=hseen|(s['rss']!=100).any(0)
        ss=dict(rss=s['rss'][:,visible],xy=support['xy'])
        mapped,xy=tpm.calibrate((prior[:,visible],hxy),ss,(40.,1.))
        prob=tpm.tobit_weights(q['rss'][:,visible],mapped,12.,-85.)
        estimates['fixed_refi']=prob@(xy-xy[0])+xy[0]
        for name,loc in estimates.items():
            errors=np.linalg.norm(loc*METRES_PER_UJI_UNIT-q['xy'],axis=1)
            if not np.isfinite(errors).all():raise ValueError('Invalid localization output')
            records.append(dict(stage=stage,month=m['month'],floor=m['floor'],draw=m['draw'],
                                K=m['K'],method=name,n_queries=len(errors),mde=q['weights']@errors))
    return pd.DataFrame(records)


def main(archive,output,stage):
    output.mkdir(exist_ok=True,parents=True)
    cfg=output/'longitudinal_wknn_parameters.json'
    if stage=='prepare':
        opts={f'{r}_{k}':(r,k) for r in ('raw','prototype') for k in NEIGHBORS}
        src=measure(archive,'source',opts)
        src.to_csv(output/'longitudinal_reference_source.csv',index=False)
        risk=src[src.method!='fixed_refi'].groupby('method').mde.mean()
        winner=min(opts,key=lambda a:risk[a])
        config=dict(sha256=SHA256,unit='m',family='WKNN over all H scans or their per-XY means plus R1 S; k=1,3,7,15. '
                    'Uniform early month/floor/draw/K. Original CSV IDs resolve ties. Late and validation months excluded.',
                    settings=dict(tuned_wknn=opts[winner],uji_wknn=['prototype',3]),source_risks=risk.to_dict())
        cfg.write_text(json.dumps(config,indent=2)+'\n')
    else:
        settings=json.loads(cfg.read_text())['settings']
        risk=measure(archive,stage,settings)
        risk.to_csv(output/f'longitudinal_reference_{stage}.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive',type=Path);p.add_argument('output',type=Path)
    p.add_argument('stage',choices=['prepare','validation','late','late_A5'])
    a=p.parse_args(); main(a.archive,a.output,a.stage)
