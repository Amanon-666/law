"""Remove a fraction of implied AP-count evidence from the fixed receiver score.

Detected RSS below −85 dBm exists in UJI. Accordingly, the existing normal
detected-value score plus a nondetection CDF is not asserted to be a perfectly
truncated generative law. The Poisson-binomial correction is an intervention
on its implied independent detection-count channel, not an exact proof of a
conditional observation model for UJI.
"""
import numpy as np
from scipy.special import log_ndtr,softmax
from .map_variance import QueryTerms


def log_count_probabilities(prototypes, max_count):
    """For each candidate, log Pr(N=k), k=0..max_count. No tail renormalization."""
    m=np.asarray(prototypes,dtype=float)
    if m.ndim!=2 or not isinstance(max_count,(int,np.integer)) or not 0<=max_count<=m.shape[1]:
        raise ValueError('Expected a candidate x AP matrix and valid maximum count')
    log_on=log_ndtr((m+85.)/12.).T.copy()
    log_off=log_ndtr((-85.-m)/12.).T.copy()
    dp=np.full((len(m),max_count+1),-np.inf)
    dp[:,0]=0.
    for ap,(on,off) in enumerate(zip(log_on,log_off)):
        hi=min(ap+1,max_count)
        # Both right-hand arrays are calculated from the previous AP state.
        if hi:
            dp[:,1:hi+1]=np.logaddexp(dp[:,1:hi+1]+off[:,None],dp[:,:hi]+on[:,None])
        dp[:,0]+=off
    return dp


def components(field,query):
    q=np.asarray(query,dtype=float)
    if q.ndim!=2 or q.shape[1]!=len(field.visible) or not np.isfinite(q).all():
        raise ValueError('Expected a finite aligned query matrix')
    r=q[:,field.visible]
    counts=(r!=100).sum(1)
    base=QueryTerms(r).scores(field.prototypes,np.array([[144.]]))
    table=log_count_probabilities(field.prototypes,int(np.max(counts,initial=0)))
    return base,table[:,counts].T


def predict(field,query,gamma):
    if not np.isfinite(gamma) or not 0<=gamma<=1:raise ValueError('Expected gamma in [0,1]')
    base,logcount=components(field,query)
    p=softmax(base-gamma*logcount,axis=1)
    return p@(field.xy-field.xy[0])+field.xy[0]
