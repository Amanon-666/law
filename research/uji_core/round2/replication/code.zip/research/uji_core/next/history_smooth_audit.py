"""Paired content-learning attribution and fixed strong-smoothing controls."""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
from scipy.special import expit
from ..protocol import BUDGETS,read_floors
from ..summarize import INDEX
from .history_smooth_study import task_data,prepare_case,evaluate_prior
from .variance_pool_audit import summary


def main(data,frozen,out,floor_reference):
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    fits=json.loads((out/'fit.json').read_text())['folds']
    fs=[dict(building=b,floor=f) for b,f in tr]
    allrows=[];rates=[]
    for mode,reg,jobs in [('official','period',fs),('phone','device',json.loads((frozen/'device_stress_design.json').read_text())['events'])]:
        controls=[]
        for j in jobs:
            b,f=j['building'],j['floor']
            bank,t,q,orders=task_data(tr,va,phones,j,reg,False)
            cfg=fits[str(b)]['fits']
            g=expit(bank.features@np.asarray(cfg['full']['theta']))
            can_move=np.abs(bank.contrast)>1.
            rates.append(dict(mode=mode,building=b,floor=f,active_cells=int(can_move.sum()),
                  scalar=float(expit(cfg['scalar']['theta'][0])),
                  **{f'learned_gate_p{v}':float(np.percentile(g[can_move],v)) for v in (10,50,90)}))
            priors={name:bank.raw+level*bank.contrast for name,level in [('fixed0',0.),('fixed75',.75),('fixed1',1.)]}
            for draw,order in enumerate(orders):
                for k in BUDGETS:
                    case=prepare_case(bank,t,order[:k],q,np.ones_like(bank.hseen))
                    controls.append(dict(building=b,floor=f,draw=draw,K=k,
                                  **{n:evaluate_prior(p,case,False) for n,p in priors.items()}))
        extra=pd.DataFrame(controls)
        extra.to_csv(out/(mode+'_fixed_controls.csv'),index=False)
        d=pd.read_csv(out/(mode+'.csv')).merge(extra,on=INDEX,validate='one_to_one')
        if floor_reference:
            wk=pd.read_csv(floor_reference/('floor_wknn_'+mode+'.csv')).query("method=='gap_fit'").set_index(INDEX).mde
            d=d.set_index(INDEX).join(wk.rename('floor_wknn'),validate='one_to_one').reset_index()
        if len(d)!=650 or not np.isfinite(d.to_numpy()).all():raise ValueError('Incomplete comparison')
        refs=['half','scalar','single_best','physical','shuffled','AP_mean','variance_only','contrast_coverage',
              'remove_variance','remove_contrast_coverage','fixed0','fixed75','fixed1']+(['floor_wknn'] if floor_reference else [])
        allrows+=summary(d,mode,'full',refs)
        allrows+=summary(d,mode,'scalar',['half','fixed75','fixed1'])
        allrows+=summary(d,mode,'single_best',['scalar','half','fixed75'])
    pd.DataFrame(allrows).to_csv(out/'tiers.csv',index=False)
    pd.DataFrame(rates).to_csv(out/'gate_ranges.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','out'):p.add_argument(n,type=Path)
    p.add_argument('--floor-reference',type=Path)
    a=p.parse_args();main(a.data,a.frozen,a.out,a.floor_reference)
