"""Fit one integrated scan-offset comparator using only source localization losses.

python -m research.uji_core.next.match DATA FROZEN_RESULTS OUTPUT
σ, θ define the existing censor-aware score. A query-scanner readout offset
has b~N(0,τ²) shared across its detected RSS values; the detection process
is left unchanged. Its Gaussian integral depends on the candidate only through
sum of detected RSS residuals and their squared sum. The log determinant is
constant across candidates of a query and cancels in the location posterior.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import log_ndtr

from ..protocol import HASHES, read_floors
from .match_episodes import eval_tasks, maps, source_tasks

SIGMA = (12.,8.,16.,24.)
THRESHOLD = (-85.,-95.,-75.)
TAU = (0.,3.,6.,12.,np.inf)
DISCOUNT = (1.,.5,.25,0.)
TEMP = (1.,.5,2.,4.)
DEFAULT = (12.,-85.,0.,1.,1.)
FIXED = (12.,-85.,6.,1.,1.)


def terms(query,m):
    seen = (query != 100).astype(float)
    # Shift to improve conditioning; the residual between detected r and m is unchanged.
    r = np.where(seen != 0, np.asarray(query,dtype=float)+75., 0.)
    p = m + 75.
    count = seen.sum(1,keepdims=True)
    total = r.sum(1,keepdims=True) - seen @ p.T
    energy = (r*r).sum(1,keepdims=True) + seen @ (p*p).T - 2*r@p.T
    return dict(n=count, residual2=np.maximum(0.,energy), sum2=total**2, missed=1.-seen)


def detected_score(t,sigma,tau):
    rss = -t['residual2'] / (2*sigma*sigma)
    if tau == 0:
        return rss
    denominator = t['n'] + (sigma/tau)**2
    improvement = np.divide(t['sum2'],denominator,out=np.zeros_like(t['sum2']),where=denominator>0)
    return rss + improvement/(2*sigma*sigma)


def risk(logits, xy, truth, weights):
    # Any leading selection axes are preserved; the last axes are query, location.
    p = np.exp(logits-logits.max(axis=-1,keepdims=True))
    pred = (p @ xy)/p.sum(axis=-1,keepdims=True)
    return np.linalg.norm(pred-truth,axis=-1) @ weights


def event_loss(e, choices=None):
    m = e['prototypes']
    t = terms(e['query'],m)
    center = e['xy'][0]
    args = (e['xy']-center,e['truth']-center,e['weight'])
    if choices is None:
        result = np.empty((len(SIGMA),len(THRESHOLD),len(TAU),len(DISCOUNT),len(TEMP)))
        for i, sigma in enumerate(SIGMA):
            r = np.stack([detected_score(t,sigma,tau) for tau in TAU])
            for j,theta in enumerate(THRESHOLD):
                miss = t['missed'] @ log_ndtr((theta-m)/sigma).T
                score = r[:,None] + np.array(DISCOUNT)[None,:,None,None]*miss
                score = score[:,:,None] / np.array(TEMP)[None,None,:,None,None]
                result[i,j] = risk(score,*args)
        return result
    out = {}
    for label,(sigma,theta,tau,discount,temp) in choices.items():
        miss = t['missed'] @ log_ndtr((theta-m)/sigma).T
        logits = (detected_score(t,sigma,tau)+discount*miss)/temp
        out[label] = float(risk(logits,*args))
    return out


def serial(params):
    return ['profile' if np.isinf(x) else float(x) for x in params]


def decode(values):
    return [np.inf if x=='profile' else x for x in values]


def select(train,phones,times,out):
    buildings = sorted({b for b,_ in train})
    averages = {b:[] for b in buildings}
    designs = []
    floor_gaps = []
    for (b,f) in train:
        tasks = list(source_tasks(train,phones,times,b,f))
        losses = []
        for phone,history,draws in tasks:
            details = dict(building=b,floor=f,query_phone=phone,
                           last_H_ts=int(max(times[h['ids']].max() for h in history)),draws=[])
            for draw,order,q in draws:
                sids = train[b,f]['ids'][order]
                assert max(times[sids]) < min(times[q['ids']])
                assert details['last_H_ts'] < min(times[q['ids']])
                details['draws'].append(dict(draw=draw,S=sids.tolist(),Q=q['ids'].tolist(),
                    last_S_ts=int(max(times[sids])),first_Q_ts=int(min(times[q['ids']]))))
            designs.append(details)
            # Each phone/floor has exactly 4 draws and 5 budgets.
            total = None
            for e in maps(train,b,f,[(phone,history,draws)]):
                loss = event_loss(e)
                total = loss if total is None else total + loss
            losses.append(total/(len(draws)*5))
        if losses:
            averages[b].append(np.mean(losses,axis=0))
        else:
            floor_gaps.append([b,f])
        print(f'Source B{b} F{f}: {len(tasks)} eligible phones',flush=True)
    if not all(averages.values()):
        raise ValueError('No valid source environment for a building')
    np.savez_compressed(out/'source_risk_grid.npz',
                        **{f'B{b}':np.mean(floors,axis=0) for b,floors in averages.items()})
    with (out/'source_rows.json').open('w') as fh:
        json.dump(designs,fh)
    selected = {}
    grid = (SIGMA,THRESHOLD,TAU,DISCOUNT,TEMP)
    fixed_offset = TAU.index(FIXED[2])
    for held in buildings:
        arr = np.mean([np.mean(v,axis=0) for b,v in averages.items() if b!=held],axis=0)
        def best(candidates):
            ix = min(candidates,key=lambda v:arr[v])
            return tuple(g[i] for g,i in zip(grid,ix))
        ix = list(np.ndindex(arr.shape))
        global_rule = best([x for x in ix if x[2]==0])
        fixed_tau_retrained = best([x for x in ix if x[2]==fixed_offset])
        tau_only = best([x for x in ix if all(x[i]==0 for i in (0,1,3,4))])
        joint = best(ix)
        selected[str(held)] = {n:serial(v) for n,v in dict(
            default=DEFAULT, fixed_offset=FIXED, global_fit=global_rule,
            default_no_misses=(12.,-85.,0.,0.,1.),
            global_restore_misses=(*global_rule[:3],1.,global_rule[4]),
            fixed_offset_fit=fixed_tau_retrained, offset_only_fit=tau_only, joint_fit=joint,
            remove_offset=(joint[0],joint[1],0.,joint[3],joint[4])).items()}
    record = dict(source='Each eligible phone: latest half of its training-floor timestamps; distinct 12 Q positions from that phone; non-query phones and strictly earlier timestamps only in H/S. Four independent draws, 20 nested positions in S; no S/Q XY overlaps. At least 3 H coordinates. All train CSV (times are recorded timestamp, not month-scale simulation).',
                  weight='Equal source buildings, eligible floors, eligible phones, draws, K, Q positions. Entire target building omitted from coefficient selection.',
                  source_csv_sha256=HASHES['trainingData.csv'],excluded_ineligible_floors=floor_gaps,
                  source_phone_floor_count=len(designs),K=[1,3,5,10,20],
                  likelihood='Detected RSS share one Gaussian readout shift per scan. Missing AP scores use separate detected-status threshold and optional discount, before common temperature. Offset here is on the RSS reporting channel, not a receiver detection-threshold shift. Profile denotes flat-offset limit.',
                  grid=dict(sigma=SIGMA,threshold=THRESHOLD,tau=serial(TAU),discount=DISCOUNT,temperature=TEMP),
                  control='global_fit searches every identical score setting except tau=0. fixed_offset_fit refits all common nuisance parameters with tau=6. Offset-only fit fixes all other parameters at default. Tie preference is listed grid order.',
                  diagnostic='default_no_misses and global_restore_misses are post hoc single-weight interventions with no fitting or model selection.',
                  selections=selected)
    path = out/'selection.json'
    path.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    return {b:{n:decode(v) for n,v in arms.items()}
            for b,arms in json.loads(path.read_text())['selections'].items()}


def main(data,frozen,out):
    out.mkdir(parents=True,exist_ok=True)
    train = read_floors(data,'trainingData.csv')
    meta = pd.read_csv(data/'trainingData.csv',usecols=['PHONEID','TIMESTAMP'])
    phones = meta.PHONEID.to_numpy()
    choices = select(train,phones,meta.TIMESTAMP.to_numpy(),out)
    official = read_floors(data,'validationData.csv')
    for mode,name in [('official','manifest.json'),('device','device_stress_design.json')]:
        manifest = json.loads((frozen/name).read_text())
        rows = []
        for b,f in train:
            for e in maps(train,b,f,eval_tasks(train,official,phones,manifest,b,f,mode)):
                losses = event_loss(e,choices[str(b)])
                rows.append({**{k:e[k] for k in ['building','floor','draw','K','phone']},**losses})
        result = pd.DataFrame(rows)
        if len(result)!=650 or not np.isfinite(result[list(choices['0'])].to_numpy()).all():
            raise ValueError(f'Incomplete evaluation {mode}')
        result.to_csv(out/f'{mode}_events.csv',index=False)
        print(mode,result.groupby(['building','K'])[list(choices['0'])].mean().round(3),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('data','frozen','out'):
        p.add_argument(key,type=Path)
    a=p.parse_args()
    main(a.data,a.frozen,a.out)
