"""Frozen conditional detected-RSS mean control. NumPy/SciPy, H/S/Q only.

fit_conditional_map returns a reusable fitted map in the input XY system.
Use coordinate_units_per_uji=1 for UJI-equivalent inputs (including already
converted external inputs) or .766 for raw metre inputs; do not convert twice.
Only the detected Gaussian's mean at historical candidate rows changes.
"""
from dataclasses import dataclass

import numpy as np
from scipy.special import log_ndtr, softmax

from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, historical_prior

EXTERNAL_GATE = (0., .21941321218335094, 0.)
EXTERNAL_SCALAR = (.04228933469458107,) * 3
BAND_EDGES = (.2, .8)


def historical_moments(histories, gaps):
    """H observed-space mean, XY, actual detection frequency and detected mean."""
    m, xy = historical_prior(histories, 10., .5, gaps)
    masks = [dict(rss=(h['rss'] != 100).astype(float), xy=h['xy']) for h in histories]
    numerators = [dict(rss=np.where(h['rss'] != 100, (h['rss'].astype(float)+110.) / 110., 0.),
                       xy=h['xy']) for h in histories]
    prob, px = historical_prior(masks, 10., .5, gaps)
    num, nx = historical_prior(numerators, 10., .5, gaps)
    if not np.array_equal(xy, px) or not np.array_equal(xy, nx):
        raise ValueError('Incompatible H moment positions')
    rate = np.divide(num, prob, out=np.zeros_like(num), where=prob > 0.)
    detected = np.where(prob > 0., -110. + 110.*rate, m)
    return m, xy, prob, detected


@dataclass(frozen=True)
class ConditionalMeanMap:
    base: FingerprintMap
    h_difference: np.ndarray
    h_bands: np.ndarray
    coefficients: tuple

    def predict(self, query_rss, coefficients=None):
        """Predict coordinates; optional coefficients allow matched frozen controls."""
        g = np.asarray(self.coefficients if coefficients is None else coefficients, dtype=float)
        if g.shape != (3,) or not np.isfinite(g).all() or np.any((g<0.) | (g>1.)):
            raise ValueError('Expected three convex weights')
        query = np.asarray(query_rss, dtype=float)
        if query.ndim!=2 or query.shape[1]!=len(self.base.visible) or not np.isfinite(query).all():
            raise ValueError('Expected aligned, finite query RSS')
        q = query[:,self.base.visible]
        m = self.base.prototypes
        nh = len(self.h_difference)
        d = self.h_difference
        detected = m.copy()
        detected[:nh] += g[self.h_bands]*(np.clip(m[:nh]+d,-110.,0.)-m[:nh])
        seen = (q != 100).astype(float)
        r = np.where(q!=100, q+75., 0.)
        mu = detected+75.
        logp = (r@mu.T - .5*seen@(mu*mu).T)/144. + (1.-seen)@log_ndtr((-85.-m)/12.).T
        xy = self.base.xy
        return softmax(logp,axis=1)@(xy-xy[0])+xy[0]


def fit_conditional_map(histories, support, *, floor_gaps=None, coordinate_units_per_uji=1., coefficients=EXTERNAL_GATE):
    """Fit the original gap2 half10/40 map; retain only H-based extra moments.

    histories and support contain aligned rss[N,A],xy[N,2] arrays. 100 denotes
    nondetection. floor_gaps, when supplied, are aligned original floor-index
    differences. New APs visible only in S keep their original means.
    """
    scale = float(coordinate_units_per_uji)
    if not np.isfinite(scale) or scale <= 0.:raise ValueError('Invalid XY unit conversion')
    ss = np.asarray(support['rss'],float)
    if ss.ndim!=2:raise ValueError('Expected support [N,A], including [0,A] for K=0')
    def prepare(sample):
        r = np.asarray(sample['rss'],float);x = np.asarray(sample['xy'],float)
        if r.ndim!=2 or r.shape[1]!=ss.shape[1] or x.shape!=(len(r),2) or not np.isfinite(r).all() or not np.isfinite(x).all():
            raise ValueError('Invalid coordinates or RSS catalogue')
        return dict(rss=r,xy=x/scale)
    h = [prepare(v) for v in histories]
    if floor_gaps is not None:
        gaps = np.asarray(floor_gaps,float)
        if gaps.shape!=(len(h),) or not np.isfinite(gaps).all():raise ValueError('Incomplete floor gaps')
        gaps = gaps[[len(v['rss'])>0 for v in h]]
    else:gaps=None
    h = [v for v in h if len(v['rss'])]
    if not h:raise ValueError('Need historical scans')
    s = prepare(support)
    mask = np.logical_or.reduce([(v['rss']!=100).any(0) for v in [*h,s]])
    m,xy,p,c = historical_moments(h,gaps)
    original,locations = tpm.calibrate((m[:,mask],xy),dict(rss=s['rss'][:,mask],xy=s['xy']),(40.,1.))
    bands = np.searchsorted(BAND_EDGES,p[:,mask],side='right')
    return ConditionalMeanMap(FingerprintMap(original,locations*scale,mask),c[:,mask]-m[:,mask],bands,tuple(coefficients))
