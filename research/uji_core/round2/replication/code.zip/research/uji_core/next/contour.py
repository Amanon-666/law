"""A single kernel for local support propagation along a historical signal field.

For AP a, augment xy with its predicted old signal level. The kernel is a
product of two valid Gaussian kernels. A fixed source-learned scale governs
how far a change crosses old signal contours. beta=0 gives spatial-only GP.
"""
import argparse
from itertools import product
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap,smooth_history
from ..protocol import BUDGETS,SEEDS,read_floors,split_rows,position_weights
from ..smooth_scale import local_rows
from residual_probe.episode_rows import nested_rows
from .transport import source_design

LENGTH=(20.,40.,80.)
BETA=(0.,.25,1.,4.)
GRID=tuple(product(LENGTH,BETA))


class ContourMap:
    def __init__(self,hs,unit=1.):
        self.unit=unit
        self.m,self.xy=smooth_history(tpm.history_map(hs,None,None),10.*unit,.5)
        self.mask=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])

    def prepare(self,s):
        mask=self.mask | (s['rss']!=100).any(0)
        sy,sx=tpm.position_map(tpm.dbm(s['rss'][:,mask]),s['xy'])
        m=self.m[:,mask]
        sm=tpm.lookup(sx,self.xy,m)
        return mask,np.vstack((self.xy,sx)),sy,m,(sy-sm).T,cdist(self.xy,sx,'sqeuclidean')/self.unit**2,cdist(sx,sx,'sqeuclidean')/self.unit**2,((m.T[:,:,None]-sm.T[:,None,:])/12.)**2,((sm.T[:,:,None]-sm.T[:,None,:])/12.)**2

    @staticmethod
    def model(parts,ell,beta,shuffle=False):
        mask,xy,sy,m,r,ds,ss,ds_r,ss_r=parts
        if shuffle:
            rng=np.random.default_rng(131)
            ix=rng.permutation(len(r))
            ds_r,ss_r=ds_r[ix],ss_r[ix]
        if beta:
            cross=np.exp(-.5*(ds[None]/ell**2+beta*ds_r))
            kss=np.exp(-.5*(ss[None]/ell**2+beta*ss_r))+np.eye(len(sy))
            alpha=np.linalg.solve(kss,r[:,:,None])[:,:,0]
            update=np.einsum('axk,ak->xa',cross,alpha)
        else:
            cross=np.exp(-.5*ds/ell**2)
            kss=np.exp(-.5*ss/ell**2)+np.eye(len(sy))
            update=cross@np.linalg.solve(kss,r.T)
        return FingerprintMap(np.vstack((np.clip(m+update,-110.,0.),sy)),xy,mask)


def measure(tr,va,phone,jobs,period,config=None):
    records=[]
    for j in jobs:
        b,f=j['building'],j['floor'];t=tr[b,f]
        hs=[h for (hb,hf),h in tr.items() if hb==b and hf!=f]
        if period:
            q=va[b,f]
            orders=([nested_rows(t['xy'],range(len(t['xy'])),BUDGETS,0,f'contour-source/{b}/{f}/{d}')['support_rows'][20] for d in range(3)]
                    if config is None else [split_rows(t,b,f,d)[0] for d in SEEDS])
        else:
            hs=[{key:v[phone[h['ids']]!=j['phone']] for key,v in h.items()} for h in hs]
            hs=[h for h in hs if len(h['rss'])]
            qi=local_rows(t,np.asarray(j['query_ids']));q={key:v[qi] for key,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))
            if config is None:orders=orders[:3]
        bank=ContourMap(hs);qw=position_weights(q['xy'])
        arms={str(p):p for p in GRID} if config is None else config[str(b)]
        for d,sr in enumerate(orders):
            for k in BUDGETS:
                parts=bank.prepare({key:v[sr[:k]] for key,v in t.items()})
                cache={}
                for name,(ell,beta) in arms.items():
                    key=ell,beta,name=='shuffle'
                    if key not in cache:
                        model=bank.model(parts,*key)
                        pred=model.predict(q['rss'])
                        cache[key]=qw@np.linalg.norm(pred-q['xy'],axis=1)
                    records.append((b,f,d,k,name,ell,beta,cache[key]))
    return pd.DataFrame(records,columns=['building','floor','draw','K','method','ell','beta','mde'])


def main(data,design,out):
    out.mkdir(exist_ok=True,parents=True)
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=[dict(building=b,floor=f) for b,f in tr]
    a=measure(tr,va,phones,jobs,True).assign(regime='time')
    b=measure(tr,va,phones,source_design(tr,phones),False).assign(regime='device')
    r=pd.concat([a,b]).groupby(['building','regime','floor','ell','beta']).mde.mean().groupby(['building','regime','ell','beta']).mean()
    r.to_csv(out/'source.csv')
    configs={}
    for b in (0,1,2,'external'):
        scores=(r if b=='external' else r.drop(b,level='building')).groupby(['ell','beta']).mean()
        best=lambda grid:min(grid,key=lambda p:(scores.loc[p],p[1],abs(p[0]-40)))
        full=best(GRID)
        configs[str(b)]=dict(standard=(40.,0.),matched_spatial=best([(l,0.) for l in LENGTH]),
                     fixed_contour=(40.,1.),fixed_weak=(40.,.25),selected=full,shuffle=full)
    file=out/'fit.json';file.write_text(json.dumps(configs,indent=2)+'\n')
    cfg=json.loads(file.read_text())
    measure(tr,va,phones,jobs,True,cfg).to_csv(out/'official.csv',index=False)
    measure(tr,va,phones,json.loads(design.read_text())['events'],False,cfg).to_csv(out/'phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','design','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.design,a.out)
