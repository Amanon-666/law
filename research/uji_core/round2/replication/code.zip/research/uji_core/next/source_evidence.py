"""Partial pooling of S-only evidence for historical source relevance.

Each source predicts all S fingerprints. A robust discrepancy in observed
space is shrunk to a shared AP judgement and a proximity prior. This changes
the historical template only; the downstream target update/readout is fixed.
"""
import argparse
import json
from itertools import product
from pathlib import Path
import numpy as np
import pandas as pd

from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap
from .source_trust import Bank
from .transport import source_design
from ..protocol import BUDGETS,SEEDS,read_floors,split_rows,position_weights
from ..smooth_scale import local_rows
from residual_probe.episode_rows import nested_rows

SCALES=(0.,.5,2.,8.)
SHARING=(0.,.5,1.)  # 0 shares evidence; 1 estimates relevance separately per AP
GRID=tuple((t,l) for t in SCALES for l in (SHARING if t else (0.,)))


class EvidenceBank(Bank):
    def errors(self,s,mask):
        raw=tpm.dbm(s['rss'][:,mask])
        e=[]
        predictions=[]
        for m,xy in self.maps:
            mu=tpm.lookup(s['xy'],xy,m[:,mask])
            predictions.append(mu)
            e.append(np.minimum(((raw-mu)/16.)**2,9.).sum(0)/(len(raw)+3))
        e=np.stack(e)
        e-=e.mean(0)
        # A scan's universally absent slots offer little common-source evidence.
        weight=np.maximum((raw+110).max(0),np.max(np.stack(predictions)+110,axis=(0,1))).clip(0,30)
        shared=np.average(e,axis=1,weights=np.maximum(weight,1e-8))[:,None]
        return e,shared

    def condition(self,s,scale,separate,evidence=None):
        mask=self.hmask|(s['rss']!=100).any(0)
        e,shared=self.errors(s,mask) if evidence is None else evidence
        logits=-2*self.gap[:,None]-scale*((1-separate)*shared+separate*e)
        w=np.exp(np.maximum(logits-logits.max(0),-80.))
        def avg(numer,mass):
            return np.einsum('ja,jxa->xa',w,numer[:,:,mask])/np.einsum('ja,jx->xa',w,mass)
        m=.5*(avg(self.numer,self.exact)+avg(self.num_smooth,self.den_smooth))
        v,xy=tpm.calibrate((m,self.xy),dict(rss=s['rss'][:,mask],xy=s['xy']),(40.*self.unit,1.))
        return FingerprintMap(v,xy,mask)


def measure(tr,va,phone,jobs,period,choices=None):
    rows=[]
    for j in jobs:
        b,f=j['building'],j['floor']; t=tr[b,f]
        floors=[(abs(hf-f),h) for (hb,hf),h in tr.items() if hb==b and hf!=f]
        if period:
            q=va[b,f]
            orders=([nested_rows(t['xy'],range(len(t['xy'])),BUDGETS,0,f'ev-src/{b}/{f}/{d}')['support_rows'][20] for d in range(3)]
                 if choices is None else [split_rows(t,b,f,d)[0] for d in SEEDS])
        else:
            floors=[(gap,{k:v[phone[h['ids']]!=j['phone']] for k,v in h.items()}) for gap,h in floors]
            floors=[(gap,h) for gap,h in floors if len(h['rss'])]
            qr=local_rows(t,np.asarray(j['query_ids']));q={k:v[qr] for k,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))
            if choices is None:orders=orders[:3]
        bank=EvidenceBank([h for _,h in floors],[gap for gap,_ in floors])
        arms={str(p):p for p in GRID} if choices is None else choices[str(b)]
        qw=position_weights(q['xy'])
        for draw,idx in enumerate(orders):
            for k in BUDGETS:
                s={key:v[idx[:k]] for key,v in t.items()}
                mask=bank.hmask|(s['rss']!=100).any(0)
                ev=bank.errors(s,mask); cache={}
                for name,(scale,sep) in arms.items():
                    key=(scale,sep,name=='shuffle')
                    if key not in cache:
                        evidence=ev
                        if name=='shuffle':
                            ix=np.random.default_rng(751).permutation(ev[0].shape[1])
                            evidence=(ev[0][:,ix],ev[1])
                        model=bank.condition(s,scale,sep,evidence)
                        cache[key]=qw@np.linalg.norm(model.predict(q['rss'])-q['xy'],axis=1)
                    rows.append((b,f,draw,k,name,scale,sep,cache[key]))
    return pd.DataFrame(rows,columns=['building','floor','draw','K','method','scale','separate','mde'])


def main(data,design,out):
    out.mkdir(exist_ok=True,parents=True)
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=[dict(building=b,floor=f) for b,f in tr]
    a=measure(tr,va,phones,jobs,True).assign(group='time')
    d=measure(tr,va,phones,source_design(tr,phones),False).assign(group='device')
    keys=['scale','separate']
    r=pd.concat([a,d]).groupby(['building','group','floor',*keys]).mde.mean().groupby(['building','group',*keys]).mean()
    r.to_csv(out/'source.csv');cfg={}
    for b in (0,1,2,'external'):
        sub=r if b=='external' else r.drop(b,level='building')
        avg=sub.groupby(keys).mean()
        best=lambda grid:min(grid,key=lambda p:(avg.loc[p],sum(p)))
        full=best(GRID)
        cfg[str(b)]=dict(parent=(0.,0.),weak_shared=(.5,0.),weak_AP=(.5,1.),fixed_partial=(2.,.5),
            shared_fit=best([p for p in GRID if p[1]==0]),AP_fit=best([p for p in GRID if p[0]==0 or p[1]==1]),
            selected=full,shuffle=full)
    fp=out/'fit.json';fp.write_text(json.dumps(cfg,indent=2)+'\n')
    cfg=json.loads(fp.read_text())
    measure(tr,va,phones,jobs,True,cfg).to_csv(out/'official.csv',index=False)
    measure(tr,va,phones,json.loads(design.read_text())['events'],False,cfg).to_csv(out/'phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','design','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.design,a.out)
