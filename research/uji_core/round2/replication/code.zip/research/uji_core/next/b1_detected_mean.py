"""Post hoc conditional-mean channel diagnostic; do not use for model selection.

Both components of each original fixed-MAP vs nearest-true margin are retained.
The counterfactual changes only H candidates' detected-RSS mean. It keeps the
same S innovation, missing score, candidates, support templates, and sigma.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import log_ndtr, softmax
from scipy.spatial.distance import cdist
from refi import fit_map,historical_prior
from ..protocol import read_floors
from ..smooth_scale import local_rows
from .b1_region_repeat import ORIGINAL


def moments(hist,gaps):
    m,xy=historical_prior(hist,10.,.5,gaps)
    # The same linear operator acts on both moment numerators. Scaling the
    # nonnegative observed-strength numerator into [0,1] avoids RSS sentinel 100.
    seen=[dict(xy=h['xy'],rss=(h['rss']!=100).astype(float)) for h in hist]
    ss,px=historical_prior(seen,10.,.5,gaps)
    num=[dict(xy=h['xy'],rss=np.where(h['rss']!=100,(h['rss'].astype(float)+110.)/110.,0.)) for h in hist]
    sn,nx=historical_prior(num,10.,.5,gaps)
    assert np.array_equal(px,xy) and np.array_equal(nx,xy)
    np.testing.assert_allclose(m,110.*sn-110.,atol=1e-10,rtol=0.)
    if ss.min()<0. or ss.max()>1.+1e-12:raise ValueError('Invalid empirical detection probability')
    conditional=-110.+110.*np.divide(sn,ss,out=np.zeros_like(sn),where=ss>0.)
    # With no H detection, leave the original historical mean unchanged.
    conditional=np.where(ss>0.,conditional,m);return m,xy,ss,conditional


def main(data,manifest,out):
    out.mkdir(exist_ok=True,parents=True);train=read_floors(data,'trainingData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    manifest=json.loads(manifest.read_text());score_rows=[];ap_rows=[];max_parent=0.
    for floor in (2,3):
        job=next(j for j in manifest['events'] if j['building']==1 and j['floor']==floor);dev=job['phone'];t=train[1,floor]
        discovery=np.array(ORIGINAL);standard=np.asarray(job['query_ids']);record=[]
        if floor==2:
            for orig in discovery:
                xy=t['xy'][local_rows(t,np.array([orig]))[0]]
                for i in np.flatnonzero((t['xy']==xy).all(1)):
                    if phones[t['ids'][i]]==dev:
                        record.append((i,'F2_discovery' if t['ids'][i] in ORIGINAL else 'F2_region_repeats',orig))
            for i in local_rows(t,standard[~np.isin(standard,discovery)]):record.append((i,'F2_other_nine',t['ids'][i]))
        else:
            for i in local_rows(t,standard):record.append((i,'F3_all_twelve',t['ids'][i]))
        qr=np.array([row[0] for row in record]);keys=[v[1] for v in record];coordinate_ids=[int(v[2]) for v in record]
        q={key:value[qr] for key,value in t.items()};assert len(np.unique(q['ids']))==len(qr)
        if not (phones[q['ids']]==dev).all():raise ValueError('Unexpected test device')
        hs=[];gaps=[]
        for (b,f),h in sorted(train.items()):
            if b!=1 or f==floor:continue
            keep=phones[h['ids']]!=dev
            if keep.any():hs.append({k:v[keep] for k,v in h.items()});gaps.append(abs(f-floor))
        m,xy,p,cond=moments(hs,gaps)
        for draw,order in enumerate(local_rows(t,np.asarray(job['support_orders']))):
            for k in (1,3):
                ss={key:v[order[:k]] for key,v in t.items()};model=fit_map(hs,ss,floor_gaps=gaps);mask=model.visible
                nH=len(xy);assert np.array_equal(model.xy[:nH],xy)
                mfix=model.prototypes;replacement=mfix.copy()
                # Keep the exact S-induced update on the H map, only replacing
                # the H-based filled mean by its empirical conditional counterpart.
                replacement[:nH]=np.clip(mfix[:nH]+(cond[:,mask]-m[:,mask]),-110.,0.)
                posterior=model.predict(q['rss']);dist=cdist(q['xy'],model.xy);true=dist.argmin(1);public_aps=np.flatnonzero(mask)
                for qi,rss in enumerate(q['rss'][:,mask]):
                    active=rss!=100;ap=public_aps[active];observed=rss[active].astype(float)
                    old=-.5*((observed[None,:]-mfix[:,active])/12.)**2
                    new=-.5*((observed[None,:]-replacement[:,active])/12.)**2
                    absent=log_ndtr((-85.-mfix[:,~active])/12.).sum(1)
                    original=old.sum(1)+absent;delta=new-old;logits=original+delta.sum(1)
                    pr=softmax(original);alt=softmax(logits);top=int(original.argmax());alt_top=int(logits.argmax());near=int(true[qi]);truth=q['xy'][qi]
                    def mean_xy(w):return w@(model.xy-model.xy[0])+model.xy[0]
                    original_xy=mean_xy(pr);new_xy=mean_xy(alt);max_parent=max(max_parent,float(np.max(abs(original_xy-posterior[qi]))))
                    old_error=float(np.linalg.norm(original_xy-truth));new_error=float(np.linalg.norm(new_xy-truth))
                    # The one-AP counterfactual retains every other original score component.
                    one_error=np.linalg.norm(mean_xy(softmax(original[:,None]+delta,axis=0).T)-truth,axis=1)
                    if near<nH:
                        pt=p[near,mask][active];ct=cond[near,mask][active];ht=m[near,mask][active]
                    else:
                        pt=ct=ht=np.full(active.sum(),np.nan)
                    if top<nH:
                        pw=p[top,mask][active];cw=cond[top,mask][active];hw=m[top,mask][active]
                    else:
                        pw=cw=hw=np.full(active.sum(),np.nan)
                    # Predefined diagnostic categories only. No thresholds affect predictions.
                    sparse=(pt>0)&(pt<.2)&(ct>-85.)
                    oldparts=old[top]-old[near];newparts=new[top]-new[near];miss=float(absent[top]-absent[near])
                    wrong_cluster=np.linalg.norm(model.xy-model.xy[top],axis=1)<=10.
                    wrong_w=pr[wrong_cluster]/pr[wrong_cluster].sum()
                    cluster_old=wrong_w@old[wrong_cluster]-old[near];cluster_new=wrong_w@new[wrong_cluster]-new[near]
                    meta=dict(cohort=keys[qi],coordinate_from=coordinate_ids[qi],query_id=int(q['ids'][qi]),floor=floor,phone=dev,draw=draw,K=k)
                    score_rows.append(dict(**meta,n_detected=len(ap),n_sparse=int(sparse.sum()),old_error=old_error,new_error=new_error,change=new_error-old_error,
                        actual_MAP_dist=dist[qi,top],new_MAP_dist=dist[qi,alt_top],true_to_candidate=dist[qi,near],original_MAP_in_H=top<nH,near_in_H=near<nH,
                        mass_true_before=pr[dist[qi]<=10].sum(),mass_true_after=alt[dist[qi]<=10].sum(),old_MAP_minus_near_detected=oldparts.sum(),
                        new_fixed_MAP_minus_near_detected=newparts.sum(),fixed_MAP_minus_near_missed=miss,old_margin=oldparts.sum()+miss,new_fixed_margin=newparts.sum()+miss,
                        sparse_original=oldparts[sparse].sum(),sparse_fixed_new=newparts[sparse].sum(),
                        positive_margin_mass=np.maximum(oldparts,0.).sum(),sparse_positive_margin_mass=np.maximum(oldparts[sparse],0.).sum(),
                        old_mode10_minus_near_RSS=cluster_old.sum(),new_fixed_mode10_minus_near_RSS=cluster_new.sum(),
                        mean_abs_q_minus_true_filled=np.abs(observed-mfix[near,active]).mean(),mean_abs_q_minus_true_conditional=np.abs(observed-replacement[near,active]).mean(),
                        mean_abs_q_minus_MAP_filled=np.abs(observed-mfix[top,active]).mean(),mean_abs_q_minus_MAP_conditional=np.abs(observed-replacement[top,active]).mean()))
                    for ai,col in enumerate(ap):
                        ap_rows.append(dict(**meta,AP=f'WAP{col+1:03}',rss=observed[ai],true_history_p=pt[ai],true_history_filled=ht[ai],true_history_cond=ct[ai],
                            map_history_p=pw[ai],map_history_filled=hw[ai],map_history_cond=cw[ai],true_score_filled=mfix[near,active][ai],
                            true_score_cond=replacement[near,active][ai],map_score_filled=mfix[top,active][ai],map_score_cond=replacement[top,active][ai],
                            old_AP_margin=oldparts[ai],new_AP_margin=newparts[ai],single_AP_error=one_error[ai],single_AP_delta=one_error[ai]-old_error,
                            sparse_strong=bool(sparse[ai]),old_mode10_margin=cluster_old[ai],new_fixed_mode10_margin=cluster_new[ai]))
    d=pd.DataFrame(score_rows);aa=pd.DataFrame(ap_rows);d.to_csv(out/'detected_events.csv.gz',index=False);aa.to_csv(out/'detected_AP.csv.gz',index=False)
    index=['cohort','coordinate_from','query_id','K'];loc=d.groupby(index).mean(numeric_only=True).groupby(['cohort','coordinate_from','K']).mean()
    summary=loc.groupby(['cohort','K']).mean(numeric_only=True);summary.to_csv(out/'detected_summary.csv');loc.to_csv(out/'detected_positions.csv')
    grouped=[]
    # AP-level attribution: absent query/AP pairs make zero contribution. Use
    # the same denominator (all allowed scans within each site) as the score.
    for (name,k),block in d.groupby(['cohort','K']):
        npos=block.coordinate_from.nunique();counts=block.groupby('coordinate_from').size()
        z=aa[(aa.cohort==name)&(aa.K==k)].copy();z['mass']=1./(npos*z.coordinate_from.map(counts))
        for col in ('old_AP_margin','new_AP_margin','single_AP_delta'):
            z[col+'_weighted']=z[col]*z.mass
        for apname,apdata in z.groupby('AP'):
            grouped.append(dict(cohort=name,K=int(k),AP=apname,exposure=float(apdata.mass.sum()),
                old_margin=float(apdata.old_AP_margin_weighted.sum()),new_margin=float(apdata.new_AP_margin_weighted.sum()),
                conditional_single_AP_MDE_delta=float(apdata.single_AP_delta_weighted.sum()),
                mean_true_hist_detected_probability=float(np.average(apdata.true_history_p,weights=apdata.mass)) if apdata.true_history_p.notna().all() else None,
                mean_measured_RSS=float(np.average(apdata.rss,weights=apdata.mass))))
    pd.DataFrame(grouped).to_csv(out/'ap_contributions.csv',index=False)
    meta=dict(known='Post hoc B1F2 selected 3 adjacent sites; discovery rows separate from 24 new rows; other nine F2, all 12 F3 fixed query controls; support/phone/geometry drawn from existing manifests unchanged. No external evaluation.',
        estimator='Identical gap2 weighted floor and half10 spatial operator on E[d] and E[d(r+110)/110]. At P>0 use -110+110 E[d(r+110)/110]/P. For H candidates add this conditional-minus-filling difference before evaluating detected RSS Gaussian (same baseline post-S displacement, clip [-110,0]); at P=0 leave original. Raw S templates and all nondetection scores unchanged. No probability factor or tuning.',
        decomposition='Original MAP and nearest-true candidate fixed for every before/after margin. Each detected AP substituted alone for its individual MDE effect. Mixed 10U wrong-cluster terms use normalized original posterior weights across that cluster; not a decomposition of a marginal log-likelihood ratio.',
        diagnostics='Sparse/strong: 0 < empirical H detection frequency < .2 and empirical H detected-only RSS above existing -85 dBm threshold at nearest true H candidate. Predictions do not use these categories.',
        max_abs_public_xy_difference=max_parent,rows=len(d),n_detected_pairs=len(aa));assert max_parent<1e-8
    (out/'detected_protocol.json').write_text(json.dumps(meta,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('data','manifest','out'):p.add_argument(key,type=Path)
    a=p.parse_args();main(a.data,a.manifest,a.out)
