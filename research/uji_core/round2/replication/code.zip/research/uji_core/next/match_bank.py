"""Learn one scan-gain width from other floors inside the deployment history bank.

Blind API: bank = fit_bank([{'rss': H1, 'xy': X1}, ...])
           model = bank.condition({'rss': S, 'xy': XS})
           estimate_xy = model.predict(query_rss)
No fitted external checkpoint, device IDs, timestamps, target labels, or query
input is used in fit_bank. Original row order indexes repeated acquisitions.
"""
from dataclasses import dataclass

import numpy as np
from scipy.special import softmax
from external_baselines import tpm_adapter as tpm
import refi

from ..protocol import BUDGETS, SEEDS, position_weights
from .match import DEFAULT
from .match_coupled import conditional_scores, marginal, losses

# Exact ties prefer the predeclared no-training 6 dB rule.
WIDTHS = (6., 0., 3., 9., 12.)


@dataclass(frozen=True)
class TargetMap:
    field: refi.FingerprintMap
    width: float

    def predict(self, query_rss):
        q = np.asarray(query_rss, dtype=float)
        if q.ndim != 2 or q.shape[1] != len(self.field.visible) or not np.isfinite(q).all():
            raise ValueError('Expected a finite query x aligned-AP matrix')
        xy = self.field.xy
        out = np.empty((len(q),2), dtype=float)
        for l in range(0,len(q),64):
            scores = conditional_scores(q[l:l+64,self.field.visible],self.field.prototypes)
            weights = softmax(marginal(scores,self.width),axis=1)
            out[l:l+64] = weights@(xy-xy[0])+xy[0]
        return out


@dataclass(frozen=True)
class TrainedBank:
    histories: tuple
    width: float
    audit: dict

    def condition(self, support):
        return TargetMap(refi.fit_map(self.histories,support),self.width)


def draws_for(xy):
    # Sorted coordinate groups are independent of RSS values and source-list order.
    pos, group = np.unique(xy,axis=0,return_inverse=True)
    members=[np.flatnonzero(group.ravel()==i) for i in range(len(pos))]
    if len(pos)<max(BUDGETS)+12:
        return
    for draw in SEEDS:
        rng=np.random.default_rng(391723+draw)
        permutation=rng.permutation(len(pos))
        qpos=permutation[:12]
        spos=permutation[12:12+max(BUDGETS)]
        support=np.array([rng.choice(members[i]) for i in spos])
        query=np.concatenate([rng.choice(members[i], min(3,len(members[i])),replace=False) for i in qpos])
        yield support,query


def fit_bank(histories):
    """Estimate only the width from historical leave-one-source-out localization."""
    histories=tuple({'rss':np.asarray(h['rss']), 'xy':np.asarray(h['xy'])}
                    for h in histories if len(h['rss']))
    if not histories:
        raise ValueError('Need at least one historical source')
    if histories[0]['rss'].ndim!=2:
        raise ValueError('Expected an H scan matrix with an aligned AP axis')
    width=histories[0]['rss'].shape[1]
    for h in histories:
        refi._scans(h,width)
    source_risks,details=[],[]
    for j,h in enumerate(histories):
        remaining=histories[:j]+histories[j+1:]
        draws=list(draws_for(h['xy']))
        if not remaining or not draws:
            details.append(dict(source=j,eligible=False))
            continue
        raw,hxy=refi.smooth_history(tpm.history_map(remaining,None,None),10.,.5)
        visible=np.logical_or.reduce([(x['rss']!=100).any(0) for x in remaining])
        risk_by_draw=[]
        row_identity=[]
        for s,q in draws:
            qxy=h['xy'][q]
            weight=position_weights(qxy)
            grid=[]
            for k in BUDGETS:
                sr=s[:k]
                active=visible|(h['rss'][sr]!=100).any(0)
                support={'rss':h['rss'][sr][:,active],'xy':h['xy'][sr]}
                prototypes,xy=tpm.calibrate((raw[:,active],hxy),support,(40.,1.))
                event=dict(query=h['rss'][q][:,active], prototypes=prototypes, xy=xy,
                           truth=qxy,weight=weight)
                grid.append(losses(event,DEFAULT,WIDTHS))
            risk_by_draw.append(np.mean(grid,axis=0))
            row_identity.append(dict(S=s.tolist(),Q=q.tolist()))
        risk=np.mean(risk_by_draw,axis=0)
        source_risks.append(risk)
        details.append(dict(source=j,eligible=True,draws=row_identity,risks=risk.tolist()))
    average=np.mean(source_risks,axis=0) if source_risks else None
    selected=WIDTHS[int(np.argmin(average))] if average is not None else 6.
    return TrainedBank(histories,selected,dict(widths=WIDTHS,selected=selected,
        fallback=not source_risks,average_risks=None if average is None else average.tolist(),
        row_indices='Local zero-based indices within each held history only',sources=details))
