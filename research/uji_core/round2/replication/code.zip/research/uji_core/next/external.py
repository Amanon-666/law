"""External test on publisher-designated target scans and label-position nested support.

OPENBLAS_NUM_THREADS=1 python -m research.uji_core.next.external DATA UJI_RESULTS OUT --dataset tau|sod
Zenodo 5174851, Lohan/Torres-Sospedra/Gonzalez (2021), CC BY 4.0.
All horizontal distances are reported in meters. Each UJI coordinate unit maps
to 0.766 m before applying already-frozen spatial hyperparameters.
"""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

from external_baselines import tpm_adapter as tpm
from refi import smooth_history
from residual_probe.episode_rows import nested_rows
from ..inverse import predict
from ..protocol import BUDGETS, SEEDS, position_weights
from ..wknn_reference import pool_floor

DATASETS = {
    "tau": dict(sites=("TIE1","SAH1"), doi="10.5281/zenodo.5174851", license="CC BY 4.0",
                author="E. S. Lohan, J. Torres-Sospedra, A. Gonzalez (2021)",
                input="Zenodo ZIP, author-provided training and operational test scans.",
                history="Earlier operator_prior_v1 evaluated these same buildings, including SAH1 F2 official. Independent of current fitting only."),
    "sod": dict(sites=("CETC331",), doi="10.1186/s43020-022-00086-y",
                source="https://github.com/bijingxue/SODIndoorLoc/tree/bfe8f63f55957cc25b23ba91c408ae345a3fb0b7/CETC331",
                author="J. Bi et al. (2022)", input="First-author released CSV. A training fingerprint (S or H) is already a mean of 30 scans; queries are real scans. Other buildings are single-floor.",
                history="Earlier project notes checked CETC331 coverage and used the two other SOD buildings in an older transfer study. This run uses no SOD fingerprints or outcomes for model selection. No earlier CETC331 localization evaluation was identified."),
}
SOD_HASHES = {"training":"c5975a9e2c8fe03e0ce8ec11175d005032867f6267747dfeae7f2ca1720a143e",
              "test":"3832048128c8f772438020ee38c38e2b4b0bf4d8591c3fa32d5322d390c86388"}
METRES_PER_UJI_UNIT = .766
ZIP_SHA256 = 'e2aad829ead7d729c8d5c28ed1b2a8f6d4f60d97cc1827043537addaf93e30ac'



def read_tau(zip_path, site, split):
    if hashlib.sha256(zip_path.read_bytes()).hexdigest() != ZIP_SHA256:
        raise ValueError('Unexpected Zenodo archive')
    with zipfile.ZipFile(zip_path) as z:
        names = {Path(n).name:n for n in z.namelist()}
        def matrix(kind, dtype):
            with z.open(names[f'{site}_{split}_{kind}.csv']) as f:
                return pd.read_csv(f,header=None,dtype=dtype).to_numpy()
        coords, rss = matrix('coordinates',float), matrix('rss',np.int16)
    if len(coords) != len(rss) or not np.isfinite(coords).all():
        raise ValueError('Invalid external data')
    floors = coords[:,3].astype(int)
    assert np.array_equal(floors,coords[:,3])
    return {int(f):dict(ids=np.flatnonzero(floors==f),rss=rss[floors==f],
                        xy=coords[floors==f,:2] / METRES_PER_UJI_UNIT) for f in np.unique(floors)}


def read_sod(directory, site, split):
    prefix = "Training" if split == "training" else "Testing"
    path = directory / site / f"{prefix}_{site}.csv"
    if hashlib.sha256(path.read_bytes()).hexdigest() != SOD_HASHES[split]:
        raise ValueError("Unexpected CETC331 CSV")
    df=pd.read_csv(path)
    aps=[f"MAC{i}" for i in range(1,53)]
    return {int(f):dict(ids=z.index.to_numpy(),rss=z[aps].to_numpy(np.int16),
                        xy=z[["ECoord","NCoord"]].to_numpy()/METRES_PER_UJI_UNIT)
            for f,z in df.groupby("FloorID")}


def design(path, uji, dataset, reader):
    scores = pd.read_csv(uji/'wknn_source.csv')
    table = scores.groupby(['building','reference','neighbors']).mde.mean()
    risk = table.groupby(['reference','neighbors']).mean()
    # Same candidate tie preference as the frozen UJI reference study.
    rep,k = min(((r,n) for r in ('raw','prototype') for n in (1,3,7,15)),
                key=lambda op:risk.loc[op])
    events,omitted = [],[]
    for site in DATASETS[dataset]['sites']:
        data, valid = (reader(path,site,s) for s in ('training','test'))
        for floor,target in data.items():
            if floor not in valid or len(np.unique(target['xy'],axis=0))<max(BUDGETS) or len(data)<2:
                omitted.append(dict(site=site,floor=floor,n_training=len(target['xy']),
                                    n_query=0 if floor not in valid else len(valid[floor]['xy'])))
                continue
            for seed in SEEDS:
                draw=nested_rows(target['xy'],range(len(target['xy'])),BUDGETS,0,
                                 f'{dataset}-ext-v1/{site}/{floor}/{seed}')
                selected=draw['support_rows'][max(BUDGETS)]
                events.append(dict(site=site,floor=floor,seed=seed,support_local=selected,
                                   support_ids=target['ids'][selected].tolist(),
                                   query_ids=valid[floor]['ids'].tolist()))
    return dict(**DATASETS[dataset], input_sha256=ZIP_SHA256 if dataset=='tau' else SOD_HASHES,
                wknn_source_sha256=hashlib.sha256((uji/'wknn_source.csv').read_bytes()).hexdigest(),metres_per_uji_unit=METRES_PER_UJI_UNIT,report_unit='m',
                field='Deployed 0.5 smoothing at 10 U, 40 U residual and unit ridge; fixed Tobit (12,-85).',
                wknn=dict(reference=rep,neighbors=int(k),fit='All 3 UJI training buildings, equal building and floor, fixed historical candidate grid. No external tuning.'),
                design='All publisher test queries per floor. Each support position contributes one publisher training fingerprint; '
                'nested draws depend on training coordinates only. H is all other floors of this same site. '
                'Primary risk averages scans within position, then positions, draw, floor and building. '
                'Report absent official-query floors explicitly. Test labels score only. Row IDs are zero-based per CSV.',
                excluded=omitted,events=events)


def map_for(prior,hx,target,sr,mask):
    s=dict(rss=target['rss'][sr][:,mask],xy=target['xy'][sr])
    return tpm.calibrate((prior[:,mask],hx),s,(40.,1.))


def main(path,uji,out,dataset):
    out.mkdir(exist_ok=True,parents=True)
    reader=read_tau if dataset=='tau' else read_sod
    frozen=design(path,uji,dataset,reader)
    (out/f'external_{dataset}_protocol.json').write_text(json.dumps(frozen,indent=2)+'\n')
    choice=frozen['wknn']; events=[]; predictions=[]
    for site in DATASETS[dataset]['sites']:
        train,valid=(reader(path,site,s) for s in ('training','test'))
        for floor in sorted({e['floor'] for e in frozen['events'] if e['site']==site}):
            target,q=train[floor],valid[floor]
            h=[v for f,v in train.items() if f!=floor]
            hp,hx=tpm.history_map(h,None,None)
            smooth,_=smooth_history((hp,hx),10.,.5)
            mask_h=np.logical_or.reduce([(a['rss']!=100).any(0) for a in h])
            bank=h if choice['reference']=='raw' else [pool_floor(a) for a in h]
            w=position_weights(q['xy'])
            for case in frozen['events']:
                if (case['site'],case['floor'])!=(site,floor):
                    continue
                for k in BUDGETS:
                    sr=case['support_local'][:k]
                    mask=mask_h|(target['rss'][sr]!=100).any(0)
                    s={key:target[key][sr] for key in ('rss','xy','ids')}
                    m,xy=map_for(smooth,hx,target,sr,mask)
                    p=tpm.tobit_weights(q['rss'][:,mask],m,12.,-85.)@(xy-xy[0])+xy[0]
                    pw=predict(bank,s,q['rss'],neighbors=choice['neighbors'],scale=1.,transport=0.)
                    for arm,loc in [('fixed_refi',p),('strong_wknn',pw)]:
                        err=np.linalg.norm(loc-q['xy'],axis=1)*METRES_PER_UJI_UNIT
                        if not np.isfinite(err).all(): raise FloatingPointError((site,floor,k,arm))
                        key=dict(site=site,floor=floor,seed=case['seed'],K=k,method=arm)
                        events.append(dict(**key,n_query=len(q['rss']),n_H=sum(len(a['rss']) for a in h),mde=w@err))
                        predictions.append(pd.DataFrame(dict(**key,row_id=q['ids'],err_m=err,w=w)))
    pd.DataFrame(events).to_csv(out/f'external_{dataset}_events.csv',index=False)
    pd.concat(predictions,ignore_index=True).to_csv(out/f'external_{dataset}_queries.csv.gz',index=False)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('data','uji','out'): parser.add_argument(name,type=Path)
    parser.add_argument('--dataset',choices=DATASETS,required=True)
    args=parser.parse_args()
    main(args.data,args.uji,args.out,args.dataset)
