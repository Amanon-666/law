"""Learn how much of one observed-space RSS innovation survives a future campaign.

Train conditional moments on true cross-time repeats. Select only the ridge
strength by validation localization. A same-campaign control excludes the
anchor scan from the repeated-scan target. Train and evaluation are separate
commands so a caller can freeze all other candidates before opening late data.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist

from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap
from ..protocol import BUDGETS, SEEDS, read_floors, position_weights
from . import longitudinal as lib
from .transport import history_basis
from .match_episodes import eval_tasks

METRES_PER_UNIT=.766
P_EDGES=(.2,.8)
NBINS=9
RIDGES=(0.,.01,.1,1.,np.inf)
SCALARS=(0.,.25,.5,.75,1.,1.25,1.5,2.)


def normalized(data,scale):
    return {'rss':data['rss'],'xy':data['xy']/scale}


def categories(p,seen,z):
    # Low/middle/high previous detection rate x miss/negative detection/positive detection.
    return 3*np.searchsorted(P_EDGES,p,side='right')+np.where(seen,1+(z>=0).astype(int),0)


def paired_stats(archive,stage):
    rows=[]
    for t in lib.STAGES[stage]:
        for floor in (3,5):
            h=lib.on_floor(archive,t-2,'trn',15 if t==3 else 1,floor)
            s=lib.on_floor(archive,t-1,'trn',1,floor)
            future=lib.on_floor(archive,t,'trn',1,floor)
            if not(h['times'].max()<s['times'].min() and s['times'].max()<future['times'].min()):
                raise ValueError('Campaign timestamps overlap')
            m,hxy,p,hseen=history_basis([normalized(h,METRES_PER_UNIT)])
            sx,sg,sc=np.unique(s['xy'],axis=0,return_inverse=True,return_counts=True);sg=sg.ravel()
            fx,fg,fc=np.unique(future['xy'],axis=0,return_inverse=True,return_counts=True);fg=fg.ravel()
            if not np.array_equal(sx,fx) or sc.min()<2 or fc.min()<2:
                raise ValueError('Matched temporal replicates are unavailable')
            ex=tpm.lookup(sx/METRES_PER_UNIT,hxy,m)[sg];prob=tpm.lookup(sx/METRES_PER_UNIT,hxy,p)[sg]
            sdb=tpm.dbm(s['rss']); fdb=tpm.dbm(future['rss'])
            means=tpm.position_map(sdb,s['xy'])[0]
            fmean=tpm.position_map(fdb,future['xy'])[0]
            same=(means[sg]*sc[sg,None]-sdb)/(sc[sg,None]-1.)
            e_s=sdb-ex; y_future=fmean[sg]-ex; y_same=same-ex
            seen=s['rss']!=100; use=seen|hseen
            bins=categories(prob,seen,e_s)
            # Equal location, then scan within location and AP allowed at that scan.
            w=use/(len(sx)*sc[sg,None]*use.sum(1,keepdims=True))
            variance=np.zeros_like(fmean);np.add.at(variance,fg,(fdb-fmean[fg])**2);variance/=fc[:,None]-1.
            def by_bin(v):
                return np.bincount(bins.ravel(),weights=(w*v).ravel(),minlength=NBINS)
            vals={name:by_bin(v) for name,v in {
                'mass':1.,'support_energy':e_s**2,'future_cross':e_s*y_future,
                'future_mean_energy':y_future**2,'same_cross':e_s*y_same,'same_mean_energy':y_same**2,
                'future_noise':variance[sg],'future_repeat_count_inverse_noise':variance[sg]/fc[sg,None],
                'matched_future_mean':fmean[sg], 'matched_previous_mean':means[sg],
            }.items()}
            rows += [dict(month=t,floor=floor,bin=i,source_positions=len(sx),calibration_scans=len(sdb),
                          repeat_scans=len(fdb),earliest_H=int(h['times'].min()),earliest_S=int(s['times'].min()),
                          earliest_F=int(future['times'].min()),**{k:v[i] for k,v in vals.items()}) for i in range(NBINS)]
    return pd.DataFrame(rows)


def fit_curves(stats):
    avg=stats.groupby('bin').mean(numeric_only=True); d=avg.support_energy.to_numpy()
    models={'unit':np.ones(NBINS),**{f'constant{v}':np.full(NBINS,v) for v in SCALARS}}
    for kind in ('future','same'):
        cross=avg[kind+'_cross'].to_numpy();global_gain=float(np.clip(cross.sum()/d.sum(),0.,2.))
        models[kind+'_global']=np.full(NBINS,global_gain)
        for coeff in RIDGES:
            ridge=coeff*d.sum()/NBINS
            g=np.full(NBINS,global_gain)
            if np.isfinite(ridge):
                g=np.divide(cross+ridge*global_gain,d+ridge,out=g,where=d+ridge>0)
            models[f'{kind}_{coeff}']=np.clip(g,0.,2.)
    return models


def projection(hxy,sxy):
    ss=np.exp(-cdist(sxy,sxy,'sqeuclidean')/(2*40.**2))
    hs=np.exp(-cdist(hxy,sxy,'sqeuclidean')/(2*40.**2))
    return np.linalg.solve(ss+np.eye(len(sxy)),hs.T).T


def updates(basis,support,scale):
    m,hxy,p,hseen=basis
    s=normalized(support,scale)
    visible=hseen|(s['rss']!=100).any(0);m=m[:,visible];p=p[:,visible]
    rss=s['rss'][:,visible];sxy,grp=np.unique(s['xy'],axis=0,return_inverse=True);grp=grp.ravel()
    prior=tpm.lookup(sxy,hxy,m)[grp];freq=tpm.lookup(sxy,hxy,p)[grp]
    single=tpm.dbm(rss);z=single-prior
    bins=categories(freq,rss!=100,z)
    sy=tpm.position_map(single,s['xy'])[0]
    # Supports with repeated scans share one spatial residual.
    unique=len(sxy)==len(rss)
    order=np.argsort(grp)
    proj=projection(hxy,sxy)
    def build(g):
        vz=g[bins]*z
        delta=vz[order] if unique else tpm.position_map(vz,s['xy'])[0]
        return np.vstack([np.clip(m+proj@delta,-110.,0.),sy])
    return build,np.vstack([hxy,sxy]),visible


def fit_map(histories,support,gain,coordinate_units_per_uji=1.):
    """Portable frozen conditional gain, real coordinates in caller units."""
    scale=float(coordinate_units_per_uji);g=np.asarray(gain,float)
    if g.shape!=(NBINS,) or np.any((g<0)|(g>2)) or not np.isfinite(g).all() or scale<=0:
        raise ValueError('Invalid gain table or coordinate scale')
    b=history_basis([normalized(h,scale) for h in histories])
    if not len(support['rss']):
        m,xy,_,hseen=b;return FingerprintMap(m[:,hseen],xy*scale,hseen)
    builder,xy,mask=updates(b,support,scale)
    return FingerprintMap(builder(g),xy*scale,mask)


def event_losses(b,s,q,models,scale):
    builder,xy,mask=updates(b,s,scale);query=q['rss'][:,mask]
    weights=q.get('weights')
    if weights is None:weights=position_weights(q['xy'])
    cache={};out={}
    for method,g in models.items():
        key=tuple(np.asarray(g,float))
        if key not in cache:
            w=tpm.tobit_weights(query,builder(np.asarray(g,float)),12.,-85.)
            xyhat=(w@(xy-xy[0])+xy[0])*scale
            cache[key]=float(weights@np.linalg.norm(xyhat-q['xy'],axis=1))
            if not np.isfinite(cache[key]):raise ValueError('Nonfinite MDE')
        out[method]=cache[key]
    return out


def localize(archive,stage,models):
    entries=[];last=None
    for meta,h,s,q in lib.episodes(archive,stage):
        key=meta['month'],meta['floor']
        if key!=last:
            basis=history_basis([normalized(h,METRES_PER_UNIT)]);last=key
        losses=event_losses(basis,s,q,models,METRES_PER_UNIT)
        entries.extend(dict(month=meta['month'],floor=meta['floor'],stage=stage,draw=meta['draw'],K=meta['K'],method=k,mde=v) for k,v in losses.items())
    return pd.DataFrame(entries)


def score_moments(stats,models):
    rows=[]
    for (t,f),g in stats.groupby(['month','floor']):
        g=g.sort_values('bin');d=g.support_energy.to_numpy();v=g.future_mean_energy.to_numpy();c=g.future_cross.to_numpy()
        for method,mult in models.items():
            mult=np.asarray(mult,float)
            pred=np.dot(d,mult**2)-2*np.dot(c,mult)+v.sum()
            rows.append(dict(month=t,floor=f,method=method,site_mean_MSE=float(pred),prior_site_MSE=float(v.sum()),
                             prior_single_scan_MSE=float(v.sum()+g.future_noise.sum()-g.future_repeat_count_inverse_noise.sum()),
                             within_site_variance=float(g.future_noise.sum())))
    return pd.DataFrame(rows)


def train(archive,out):
    out.mkdir(exist_ok=True,parents=True)
    src=paired_stats(archive,'source');src.to_csv(out/'temporal_source_moments.csv',index=False)
    models=fit_curves(src)
    valid=localize(archive,'validation',models);valid.to_csv(out/'temporal_validation.csv',index=False)
    risk=valid.groupby('method').mde.mean()
    chosen={'unit':'unit','no_propagation':'constant0.0','half':'constant0.5',
            'best_global':min((f'constant{v}' for v in SCALARS),key=lambda k:(risk[k],abs(float(k[8:])-1.))),
            'future_global':'future_global','same_global':'same_global'}
    for kind in ('future','same'):
        chosen[kind]=min((f'{kind}_{r}' for r in RIDGES),key=lambda k:risk[k])
    selected={k:models[v].tolist() for k,v in chosen.items()}
    record=dict(chosen=chosen,models=selected,all_candidates={k:v.tolist() for k,v in models.items()},validation_mde=risk.to_dict(),
                bins='3 * historic detection band (<.2, [.2,.8), >=.8) + {0=missed, 1=detected negative z, 2=detected nonnegative z}',
                paired_supervision='12 scans/location in t-1, each used as a separate R1 support. Future target = mean independent t at same XY; same-month control = mean of remaining t-1 scans at that XY. Bin-wise zero-intercept regression, gain bounds [0,2], ridge toward fitted global slope.',
                source='t=3..7, H=t-2, S=t-1, future=t. Equal month/floor/location/scans/APs permitted by H or own scan.',
                validation='t=10..15, choose one ridge per law by same spatially disjoint full-query post-S location MDE; strong scalar separately chosen on same validation.',
                sha256=lib.SHA256,metres_per_UJI_unit=METRES_PER_UNIT)
    (out/'temporal_frozen.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    score_moments(src,selected).to_csv(out/'temporal_source_forecast.csv',index=False)
    print('FROZEN',chosen, flush=True)


def test(archive,uji,frozen,out):
    models={k:np.array(v) for k,v in json.loads((out/'temporal_frozen.json').read_text())['models'].items()}
    for stage in ('late','late_A5'):
        localize(archive,stage,models).to_csv(out/f'temporal_{stage}.csv',index=False)
    score_moments(paired_stats(archive,'late'),models).to_csv(out/'temporal_late_forecast.csv',index=False)
    train=read_floors(uji,'trainingData.csv');official=read_floors(uji,'validationData.csv');rows=[]
    phones=pd.read_csv(uji/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    for mode,file in [('official','manifest.json'),('phone','device_stress_design.json')]:
        design=json.loads((frozen/file).read_text())
        for (b,f),t in train.items():
            for dev,hs,draws in eval_tasks(train,official,phones,design,b,f,mode):
                basis=history_basis(hs)
                for d,sr,q in draws:
                    for k in BUDGETS:
                        s={'rss':t['rss'][sr[:k]],'xy':t['xy'][sr[:k]]}
                        loss=event_losses(basis,s,q,models,1.)
                        rows.extend(dict(stage=mode,building=b,floor=f,draw=d,K=k,method=m,mde=e) for m,e in loss.items())
        print('SCORED',mode,flush=True)
    pd.DataFrame(rows).to_csv(out/'temporal_uji_transfer.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['train','test'])
    for name in ('archive','uji','frozen','out'):p.add_argument(name,type=Path)
    a=p.parse_args()
    if a.stage=='train':train(a.archive,a.out)
    else:test(a.archive,a.uji,a.frozen,a.out)
