"""LOBO cumulative source losses using true early/late labels and held-phone tasks."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from itertools import product
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.special import softmax
from residual_probe.episode_rows import nested_rows
from ..protocol import BUDGETS,SEEDS,read_floors,split_rows,history_floors,position_weights
from ..smooth_scale import local_rows
from ..summarize import INDEX
from .transport import source_design
from .map_variance import VarianceBank,QueryTerms,variance,SIGMAS,GAINS

GRID=tuple(product(SIGMAS,GAINS,GAINS))
TR,VA,PH={}, {},None


def init(data):
    global TR,VA,PH
    TR=read_floors(data,'trainingData.csv');VA=read_floors(data,'validationData.csv')
    PH=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()


def episodes(job,regime,source):
    b,f=job['building'],job['floor'];t=TR[b,f]
    hs=history_floors(TR,b,f)
    if regime=='period':
        q=VA[b,f]
        if source:
            orders=[nested_rows(t['xy'],range(len(t['rss'])),BUDGETS,0,f'early-late-src/{b}/{f}/{i}')['support_rows'][20] for i in range(3)]
        else:
            orders=[split_rows(t,b,f,i)[0] for i in SEEDS]
    else:
        dev=job['phone']
        hs=[{k:v[PH[h['ids']]!=dev] for k,v in h.items()} for h in hs]
        qr=local_rows(t,np.asarray(job['query_ids']));q={k:v[qr] for k,v in t.items()}
        orders=local_rows(t,np.asarray(job['support_orders']))
        if source:orders=orders[:3]
    bank=VarianceBank(hs)
    weight=position_weights(q['xy'])
    for draw,order in enumerate(orders):
        for k in BUDGETS:
            sr=order[:k]
            field=bank.condition(dict(rss=t['rss'][sr],xy=t['xy'][sr]))
            terms=QueryTerms(q['rss'][:,field.visible])
            yield draw,k,field,terms,q,weight


def risk(field,terms,v,q,weight):
    p=softmax(terms.scores(field.prototypes,v),axis=1)
    pred=p@(field.xy-field.xy[0])+field.xy[0]
    return float(weight@np.linalg.norm(pred-q['xy'],axis=1))


def source_job(args):
    regime,job=args
    total=np.zeros((2,len(GRID)))
    count=0
    for _,_,field,terms,q,weight in episodes(job,regime,True):
        for i,law in enumerate(('local','AP_mean')):
            w,b=field.statistics(law)
            for n,params in enumerate(GRID):
                if i and params[1:]==(0.,0.):
                    continue
                total[i,n]+=risk(field,terms,variance(w,b,params),q,weight)
        count+=1
    total/=count
    for n,params in enumerate(GRID):
        if params[1:]==(0.,0.):total[1,n]=total[0,n]
    print(f"Source {regime} B{job['building']}F{job['floor']}",flush=True)
    return [(regime,job['building'],job['floor'],job.get('phone',-1),law,*pa,total[i,n])
            for i,law in enumerate(('local','AP_mean')) for n,pa in enumerate(GRID)]


def select(table,held):
    if held!='external':table=table[table.building!=int(held)]
    v=table.groupby(['regime','building','floor','law','s','u','v']).mde.mean().groupby(
        ['regime','building','law','s','u','v']).mean()
    all_risk=v.groupby(['law','s','u','v']).mean()
    def best(grid,law='local',risk=all_risk):
        return [law,*min(grid,key=lambda x:risk.loc[(law,*x)])]
    full=best(GRID);_,s,u,b=full
    return dict(default=['local',12.,0.,0.],constant=best([p for p in GRID if p[1:]==(0.,0.)]),
        physical=['local',6.,1.,1.],moderate=['local',9.,.25,.25],full=full,
        AP_mean_fit=best(GRID,'AP_mean'),AP_mean_same=['AP_mean',s,u,b],shuffle_same=['shuffled',s,u,b],
        tied=best([p for p in GRID if p[1]==p[2]]),
        repeat_fit=best([p for p in GRID if p[2]==0]),between_fit=best([p for p in GRID if p[1]==0]),
        without_repeat=['local',s,0.,b],without_between=['local',s,u,0.],
        period_fit=best(GRID,risk=v.xs('period',level='regime').groupby(['law','s','u','v']).mean()),
        device_fit=best(GRID,risk=v.xs('device',level='regime').groupby(['law','s','u','v']).mean()))


def eval_job(args):
    regime,job,choices=args
    b,f=job['building'],job['floor']
    records=[]
    for draw,k,field,terms,q,weight in episodes(job,regime,False):
        statistics={law:field.statistics(law) for law in set(v[0] for v in choices.values())}
        values={};row=dict(building=b,floor=f,draw=draw,K=k)
        for name,valueset in choices.items():
            law,*pa=valueset;key=tuple(valueset)
            if key not in values:
                w,between=statistics[law]
                values[key]=risk(field,terms,variance(w,between,pa),q,weight)
            row[name]=values[key]
        if draw==0 and k==5:
            law,*pa=choices['full']
            direct=field.predict(q['rss'],pa,law)
            np.testing.assert_allclose(row['full'], weight@np.linalg.norm(direct-q['xy'],axis=1),rtol=0,atol=1e-10)
            w,bv=statistics['local'];ws,bs=statistics['shuffled']
            np.testing.assert_allclose(np.sort(variance(w,bv,pa),axis=0),np.sort(variance(ws,bs,pa),axis=0),rtol=0.,atol=0.)
        records.append(row)
    return records


def main(data,frozen,out,workers):
    out.mkdir(parents=True,exist_ok=True)
    init(data)
    floors=[dict(building=b,floor=f) for b,f in TR]
    with ProcessPoolExecutor(max_workers=workers,initializer=init,initargs=(data,)) as pool:
        src=list(pool.map(source_job,[('period',j) for j in floors]+[('device',j) for j in source_design(TR,PH)]))
        table=pd.DataFrame([row for t in src for row in t],columns=['regime','building','floor','phone','law','s','u','v','mde'])
        table.to_csv(out/'source_risks.csv',index=False)
        choices={str(b):select(table,b) for b in (0,1,2,'external')}
        record=dict(choices=choices,sigma_grid=SIGMAS,scale_grid=GAINS,
            source='Actual later official labels only from other source buildings plus their cross-phone internal pseudo tasks, three draws and five K. Source MDE averages Q positions, K/draw/device/floor/building and both regimes equally. External uses all three UJI buildings and their later labels.',
            map='Half10 measured-space historical mean with ordinary 40-unit S residual calibration; same real anchors. At every H cell, W is the finite empirical within-floor-position acquisition variance, and B is the variance of the contributing local/floor mean prototypes. Both use exact half10 history mixture weights. Added S coordinates receive 3-nearest H interpolation of W/B before observing their RSS. These score variances do not form a full latent posterior. A singleton history has W=0 by finite-population convention.',
            observation='sigma²=s²+u W+v B; detected RSS gets both squared error and log sigma, misses get log Φ((-85−m)/sigma). AP_mean averages variances over all actual candidates. Per-AP shuffle deranges spatial assignments jointly for W/B, exactly preserving the sigma histogram.')
        path=out/'fit.json';path.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
        cfg=json.loads(path.read_text())['choices']
        for mode,regime,jobs in [('official','period',floors),('phone','device',json.loads((frozen/'device_stress_design.json').read_text())['events'])]:
            results=list(pool.map(eval_job,[(regime,j,cfg[str(j['building'])]) for j in jobs]))
            d=pd.DataFrame([row for t in results for row in t])
            ref=pd.read_csv(frozen/('smooth_scale_official.csv' if mode=='official' else 'smooth_scale_phone.csv')).query("method=='half10'")
            np.testing.assert_allclose(d.set_index(INDEX).default.sort_index(),ref.set_index(INDEX).mde.sort_index(),rtol=0.,atol=1e-8)
            if len(d)!=650 or not np.isfinite(d.to_numpy()).all():raise ValueError('Invalid paired comparison')
            d.to_csv(out/(mode+'.csv'),index=False)
            print(mode,d.groupby(['building','K']).mean().groupby('building').mean().round(3),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','out'):p.add_argument(n,type=Path)
    p.add_argument('--workers',type=int,default=4)
    args=p.parse_args()
    main(args.data,args.frozen,args.out,args.workers)
