"""Cross-device, time-forward source tasks and exactly row-matched evaluation maps."""
from hashlib import sha256

import numpy as np
from external_baselines import tpm_adapter as tpm
from refi import smooth_history
from residual_probe.episode_rows import nested_rows
from ..device_stress import subset
from ..protocol import BUDGETS, SEEDS, history_floors, position_weights, split_rows


def _query_draw(indices, xy, key):
    points, group = np.unique(xy[indices], axis=0, return_inverse=True)
    rng = np.random.default_rng(int.from_bytes(sha256(key.encode()).digest()[:8], 'little'))
    choices = rng.choice(len(points), 12, replace=False)
    return np.array([rng.choice(indices[group.ravel() == i]) for i in choices])


def source_tasks(train, phones, times, b, f):
    target = train[b,f]
    ids = target['ids']
    all_history = history_floors(train,b,f)
    for phone in sorted(np.unique(phones[ids])):
        sites = np.flatnonzero(phones[ids] == phone)
        cutoff = np.median(times[ids[sites]])
        future = sites[times[ids[sites]] >= cutoff]
        past = np.flatnonzero((phones[ids] != phone) & (times[ids] < cutoff))
        if len(np.unique(target['xy'][future], axis=0)) < 12:
            continue
        history = [subset(h,(phones[h['ids']] != phone) & (times[h['ids']] < cutoff))
                   for h in all_history]
        history = [h for h in history if len(h['ids'])]
        if not history or len(np.unique(np.vstack([h['xy'] for h in history]),axis=0)) < 3:
            continue
        draws = []
        for d in range(4):
            key = f'uji-offset-source-v1/{b}/{f}/{phone}/{d}'
            qrows = _query_draw(future,target['xy'],key)
            excluded = set(map(tuple,target['xy'][qrows]))
            eligible = [i for i in past if tuple(target['xy'][i]) not in excluded]
            if len(np.unique(target['xy'][eligible],axis=0)) < max(BUDGETS):
                break
            ordered = nested_rows(target['xy'],eligible,BUDGETS,0,key+'/s')['support_rows'][max(BUDGETS)]
            draws.append((d,np.asarray(ordered),subset(target,qrows)))
        if len(draws) == 4:
            yield int(phone), history, draws


def eval_tasks(train, official, phones, frozen, b, f, mode):
    target = train[b,f]
    history = history_floors(train,b,f)
    # Use the frozen row identities directly; do not select any new Q or S.
    if mode == 'official':
        drawmap = {(x['building'],x['floor'],x['draw']):x for x in frozen['episodes']}
        draws = []
        for d in SEEDS:
            ordered, _ = split_rows(target,b,f,d)
            entry = drawmap[b,f,d]
            q = official[b,f]
            assert target['ids'][ordered].tolist() == entry['support_order']
            assert q['ids'].tolist() == entry['query_ids']
            draws.append((d,ordered,q))
        return [(None,history,draws)]
    entry = next(x for x in frozen['events'] if (x['building'],x['floor']) == (b,f))
    dev = entry['phone']
    lookup = {row:i for i,row in enumerate(target['ids'])}
    qr = [lookup[x] for x in entry['query_ids']]
    q = subset(target,qr)
    h = [subset(a,phones[a['ids']] != dev) for a in history]
    h = [a for a in h if len(a['ids'])]
    draws = [(d,np.array([lookup[i] for i in order]),q) for d,order in zip(SEEDS,entry['support_orders'])]
    assert (phones[q['ids']] == dev).all()
    assert all((phones[target['ids'][s]] != dev).all() for _,s,_ in draws)
    return [(dev,h,draws)]


def maps(train, b, f, tasks):
    target = train[b,f]
    for phone, history, draws in tasks:
        prototypes,hxy = smooth_history(tpm.history_map(history,None,None),10.,.5)
        hseen = np.logical_or.reduce([(h['rss'] != 100).any(0) for h in history])
        for d, ordered, q in draws:
            for k in BUDGETS:
                rows = ordered[:k]
                rss = target['rss'][rows]
                visible = hseen | (rss != 100).any(0)
                s = dict(rss=rss[:,visible],xy=target['xy'][rows])
                m,xy = tpm.calibrate((prototypes[:,visible],hxy),s,(40.,1.))
                yield dict(building=b,floor=f,phone=phone,draw=d,K=k,
                           support_ids=target['ids'][rows],query_ids=q['ids'],
                           history_scans=sum(len(h['ids']) for h in history),
                           query=q['rss'][:,visible],prototypes=m,xy=xy,
                           truth=q['xy'],weight=position_weights(q['xy']))
