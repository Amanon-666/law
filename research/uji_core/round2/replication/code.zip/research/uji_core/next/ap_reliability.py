"""Learn an exchangeable AP reliability rule from other buildings' location tasks.

Only each AP's within-bank spatial variation, repeatability, redundancy and
support mismatch are used. No cross-building AP identity, Q labels or device
ID are needed for inference. A uniform rule recovers the published estimator.
"""
import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr, softmax
from scipy.stats import rankdata

from external_baselines import tpm_adapter as tpm
from refi import smooth_history
from ..protocol import BUDGETS, SEEDS, read_floors, position_weights, split_rows
from ..smooth_scale import local_rows
from .transport import source_design

NAMES=('frequency','spatial_stability','independence','support_agreement')
# One positive or negative association per feature. An intercept controls the
# total score temperature. Each profile is positive and has within-task mean 1.
def profiles(raw):
    ranks=np.array([2*(rankdata(v,method='average')-.5)/len(v)-1 for v in raw])
    a=np.vstack((np.ones(len(ranks[0])),np.exp(1.5*ranks),np.exp(-1.5*ranks)))
    return a/a.mean(axis=1,keepdims=True)


class ReceiverBank:
    def __init__(self, histories, unit=1.):
        self.unit=unit
        self.m,self.xy=smooth_history(tpm.history_map(histories,None,None),10*unit,.5)
        self.mask=np.logical_or.reduce([(h['rss']!=100).any(0) for h in histories])
        within=[];rates=[]
        for h in histories:
            y=tpm.dbm(h['rss'])
            mu,xy=tpm.position_map(y,h['xy'])
            m2,_=tpm.position_map(y*y,h['xy'])
            within.append(np.maximum(m2-mu*mu,0).mean(0))
            rates.append((h['rss']!=100).mean(0))
        self.rate=np.mean(rates,axis=0)
        self.within=np.mean(within,axis=0)
        self.spatial=self.m.var(0)
        centered=self.m-self.m.mean(0)
        normalized=centered/np.maximum(np.linalg.norm(centered,axis=0),1e-6)
        corr=np.maximum(normalized.T @ normalized,0)
        np.fill_diagonal(corr,0)
        self.independence=1/(1+(corr**4).sum(1))

    def adapt(self,srss,sxy):
        mask=self.mask | (srss!=100).any(0)
        m=self.m[:,mask]
        rss=srss[:,mask]
        fitted,loc=tpm.calibrate((m,self.xy),dict(rss=rss,xy=sxy),(40*self.unit,1.))
        expected=tpm.lookup(sxy,self.xy,m)
        # Where neither side has appreciable signal, a match of two missing
        # entries gives almost no information about this AP's transfer quality.
        a=(np.maximum(expected+110.,tpm.dbm(rss)+110.)/30.).clip(0,1)
        diff=(tpm.dbm(rss)-expected)**2
        noise0=self.within[mask]+36.
        variance=(2*noise0+(a*diff).sum(0))/(2+a.sum(0))
        features=(self.rate[mask],self.spatial[mask]/(self.within[mask]+36.),
                  self.independence[mask],-np.log(variance/noise0))
        return fitted,loc,mask,profiles(features)


def scores(proto,q,weight):
    det=(q!=100).astype(float)
    y=tpm.dbm(q)*det
    # Terms constant across candidate locations cancel on normalization.
    return ((y*weight) @ proto.T - .5*(det*weight) @ (proto*proto).T)/144. + ((1-det)*weight) @ log_ndtr((-85.-proto)/12.).T


@dataclass
class Episode:
    x: np.ndarray  # (queries, candidates, profiles), centered per query
    xy: np.ndarray
    truth: np.ndarray
    qw: np.ndarray


def episode(bank, s, q, shuffled=False):
    m,xy,mask,basis=bank.adapt(s['rss'],s['xy'])
    if shuffled:
        # A pre-fixed permutation WITHIN prevalence quintiles. The learned
        # coefficients, AP histogram, map and extra supervision stay fixed.
        rng=np.random.default_rng(816)
        order=np.argsort(bank.rate[mask],kind='stable')
        ix=np.arange(len(order))
        for group in np.array_split(order,5):
            ix[group]=rng.permutation(group)
        basis=basis[:,ix]
    part=np.stack([scores(m,q['rss'][:,mask],v) for v in basis],axis=2)
    part-=part.mean(1,keepdims=True)
    return Episode(part.astype('f'),xy-xy[0],q['xy']-xy[0],position_weights(q['xy']))


def objective(a,ep,grad=False):
    x=ep.x
    prob=softmax(x @ a,axis=1)
    mean=prob@ep.xy
    delta=mean-ep.truth
    e=np.linalg.norm(delta,axis=1)
    loss=ep.qw @ e
    if not grad:
        return loss
    direction=delta*(ep.qw/np.maximum(e,1e-8))[:,None]
    dscore=prob*(direction@ep.xy.T-(direction*mean).sum(1)[:,None])
    return loss,np.einsum('qc,qcp->p',dscore,x)


def make_jobs(train,phones,jobs,mode,official=None,shuffle=False,limit=None):
    data=[]
    for job in jobs:
        b,f=job['building'],job['floor']
        t=train[b,f]
        hist=[h for (hb,hf),h in train.items() if hb==b and hf!=f]
        if mode=='official':
            q=official[b,f]
            orders=[split_rows(t,b,f,d)[0] for d in SEEDS]
        else:
            hist=[{k:v[phones[h['ids']]!=job['phone']] for k,v in h.items()} for h in hist]
            hist=[h for h in hist if len(h['rss'])]
            iq=local_rows(t,np.asarray(job['query_ids']))
            q={k:v[iq] for k,v in t.items()}
            orders=local_rows(t,np.asarray(job['support_orders']))
        bank=ReceiverBank(hist)
        for d,order in enumerate(orders[:limit]):
            for k in BUDGETS:
                sr=order[:k];s={key:v[sr] for key,v in t.items()}
                yield (b,f,job.get('phone',-1),d,k),episode(bank,s,q,shuffle)


def fit(rows,cols):
    # Equal buildings, floors, source devices, draws and K. Besides the fitted
    # temperature, compare against a tuned single profile without a feature mix.
    keys=pd.DataFrame([s for s,e in rows],columns=['b','f','device','d','K'])
    wt=np.ones(len(keys))
    for group,value in (([], 'b'),(['b'],'f'),(['b','f'],'device'),(['b','f','device'],'d'),(['b','f','device','d'],'K')):
        wt/= keys.groupby(group)[value].transform('nunique').values if group else keys[value].nunique()
    prior=np.zeros(9);prior[0]=1.
    def calc(t):
        a=np.zeros(9);a[cols]=t
        v,g=0.,np.zeros(9)
        for w,(_,ep) in zip(wt,rows):
            loss,grad=objective(a,ep,True);v+=w*loss;g+=w*grad
        # Fixed weak ridge in UJI MDE units. Folds never select regularization.
        diff=a-prior
        return v+.1*np.dot(diff,diff), (g+.2*diff)[cols]
    start=np.zeros(len(cols));start[0]=1.
    r=minimize(calc,start,jac=True,method='L-BFGS-B',bounds=[(.03,2.5) if c==0 else (0.,2.5) for c in cols],
               options={'maxiter':60,'ftol':1e-8,'gtol':1e-5})
    out=np.zeros(9);out[cols]=r.x
    return out, dict(converged=bool(r.success), objective=float(r.fun),message=str(r.message))


def main(data, manifest, out):
    out.mkdir(parents=True,exist_ok=True)
    tr=read_floors(data,'trainingData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    rows=list(make_jobs(tr,phones,source_design(tr,phones),'source',limit=2))
    identity=np.zeros(9);identity[0]=1.
    configs={};checks={}
    for held in (0,1,2,'external'):
        subset=[(s,e) for s,e in rows if s[0]!=held]
        uniform,rs=fit(subset,[0])
        full,rf=fit(subset,list(range(9)))
        # Same nonuniform feature basis with a fixed model: independently
        # discount correlated APs and favor stable APs by half apiece.
        fixed=np.zeros(9);fixed[2]=fixed[3]=.5
        single=[fit(subset,[0,1+i,5+i]) for i in range(len(NAMES))]
        j=min(range(len(single)),key=lambda i:single[i][1]['objective'])
        idf=np.zeros(9);idf[5]=1.
        configs[str(held)]={k:v.tolist() for k,v in dict(identity=identity,temperature=uniform,
            fixed_quality=fixed,fixed_rarity=idf,source_single=single[j][0],learned=full).items()}
        checks[str(held)]=dict(temperature=rs,learned=rf,best_single=NAMES[j])
    file=out/'fit.json';file.write_text(json.dumps(dict(configs=configs,checks=checks,features=NAMES),indent=2)+'\n')
    del rows
    cfg=json.loads(file.read_text())['configs']
    va=read_floors(data,'validationData.csv')
    for mode,jobs in [('official',[{'building':b,'floor':f} for b,f in tr]),('phone',json.loads(manifest.read_text())['events'])]:
        results=[]
        for shuffled in (False,True):
            for (b,f,dev,draw,k),ep in make_jobs(tr,phones,jobs,mode,va,shuffled):
                arms={'shuffled':cfg[str(b)]['learned']} if shuffled else cfg[str(b)]
                for name,param in arms.items():
                    results.append((b,f,draw,k,name,objective(np.array(param),ep)))
        pd.DataFrame(results,columns=['building','floor','draw','K','method','mde']).to_csv(out/(mode+'.csv'),index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','manifest','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.manifest,a.out)
