"""One local smoothing coefficient per candidate and AP, determined by H only."""
import numpy as np
from scipy.spatial.distance import cdist
from scipy.special import expit
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, _scans

NAMES=('intercept','log_repeat_variance','log_between_variance','signed_smoothing_contrast','detection_frequency')


class HistorySmoother:
    def __init__(self, histories, gaps, unit=1.):
        if len(histories)!=len(gaps):
            raise ValueError('Supply a floor-index difference for every history')
        pairs=[(h,float(g)) for h,g in zip(histories,gaps) if len(h['rss'])]
        if not pairs or unit<=0 or not np.isfinite(unit):
            raise ValueError('Require a history and positive coordinate unit')
        width=np.asarray(pairs[0][0]['rss']).shape[1]
        hs=[_scans(h,width) for h,g in pairs]
        z=np.abs(np.array([g for h,g in pairs]))
        if not np.isfinite(z).all():raise ValueError('Nonfinite floor gap')
        reliability=np.exp(np.maximum(-2*(z-z.min()),-100.))
        self.unit=unit
        self.hseen=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
        cols=[];coords=[]
        for h in hs:
            y=tpm.dbm(h['rss'])
            raw,x=tpm.position_map(np.column_stack((y,y*y,h['rss']!=100)),h['xy'])
            m,second,p=np.hsplit(raw,3)
            cols.append(np.column_stack((m,np.maximum(second-m*m,0.),m*m,p)))
            coords.append(x)
        self.xy,loc=np.unique(np.vstack(coords),axis=0,return_inverse=True);loc=loc.ravel()
        w=np.repeat(reliability,[len(x) for x in coords]);total=np.bincount(loc,weights=w)
        values=np.vstack(cols)
        pooled=np.zeros((len(self.xy),values.shape[1]))
        np.add.at(pooled,loc,w[:,None]*values)
        pooled/=total[:,None]
        density=total/np.bincount(loc)
        spatial=np.exp(-cdist(self.xy,self.xy,'sqeuclidean')/(2*(10.*unit)**2))*density
        neighbor=(spatial/spatial.sum(1,keepdims=True))@pooled
        self.raw=np.hsplit(pooled,4)[0]
        self.contrast=np.hsplit(neighbor,4)[0]-self.raw
        mean,W,second,P=np.hsplit(.5*(pooled+neighbor),4)
        B=np.maximum(second-mean*mean,0.)
        self.ratio=np.divide(W,W+B,out=np.full_like(W,.5),where=(W+B)>1e-8)
        inputs=[np.log1p(W/144.),np.log1p(B/144.),np.tanh(self.contrast/12.),P]
        cols=[np.ones_like(self.raw)]
        for v in inputs:
            active=v[:,self.hseen]
            center=active.mean() if active.size else 0.
            sd=active.std() if active.size else 1.
            cols.append(np.clip((v-center)/max(sd,.05),-3.,3.))
        self.features=np.stack(cols,axis=-1)
        self.permutation=np.empty(self.raw.shape,dtype=int)
        for ap in range(width):
            order=np.random.default_rng(79631+ap).permutation(len(self.xy))
            self.permutation[order,ap]=np.roll(order,1)

    def prior(self, theta, mode='learned'):
        if mode=='fixed_ratio':
            g=self.ratio
        elif mode=='half':
            g=.5
        else:
            theta=np.asarray(theta,dtype=float)
            if theta.shape!=(len(NAMES),) or not np.isfinite(theta).all():
                raise ValueError('Require five frozen finite coefficients')
            g=expit(self.features@theta)
            if mode=='shuffled':
                g=np.take_along_axis(g,self.permutation,axis=0)
            elif mode=='AP_mean':
                g=g.mean(0,keepdims=True)
            elif mode!='learned':
                raise ValueError('Unknown smoothing control')
        return self.raw+self.contrast*g

    def condition(self,support,theta,mode='learned'):
        rss=np.asarray(support['rss']);xy=np.asarray(support['xy'])
        active=self.hseen|(rss!=100).any(0)
        proto,loc=tpm.calibrate((self.prior(theta,mode)[:,active],self.xy),
              dict(rss=rss[:,active],xy=xy),(40.*self.unit,1.))
        return FingerprintMap(proto,loc,active)
