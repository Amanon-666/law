"""Learn one AP-permutation-invariant comparison table on post-S location error.

The table adjusts the relative score of observed/expected RSS pairs. It is
linear in its coefficients, bounded, and shared across APs, floors and sites.
Fit on true early support / later queries and separate-phone episodes, only
in OTHER buildings. The parent map uses known floor gaps.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr, softmax
from refi import historical_prior
from external_baselines import tpm_adapter as tpm
from ..protocol import BUDGETS, SEEDS, read_floors, position_weights, split_rows
from ..smooth_scale import local_rows
from residual_probe.episode_rows import nested_rows
from .transport import source_design

OBS=np.array([-95.,-75.,-55.])
MAP=np.array([-110.,-95.,-80.,-65.,-50.])
N=1+(1+len(OBS))*len(MAP)


def spline(x,grid):
    i=np.clip(np.searchsorted(grid,x)-1,0,len(grid)-2)
    t=np.clip((x-grid[i])/(grid[i+1]-grid[i]),0,1)
    return np.stack([(1-t)*(i==k)+t*(i+1==k) for k in range(len(grid))])


def design_matrix(m,q):
    seen=q!=100;d=seen.astype(float)
    y=tpm.dbm(q)*d
    # A query-specific additive constant cancels in the coordinate posterior.
    fixed=(y@m.T-.5*d@(m*m).T)/144.+(1.-d)@log_ndtr((-85.-m)/12.).T
    ob=np.concatenate(((~seen)[None],spline(tpm.dbm(q),OBS)*seen),axis=0)
    mp=spline(m,MAP)
    xx=np.stack([fixed,*[v@u.T for v in ob for u in mp]],axis=-1)
    return (xx-xx.mean(1,keepdims=True)).astype(np.float32)


def predict(target_map,q,beta):
    out=[]
    for i in range(0,len(q),48):
        x=design_matrix(target_map.prototypes,q[i:i+48,target_map.visible])
        out.append(softmax(x@beta,axis=1)@(target_map.xy-target_map.xy[0])+target_map.xy[0])
    return np.vstack(out) if out else np.empty((0,2))


def data_stream(tr,va,phones,js,period,source):
    for j in js:
        b,f=j['building'],j['floor'];t=tr[b,f]
        h=[(abs(hf-f),v) for (hb,hf),v in tr.items() if hb==b and hf!=f]
        if period:
            q=va[b,f]
            if source:
                orders=[nested_rows(t['xy'],range(len(t['xy'])),BUDGETS,0,f'score-tab-src/{b}/{f}/{d}')['support_rows'][20] for d in range(3)]
            else:orders=[split_rows(t,b,f,d)[0] for d in SEEDS]
        else:
            h=[(g,{key:v[phones[hh['ids']]!=j['phone']] for key,v in hh.items()}) for g,hh in h]
            h=[(g,hh) for g,hh in h if len(hh['rss'])]
            iq=local_rows(t,np.asarray(j['query_ids']))
            q={key:v[iq] for key,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))[:3 if source else len(SEEDS)]
        hs=[v for _,v in h]
        m,xy=historical_prior(hs,10.,.5,[g for g,_ in h])
        hm=np.logical_or.reduce([(v['rss']!=100).any(0) for v in hs])
        for draw,order in enumerate(orders):
            qry=q
            if period and source:
                # Disjoint positions sampled uniformly; source supervision is
                # actual late data, with no target-building rows in its fit.
                loc,rev=np.unique(q['xy'],axis=0,return_inverse=True)
                rng=np.random.default_rng(5390+b*200+f*7+draw)
                ix=[rng.choice(np.flatnonzero(rev.ravel()==i)) for i in rng.choice(len(loc),min(32,len(loc)),False)]
                qry={key:v[ix] for key,v in q.items()}
            for k in BUDGETS:
                sr=order[:k];rss=t['rss'][sr]
                mask=hm|(rss!=100).any(0)
                proto,z=tpm.calibrate((m[:,mask],xy),dict(rss=rss[:,mask],xy=t['xy'][sr]),(40.,1.))
                x=design_matrix(proto,qry['rss'][:,mask])
                yield (b,f,int(period),j.get('phone',-1),draw,k),(x,z-z[0],qry['xy']-z[0],position_weights(qry['xy']))


def error(e,a,gradient=False):
    x,z,truth,weight=e
    p=softmax(x@a,axis=1)
    xy=p@z
    diff=xy-truth
    err=np.linalg.norm(diff,axis=1)
    val=weight@err
    if not gradient:return val
    direction=diff*(weight/np.maximum(err,1e-8))[:,None]
    dlogit=p*(direction@z.T-np.einsum('qi,qi->q',direction,xy)[:,None])
    return val,np.einsum('qc,qcn->n',dlogit,x)


def parameter_map(kind):
    if kind=='full':return np.eye(N)
    # Same scoring range but allow only one curve for all detected readings.
    ncol=len(MAP)
    if kind=='detection':
        a=np.zeros((N,1+2*ncol));a[0,0]=1.
        a[1:1+ncol,1:1+ncol]=np.eye(ncol)
        a[1+ncol:,1+ncol:]=np.tile(np.eye(ncol),(len(OBS),1))
        return a
    return np.eye(N)[:,:1]


def fit(rows,kind,regularization):
    labels=pd.DataFrame([s for s,_ in rows],columns=['b','f','regime','dev','d','K'])
    mass=np.ones(len(labels))
    grp=[]
    for c in ('b','regime','f','dev','d','K'):
        mass/=labels.groupby(grp)[c].transform('nunique').values if grp else labels[c].nunique()
        grp.append(c)
    matrix=parameter_map(kind)
    prior=np.zeros(N);prior[0]=1.
    def fun(v):
        a=matrix@v
        risk=0.;g=np.zeros(N)
        for w,(_,e) in zip(mass,rows):
            l,grad=error(e,a,True);risk+=w*l;g+=w*grad
        delta=a-prior
        # Ridge in mean-error units, preset; no target data selects the fit.
        return risk+regularization*np.dot(delta,delta),matrix.T@(g+2*regularization*delta)
    x=np.zeros(matrix.shape[1]);x[0]=1.
    r=minimize(fun,x,jac=True,method='L-BFGS-B',bounds=[(.4,2.)]+[(-1.5,1.5)]*(len(x)-1),
               options=dict(maxiter=75,ftol=2e-8,gtol=1e-5))
    return list(matrix@r.x),dict(success=bool(r.success),iterations=r.nit,objective=r.fun,message=str(r.message))


def main(data,design,out):
    out.mkdir(exist_ok=True,parents=True)
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=[dict(building=b,floor=f) for b,f in tr]
    rows=list(data_stream(tr,va,phones,jobs,True,True))
    rows+=list(data_stream(tr,va,phones,source_design(tr,phones),False,True))
    cfg={};diag={}
    for b in (0,1,2,'external'):
        subset=[r for r in rows if r[0][0]!=b]
        params={'identity':[1.]+[0.]*(N-1)};d={}
        for name,kind,reg in [('temperature','temperature',.1),('detection','detection',.1),('learned','full',.1),('conservative','full',.4)]:
            params[name],d[name]=fit(subset,kind,reg)
        # Retain missing-row behavior, destroy the fitted link between actual
        # measured signal strength and the map. Coefficient magnitudes match.
        full=np.array(params['learned']); coef=full[1:].reshape(4,5).copy()
        coef[1:]=coef[1:][::-1]
        params['swap_strength']=np.r_[full[0],coef.ravel()].tolist()
        cfg[str(b)]=params;diag[str(b)]=d
    fp=out/'fit.json';fp.write_text(json.dumps(dict(configs=cfg,fits=diag),indent=2)+'\n')
    del rows
    cfg=json.loads(fp.read_text())['configs']
    for name,period,js in [('official',True,jobs),('phone',False,json.loads(design.read_text())['events'])]:
        records=[]
        for (b,f,r,dev,d,k),episode in data_stream(tr,va,phones,js,period,False):
            for method,coef in cfg[str(b)].items():
                records.append((b,f,d,k,method,error(episode,np.array(coef))))
        pd.DataFrame(records,columns=['building','floor','draw','K','method','mde']).to_csv(out/(name+'.csv'),index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','design','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.design,a.out)
