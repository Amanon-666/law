"""Cross-fit a target fingerprint template from the other labeled H floors.

Hold each floor in H out in turn. At its real positions, use the remaining
floors to predict the fingerprint, then learn the linear residual of that
prediction. Ridge shrinks the operator to the identity map. It is learned
within one aligned AP catalogue; no AP identity is transferred between sites.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.linalg import solve
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, smooth_history
from .transport import source_design
from ..protocol import BUDGETS, SEEDS, read_floors, split_rows, position_weights
from ..smooth_scale import local_rows

RIDGES=(.1,1.,10.)
KINDS=('global','diagonal','joint')


def prior(h,unit):
    return smooth_history(tpm.history_map(h,None,None),10.*unit,.5)


class ProjectedBank:
    def __init__(self,hist,unit=1.):
        self.unit=unit
        self.base,self.xy=prior(hist,unit)
        self.mask=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hist])
        # Balance floors and positions, rather than giving densely repeated
        # reference points more influence on what transfers between floors.
        xs=[];ys=[]
        for j,h in enumerate(hist):
            others=[v for i,v in enumerate(hist) if j!=i]
            if not others:continue
            obs,xy=tpm.position_map(tpm.dbm(h['rss'][:,self.mask]),h['xy'])
            m,z=prior(others,unit)
            x=tpm.lookup(xy,z,m[:,self.mask])+110.
            mass=np.sqrt(len(hist)*len(xy))
            xs.append(x/mass);ys.append((obs+110.-x)/mass)
        self.maps={('identity',0.):self.base}
        if xs:
            x=np.vstack(xs);y=np.vstack(ys)
            self.xx=x.T@x
            self.xy_res=x.T@y
        else:
            self.xx=self.xy_res=None

    def map(self,kind,ridge):
        key=kind,ridge
        if key in self.maps:return self.maps[key]
        if self.xx is None:return self.base
        scale=self.xx.diagonal()+25.  # dB^2, prevents brittle rare-AP extrapolation
        penalty=np.diag(ridge*scale)
        if kind=='global':
            d=np.eye(len(scale))*(np.trace(self.xy_res)/(np.trace(self.xx)+np.trace(penalty)))
        elif kind=='diagonal':
            d=np.diag(np.diag(self.xy_res)/(np.diag(self.xx)+np.diag(penalty)))
        else:
            d=solve(self.xx+penalty,self.xy_res,assume_a='pos')
            if kind=='shuffled':
                rng=np.random.default_rng(14319)
                ix=np.arange(len(scale))
                for g in np.array_split(np.argsort(scale,kind='stable'),5):ix[g]=rng.permutation(g)
                d=d[np.ix_(ix,ix)].copy()
        m=self.base.copy()
        # Clip the shift (not the fingerprint) to a physical one-floor
        # correction scale. Same cap applies to every arm.
        m[:,self.mask]+=np.clip((m[:,self.mask]+110.)@d,-15.,15.)
        self.maps[key]=np.clip(m,-110.,0.)
        return self.maps[key]

    def condition(self,s,kind,ridge):
        mask=self.mask|(s['rss']!=100).any(0)
        m=self.map(kind,ridge)[:,mask]
        sig,xy=tpm.calibrate((m,self.xy),dict(rss=s['rss'][:,mask],xy=s['xy']),(40*self.unit,1.))
        return FingerprintMap(sig,xy,mask)


def evaluate(tr,phones,jobs,arms=None,va=None,limit=None):
    records=[]
    for j in jobs:
        b,f=j['building'],j['floor']
        t=tr[b,f]
        hs=[h for (hb,hf),h in tr.items() if hb==b and hf!=f]
        if va is None:
            hs=[{k:v[phones[h['ids']]!=j['phone']] for k,v in h.items()} for h in hs]
            hs=[h for h in hs if len(h['rss'])]
            qid=local_rows(t,np.asarray(j['query_ids']))
            q={k:v[qid] for k,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))
        else:
            q=va[b,f]
            orders=[split_rows(t,b,f,i)[0] for i in SEEDS]
        bank=ProjectedBank(hs)
        w=position_weights(q['xy'])
        models=arms[str(b)] if arms else {'identity':('identity',0.),**{f'{k}_{r}':(k,r) for k in KINDS for r in RIDGES}}
        for draw,order in enumerate(orders[:limit]):
            for k in BUDGETS:
                s={ky:v[order[:k]] for ky,v in t.items()}
                cache={}
                for name,(kind,ridge) in models.items():
                    param=kind,ridge
                    if param not in cache:
                        m=bank.condition(s,kind,ridge)
                        cache[param]=w @ np.linalg.norm(m.predict(q['rss'])-q['xy'],axis=1)
                    records.append((b,f,draw,k,name,kind,ridge,cache[param]))
    return pd.DataFrame(records,columns=['building','floor','draw','K','method','kind','ridge','mde'])


def main(data,design,out):
    out.mkdir(exist_ok=True,parents=True)
    train=read_floors(data,'trainingData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    src=evaluate(train,phones,source_design(train,phones),limit=3)
    risk=src.groupby(['building','floor','kind','ridge']).mde.mean().groupby(['building','kind','ridge']).mean()
    risk.to_csv(out/'source.csv')
    cfg={}
    for b in [0,1,2,'external']:
        r=(risk if b=='external' else risk.drop(b,level='building')).groupby(['kind','ridge']).mean()
        choices={k:min(((k,l) for l in RIDGES),key=lambda c:r.loc[c]) for k in KINDS}
        best=min([('identity',0.)]+list(choices.values()),key=lambda c:r.loc[c])
        cfg[str(b)]=dict(identity=('identity',0.),**choices,selected=best,
                         fixed_ridge=('joint',1.),shuffled_joint=('shuffled',choices['joint'][1]))
    file=out/'fit.json';file.write_text(json.dumps(cfg,indent=2)+'\n')
    arms=json.loads(file.read_text())
    va=read_floors(data,'validationData.csv')
    evaluate(train,phones,[dict(building=b,floor=f) for b,f in train],arms,va).to_csv(out/'official.csv',index=False)
    evaluate(train,phones,json.loads(design.read_text())['events'],arms).to_csv(out/'phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','design','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.design,a.out)
