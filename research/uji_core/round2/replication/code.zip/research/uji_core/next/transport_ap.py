"""Learn per-AP support-update gains from other floors within the allowed H bank.

Uses a new H-only pseudo-target study for each actual target floor and H-device
restriction. Nothing is learned from a deployment target's S or Q. To reproduce:
  python -m research.uji_core.next.transport_ap DATA FROZEN_RESULTS OUT --workers 3
"""
import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import random

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr, softmax
from threadpoolctl import threadpool_limits

from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, smooth_history
from residual_probe.episode_rows import nested_rows
from ..forward import MATCH
from ..protocol import BUDGETS, SEEDS, HASHES, read_floors, history_floors, split_rows, position_weights
from ..smooth_scale import local_rows
from .transport_loo import correction_map

PENALTIES=(.25,1.,4.)
TRAIN_DRAWS=4
VALID_DRAWS=2
SIGMA=12.
THRESHOLD=-85.


def subset(h,ix):
    return {k:v[ix] for k,v in h.items()}


def prior_map(hs):
    return smooth_history(tpm.history_map(hs,None,None),10.,.5)


def update_parts(m,xy,s):
    sy,sxy,delta,_,_=correction_map(m,xy,s['rss'],s['xy'])
    return sy,sxy,delta


def apply_ap_gain(histories,support,gains):
    """Gain length follows the caller's aligned AP catalogue, new AP defaults to 1."""
    hs=[h for h in histories if len(h['rss'])]
    if not hs:
        raise ValueError('At least one historical scan is required')
    g=np.asarray(gains,dtype=float)
    if g.ndim!=1 or len(g)!=support['rss'].shape[1] or not np.isfinite(g).all() or (g<0).any() or (g>2).any():
        raise ValueError('Expect one bounded finite gain per catalogue AP')
    mask=np.logical_or.reduce([(v['rss']!=100).any(0) for v in [*hs,support]])
    full,xy=prior_map(hs)
    m=full[:,mask]
    if not len(support['xy']):
        return FingerprintMap(m,xy,mask)
    sy,sxy,delta=update_parts(m,xy,{'rss':support['rss'][:,mask],'xy':support['xy']})
    return FingerprintMap(np.vstack([np.clip(m+delta*g[mask],-110.,0.),sy]),np.vstack([xy,sxy]),mask)


class Task:
    def __init__(self,m,delta,xy,sy,sxy,q,truth,mask):
        self.m,self.delta,self.mask=m,delta,mask
        self.xy=np.vstack([xy,sxy])-xy[0]
        self.truth=truth-xy[0]
        self.seen=(q!=100).astype(float)
        self.missed=1.-self.seen
        self.query=np.where(q!=100,q.astype(float)+75.,0.)
        self.anchor_score=self.score(sy)[0]
        self.weight=position_weights(truth)

    def score(self,m):
        v=m+75.
        trunc=(THRESHOLD-m)/SIGMA
        lp=log_ndtr(trunc)
        # Omit the query-only Gaussian constant. It cancels on normalization.
        score=(self.query@v.T-.5*self.seen@(v*v).T)/SIGMA**2 + self.missed@lp.T
        return score,lp,trunc

    def risk(self,g,grad):
        u=self.m+self.delta*g[self.mask]
        m=np.clip(u,-110.,0.)
        l,lp,t=self.score(m)
        p=softmax(np.hstack([l,self.anchor_score]),axis=1)
        pred=p@self.xy
        error=pred-self.truth
        norm=np.linalg.norm(error,axis=1)
        value=self.weight@norm
        if grad is None:
            return value
        direction=error/np.maximum(norm[:,None],1e-12)
        # JVP through coordinate expectation and per-query softmax. Actual S
        # anchors remain unmodified, so only H receives an RSS derivative.
        slope=self.weight[:,None]*p[:,:len(m)]*(direction@self.xy[:len(m)].T-(direction*pred).sum(1,keepdims=True))
        inv_mills=np.exp(-.5*t*t-.5*np.log(2*np.pi)-lp)/SIGMA
        dfield=(slope.T@self.query-(slope.T@self.seen)*(m+75.))/SIGMA**2-(slope.T@self.missed)*inv_mills
        grad[self.mask]+=np.sum(dfield*self.delta*(u>-110.)*(u<0.),axis=0)
        return value


def pseudo_tasks(hs):
    # Split entire historical coordinates before building *any* pseudo-history.
    # Source validation positions therefore enter neither training query labels
    # nor training fingerprint maps. Refit the deployment map later on all H.
    blocks=[]
    for hi,h in enumerate(hs):
        points,ix=np.unique(h['xy'],axis=0,return_inverse=True)
        ids=list(range(len(points)))
        random.Random(f'ap-gain-v1/floor{hi}/partition').shuffle(ids)
        nval=min(12,max(4,len(ids)//5))
        valid=np.isin(ix.ravel(),ids[:nval])
        blocks.append((subset(h,~valid),np.flatnonzero(valid)))
    training=[];validation=[];meta=[]
    for hi,(t,valrows) in enumerate(blocks):
        other=[b[0] for j,b in enumerate(blocks) if j!=hi and len(b[0]['rss'])]
        npoints=len(np.unique(t['xy'],axis=0))
        nq=min(12,npoints-max(BUDGETS))
        if not other or nq<4:
            continue
        m,xy=prior_map(other)
        visible=np.logical_or.reduce([(o['rss']!=100).any(0) for o in other])
        valid=hs[hi]
        valxy,groups=np.unique(valid['xy'][valrows],axis=0,return_inverse=True)
        for stage,count,out in [('train',TRAIN_DRAWS,training),('valid',VALID_DRAWS,validation)]:
            for d in range(count):
                key=f'ap-gain-v1/{stage}/floor{hi}/d{d}'
                draw=nested_rows(t['xy'],range(len(t['xy'])),BUDGETS,nq if stage=='train' else 0,key)
                if stage=='train':
                    q=subset(t,draw['query_rows'])
                else:
                    rng=random.Random(key+'/held-query')
                    qr=[rng.choice(valrows[groups.ravel()==i]) for i in range(len(valxy))]
                    q=subset(valid,qr)
                for k in BUDGETS:
                    s=subset(t,draw['support_rows'][k]);mask=visible|(s['rss']!=100).any(0)
                    sy,sxy,delta=update_parts(m[:,mask],xy,{'rss':s['rss'][:,mask],'xy':s['xy']})
                    out.append(Task(m[:,mask],delta,xy,sy,sxy,q['rss'][:,mask],q['xy'],mask))
        meta.append(dict(pseudo_floor_index=hi,training_positions=npoints,validation_positions=len(valxy),
                         training_query_positions=nq,train_tasks=TRAIN_DRAWS*len(BUDGETS),validation_tasks=VALID_DRAWS*len(BUDGETS)))
    return training,validation,meta


def fit_ap_gain(histories):
    """Learn from the supplied H bank only; return gains for all aligned APs."""
    hs=[h for h in histories if len(h['rss'])]
    if not hs:
        raise ValueError('Cannot fit without any historical scan')
    width=hs[0]['rss'].shape[1]
    unit=np.ones(width)
    active=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
    gains={'learned':unit.copy(),'scalar':unit.copy()}
    if len(hs)<2 or not active.any():
        return gains,dict(fallback='single history or no detected AP',fits=[])
    small=[dict(rss=h['rss'][:,active],xy=h['xy']) for h in hs]
    train,val,meta=pseudo_tasks(small)
    if not train or not val:
        return gains,dict(fallback='insufficient disjoint H positions',fits=[])
    n=int(active.sum());one=np.ones(n)
    scale=float(np.mean([e.risk(one,None) for e in train]))
    valunit=float(np.mean([e.risk(one,None) for e in val]))
    fits=[]
    for scalar,label in [(False,'learned'),(True,'scalar')]:
        best_risk=valunit;best=one
        # Warm start the less-regularized fits; all candidates compared on the
        # same held H positions. Identity wins exact ties on validation MDE.
        init=np.ones(1 if scalar else n)
        for lam in reversed(PENALTIES):
            def objective(v):
                g=np.repeat(v,n) if scalar else v
                grad=np.zeros(n)
                mean_loss=sum(e.risk(g,grad) for e in train)/len(train)/max(scale,1e-8)
                grad/=len(train)*max(scale,1e-8)
                shrink=g-1.
                loss=mean_loss+.5*lam*np.mean(shrink**2)
                grad+=lam*shrink/n
                return loss, np.array([grad.sum()]) if scalar else grad
            opt=minimize(objective,init,jac=True,method='L-BFGS-B',bounds=[(0.,2.)]*len(init),
                         options=dict(maxiter=18,maxls=12,ftol=1e-7,gtol=2e-4))
            if not np.isfinite(opt.fun) or not np.isfinite(opt.x).all():
                raise FloatingPointError('Nonfinite source gain fit')
            init=opt.x
            g=np.repeat(opt.x,n) if scalar else opt.x
            heldrisk=float(np.mean([e.risk(g,None) for e in val]))
            fits.append(dict(model=label,penalty=lam,train_objective=float(opt.fun),validation_mde=heldrisk,
                             iterations=opt.nit,success=bool(opt.success),status=int(opt.status)))
            if heldrisk<best_risk-1e-10:
                best_risk=heldrisk;best=g.copy()
        gains[label][active]=best
    return gains,dict(n_h=len(hs),visible=n,unit_train=scale,unit_validation=valunit,episodes=meta,fits=fits)


def shuffle_gains(g,hs):
    freq=np.vstack([np.mean(h['rss']!=100,axis=0) for h in hs]).mean(0)
    active=np.flatnonzero(freq>0)
    ordered=active[np.argsort(freq[active],kind='stable')]
    out=[]
    for i in range(3):
        rng=np.random.default_rng(20261101+i)
        perm=g.copy()
        for group in np.array_split(ordered,4):
            perm[group]=g[rng.permutation(group)]
        out.append(perm)
    return out


def histories_for(train,b,f,phone,dev):
    h=history_floors(train,b,f)
    if dev is not None:
        h=[subset(v,phone[v['ids']]!=dev) for v in h]
    return [v for v in h if len(v['rss'])]


def train_job(args):
    data,b,f,dev,out=args
    with threadpool_limits(limits=1):
        train=read_floors(data,'trainingData.csv')
        phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
        h=histories_for(train,b,f,phone,dev)
        gs,log=fit_ap_gain(h)
        record=dict(building=b,floor=f,held_phone=dev,history_row_sha256=[hashlib.sha256(v['ids'].tobytes()).hexdigest() for v in h],
                    gains={k:v.tolist() for k,v in gs.items()},diagnostics=log)
        (out/f'ap_gain_b{b}_f{f}_p{dev}.json').write_text(json.dumps(record,allow_nan=False)+'\n')
    print(f'fit B{b}F{f} phone={dev} done',flush=True)


def run(data,out,frozen,workers,score_only=False):
    out.mkdir(parents=True,exist_ok=True)
    train=read_floors(data,'trainingData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    design=json.loads((frozen/'device_stress_design.json').read_text());jobs={(j['building'],j['floor']):j for j in design['events'] if not j.get('unavailable')}
    setups=[(data,b,f,dev,out) for b,f in train for dev in ((None,jobs[b,f]['phone']) if (b,f) in jobs else (None,))]
    # A separate study directory freezes ALL fold fits before official read and
    # before any scoring of held-phone query RSS/xy.
    if score_only:
        for _,b,f,dev,_ in setups:
            if not (out/f'ap_gain_b{b}_f{f}_p{dev}.json').is_file():
                raise ValueError('Incomplete H fits')
    elif workers==1:
        for args in setups:train_job(args)
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            list(pool.map(train_job,setups))
    official=read_floors(data,'validationData.csv');rows=[]
    for _,b,f,dev,_ in setups:
        h=histories_for(train,b,f,phone,dev);t=train[b,f]
        record=json.loads((out/f'ap_gain_b{b}_f{f}_p{dev}.json').read_text())
        assert record['history_row_sha256']==[hashlib.sha256(v['ids'].tobytes()).hexdigest() for v in h]
        gs={k:np.array(v) for k,v in record['gains'].items()};sm=shuffle_gains(gs['learned'],h)
        controls={'unit':np.ones_like(gs['learned']),**gs,**{f'shuffle{i}':v for i,v in enumerate(sm)}}
        if dev is None:
            q=official[b,f];orders=[split_rows(t,b,f,i)[0] for i in SEEDS];mode='official'
        else:
            job=jobs[b,f];q=subset(t,local_rows(t,np.array(job['query_ids'])));orders=local_rows(t,np.array(job['support_orders']));mode='phone'
        full,xy=prior_map(h);visible=np.logical_or.reduce([(v['rss']!=100).any(0) for v in h]);qw=position_weights(q['xy'])
        for draw,order in zip(SEEDS,orders):
            for k in BUDGETS:
                s=subset(t,order[:k]);mask=visible | (s['rss']!=100).any(0)
                m=full[:,mask];sy,sxy,delta=update_parts(m,xy,dict(rss=s['rss'][:,mask],xy=s['xy']))
                for method,g in controls.items():
                    mm=np.vstack([np.clip(m+delta*g[mask],-110.,0.),sy]);coords=np.vstack([xy,sxy]);w=tpm.tobit_weights(q['rss'][:,mask],mm,*MATCH)
                    err=np.linalg.norm(w@(coords-xy[0])+xy[0]-q['xy'],axis=1)
                    rows.append((mode,b,f,draw,k,method,float(qw@err)))
    res=pd.DataFrame(rows,columns=['split','building','floor','draw','K','method','mde'])
    res.to_csv(out/'ap_gain_events.csv',index=False)
    macro=res.groupby(['split','building','floor','K','method']).mde.mean().groupby(['split','building','K','method']).mean().groupby(['split','K','method']).mean()
    print(macro.unstack().round(3),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('data','frozen','out'):
        p.add_argument(key,type=Path)
    p.add_argument('--workers',type=int,default=3)
    p.add_argument('--score-only',action='store_true',help='Use complete frozen H fits already in OUT')
    ns=p.parse_args();run(ns.data,ns.out,ns.frozen,ns.workers,ns.score_only)
