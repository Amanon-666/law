"""Micro-replication at three already identified, exact B1F2 reference XYs.

The three discovery rows are excluded from all primary summaries. No other
point near this region is admitted. Uses the archived H/S and strong WKNN;
splits each of the existing Tobit scan scores into its native two terms.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import log_ndtr,softmax
from scipy.spatial.distance import cdist
from refi import fit_map
from ..protocol import read_floors
from ..inverse import signal,squared,order,vote
from ..smooth_scale import local_rows
from .external_floor_wknn import GapReference
from .paired_map_wknn import group_ids

ORIGINAL=(135,784,789)
RADIUS=10.  # existing horizontal H-smoothing length in native UJI units


def score_parts(model,rss):
    q=rss[:,model.visible];m=model.prototypes;det=q!=100
    out=np.empty((len(q),len(m)))
    for i,mask in enumerate(det):out[i]=-.5*np.sum(((q[i,mask]-m[:,mask])/12.)**2,axis=1)
    absent=(~det).astype(float)@log_ndtr((-85.-m)/12.).T
    return out,absent


def model_knn(model,q,source_ids,k):
    d=squared(signal(q['rss'])[:,model.visible],model.prototypes+110.)
    ix=order(d,source_ids,k);loc=model.xy[ix]-model.xy[0]
    return vote(np.take_along_axis(d,ix,axis=1),loc,model.visible.sum())[0]+model.xy[0]


def main(data,manifest,rival_par,map_par,discovery,out):
    out.mkdir(exist_ok=True,parents=True)
    train=read_floors(data,'trainingData.csv');raw=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID','USERID','TIMESTAMP','SPACEID','RELATIVEPOSITION'])
    ref=json.loads(rival_par.read_text())['selected']['1']['gap_fit'];mapk=json.loads(map_par.read_text())['choices']['1']
    t=train[1,2];phone=raw.PHONEID.to_numpy();job=next(j for j in json.loads(manifest.read_text())['events'] if (j['building'],j['floor'])==(1,2));held=job['phone']
    if held!=23 or not set(ORIGINAL)<=set(job['query_ids']):raise AssertionError('Original query/phone mismatch')
    source_xy=t['xy'][local_rows(t,np.array(ORIGINAL))]
    at=np.stack([(t['xy']==pt).all(axis=1) for pt in source_xy],axis=1)
    ix=np.flatnonzero(at.any(axis=1));q={k:v[ix] for k,v in t.items()}
    q['site_point']=np.array(ORIGINAL)[at[ix].argmax(axis=1)];in_disc=np.isin(q['ids'],ORIGINAL)
    sessions=raw.loc[q['ids']].copy();sessions.index.name='query_id';sessions['utc_time']=pd.to_datetime(sessions.TIMESTAMP,unit='s',utc=True).astype(str)
    sessions[['x','y']]=q['xy'];sessions['coordinate_from']=q['site_point'];sessions['original_query']=in_disc
    sessions['rss_sha256']=[hashlib.sha256(v.astype('<i2').tobytes()).hexdigest() for v in q['rss']]
    sessions['detected']=(q['rss']!=100).sum(1);sessions.to_csv(out/'scans.csv')
    hs=[];gaps=[]
    for (b,f),h in train.items():
        if b!=1 or f==2:continue
        keep=phone[h['ids']]!=held
        if keep.any():hs.append({k:v[keep] for k,v in h.items()});gaps.append(abs(f-2))
    if [len(h['ids']) for h in hs]!=job['retained_history_scans']:raise AssertionError('History differs')
    hxy,hids=group_ids(np.vstack([h['xy'] for h in hs]),np.concatenate([h['ids'] for h in hs]))
    orders=local_rows(t,np.asarray(job['support_orders']));bank=GapReference(hs,gaps,ref[0]);matched=bank.query(q['rss']);empty={k:v[:0] for k,v in t.items()}
    p0=fit_map(hs,empty,floor_gaps=gaps).predict(q['rss']);w0=bank.event(matched,empty,alphas=(ref[1],))[ref[1],ref[2]]
    rows=[];errors=[]
    for draw,sr in enumerate(orders):
        for k in (1,3):
            s={key:v[sr[:k]] for key,v in t.items()}
            if any(tuple(xy) in set(map(tuple,source_xy)) for xy in s['xy']):raise AssertionError('S coordinate coincides with Q')
            model=fit_map(hs,s,floor_gaps=gaps);pred=model.predict(q['rss'])
            sxy,sids=group_ids(s['xy'],s['ids']);ids_mat=np.r_[hids,sids]
            if not np.array_equal(model.xy,np.vstack([hxy,sxy])):raise AssertionError('Map candidate order differs')
            mp=model_knn(model,q,ids_mat,mapk);wk=bank.event(matched,s,alphas=(ref[1],))[ref[1],ref[2]]
            obs,miss=score_parts(model,q['rss']);logit=obs+miss;prob=softmax(logit,axis=1)
            check_xy=prob@(model.xy-model.xy[0])+model.xy[0];np.testing.assert_allclose(check_xy,pred,atol=1e-8,rtol=0.)
            dtrue=cdist(q['xy'],model.xy);truth=dtrue.argmin(1);tops=logit.argmax(1)
            for i,v in enumerate(q['ids']):
                pr,near=tops[i],truth[i];score_map=prob[i];xtrue=q['xy'][i];xmap=model.xy[pr];
                near_mode=np.linalg.norm(model.xy-xmap,axis=1)<=RADIUS;near_truth=dtrue[i]<=RADIUS
                mw=score_map[near_mode];share=mw.sum();mw=mw/share
                orss=obs[i,pr]-obs[i,near];omiss=miss[i,pr]-miss[i,near];c_rss=mw@obs[i,near_mode]-obs[i,near];c_miss=mw@miss[i,near_mode]-miss[i,near]
                assert abs(orss+omiss-(logit[i,pr]-logit[i,near]))<1e-8
                rows.append(dict(query_id=int(v),coordinate_from=int(q['site_point'][i]),target_phone=int(phone[v]),original_query=bool(in_disc[i]),
                    draw=draw,K=k,field=float(np.linalg.norm(pred[i]-xtrue)),map_wknn=float(np.linalg.norm(mp[i]-xtrue)),raw_reference_wknn=float(np.linalg.norm(wk[i]-xtrue)),
                    field_H=float(np.linalg.norm(p0[i]-xtrue)),reference_H=float(np.linalg.norm(w0[i]-xtrue)),
                    field_x=pred[i,0],field_y=pred[i,1],map_wknn_x=mp[i,0],map_wknn_y=mp[i,1],ref_x=wk[i,0],ref_y=wk[i,1],
                    nearest_candidate_dist=dtrue[i,near],MAP_x=xmap[0],MAP_y=xmap[1],MAP_dist=dtrue[i,pr],
                    mass_10U_true=float(score_map[near_truth].sum()),mass_10U_MAP=float(share),
                    MAP_minus_nearest_RSS=orss,MAP_minus_nearest_missing=omiss,MAP_minus_nearest_total=orss+omiss,
                    mode10_avg_minus_nearest_RSS=c_rss,mode10_avg_minus_nearest_missing=c_miss,
                    allowed_observed_AP=int(np.sum(q['rss'][i,model.visible]!=100))))
    table=pd.DataFrame(rows);table['delta']=table.field-table.raw_reference_wknn;table['readout_delta']=table.field-table.map_wknn
    table.to_csv(out/'per_query_draw.csv.gz',index=False)
    original=pd.read_csv(discovery).query('query_id in @ORIGINAL').set_index(['query_id','draw','K']).sort_index()
    old=table[table.original_query].set_index(original.index.names).sort_index();assert old.index.equals(original.index)
    maxgap=max((old.field-original.field_error).abs().max(),(old.raw_reference_wknn-original.wk_error).abs().max());assert maxgap<1e-8
    primary=table[~table.original_query].copy();names=['field','map_wknn','raw_reference_wknn','delta','readout_delta','field_H','reference_H','MAP_dist','mass_10U_true','mass_10U_MAP','MAP_minus_nearest_RSS','MAP_minus_nearest_missing','mode10_avg_minus_nearest_RSS','mode10_avg_minus_nearest_missing']
    byscan=primary.groupby(['target_phone','coordinate_from','query_id','K'])[names].mean();byscan.to_csv(out/'per_scan.csv')
    bypos=byscan.groupby(['target_phone','coordinate_from','K']).mean();bypos.to_csv(out/'per_coordinate.csv')
    worst=byscan.reset_index().sort_values('field',ascending=False).groupby(['coordinate_from','K']).head(1);worst.to_csv(out/'max_confirmed_by_coordinate.csv',index=False)
    records=[]
    for source,grp in sessions[~sessions.original_query].groupby('coordinate_from'):
        prior_hash=sessions.loc[source,'rss_sha256']
        records.append(dict(coordinate_from=int(source),n_scans=len(grp),phone_ids=sorted(map(int,grp.PHONEID.unique())),
            n_distinct_vectors=grp.rss_sha256.nunique(),duplicates_of_own_excluded=int((grp.rss_sha256==prior_hash).sum()),
            ordered_ids=grp.sort_values('TIMESTAMP').index.tolist(),first_timestamp=int(grp.TIMESTAMP.min()),last_timestamp=int(grp.TIMESTAMP.max()),
            distinct_timestamps=int(grp.TIMESTAMP.nunique())))
    allq=sessions[~sessions.original_query];rec=dict(discovery_rows=ORIGINAL,n_remaining=len(allq),allcoords_distinct_RSS=int(allq.rss_sha256.nunique()),
        duplicate_of_any_excluded=int(allq.rss_sha256.isin(sessions[sessions.original_query].rss_sha256).sum()),
        collection='No native session ID; raw USERID/PHONEID, UTC timestamps, SPACEID and RELATIVEPOSITION supplied per row. Same-device, closely spaced repeats; not independent visits.',
        basedata_sha256=hashlib.sha256((data/'trainingData.csv').read_bytes()).hexdigest(),support_manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
        rows_by_point=records,held_phone=held,other_phone_rows=int((allq.PHONEID!=held).sum()),reference_config=ref,same_map_k=int(mapk),discovery_max_error=maxgap,
        score='MAP−nearest geometrical candidate; detected-RSS and nondetection terms in natural-log score units add exactly. Mode10 fields are local joint-posterior-weighted mean component differences to nearest candidate, not a decomposition of a marginal likelihood ratio.',
        weight='10 support draws are first averaged per actual scan, all remaining scans are averaged within exact XY, then the three locations are equally weighted.')
    flat=byscan.reset_index()
    rec['same_phone_macro_by_K']=bypos.loc[held].groupby('K').mean().to_dict('index')
    rec['same_phone_scan_counts_by_K']={int(k):dict(n=len(part),worse_than_reference=int((part.delta>0).sum()),
            RSS_favors_MAP=int((part.MAP_minus_nearest_RSS>0).sum()),miss_favors_truth=int((part.MAP_minus_nearest_missing<0).sum()),
            field_error_range=[float(part.field.min()),float(part.field.max())]) for k,part in flat[flat.target_phone==held].groupby('K')}
    (out/'microreplication.json').write_text(json.dumps(rec,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('data','manifest','rival_par','map_par','discovery','out'):p.add_argument(name,type=Path)
    a=p.parse_args();main(a.data,a.manifest,a.rival_par,a.map_par,a.discovery,a.out)
