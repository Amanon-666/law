"""Source-calibrated shrinkage of a support-only, leave-location-out gain.

Given one observed-space residual z per distinct S location, predict z_s
using all other S locations and the existing 40U kernel. Train only the
prior strength of the resulting one-dimensional correction on source MDE.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist

from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, smooth_history, fit_map
from ..forward import MATCH, FIXED_RADIUS, RIDGE
from ..protocol import BUDGETS, SEEDS, HASHES, read_floors, history_floors, position_weights, split_rows
from ..smooth_scale import local_rows

FIXED = (.5,.75,1.,1.25,1.5,2.)
PENALTIES = (0.,.1,.3,1.,3.,10.,np.inf)


def loo_moments(inverse, z):
    """LOO predicted residual cross-products and one location's mean energy."""
    if len(z)<2:
        return 0.,0.,0.
    prediction = z - (inverse@z) / np.diag(inverse)[:,None]
    return float(np.sum(prediction*z)),float(np.sum(prediction**2)),float(np.sum(z**2)/len(z))


def shrunk_gain(moments, penalty):
    cross,d,energy=moments
    if np.isinf(penalty) or d <= 1e-14*energy or d==0.:
        return 1.
    return float(np.clip(1.+(cross-d)/(d+penalty*energy), .5, 1.5))


def target_eb(inverse,z,moments):
    """Method-of-moments normal-means EB; refit each jackknife slope.

    Each resample deletes a complete anchor and recomputes the inner LOO fit.
    Whole anchors reduce the sensitivity to dependence among AP components.
    The normal-means measurement variance here is a working approximation.
    """
    n=len(z)
    if n<3:
        return 1.
    estimates=[]
    for i in range(n):
        keep=np.arange(n)!=i
        # Inverse of the retained covariance via the Schur complement.
        h=inverse[np.ix_(keep,keep)]-np.outer(inverse[keep,i],inverse[i,keep])/inverse[i,i]
        estimates.append(shrunk_gain(loo_moments(h,z[keep]),0.))
    var=(n-1)*np.var(estimates)
    measured=shrunk_gain(moments,0.)
    prior_var=max((measured-1.)**2-var,0.)
    return 1.+(prior_var/(prior_var+var))*(measured-1.) if prior_var+var else 1.


def correction_map(m,xy,rss,sxy):
    sy,locations=tpm.position_map(tpm.dbm(rss),sxy)
    z=sy-tpm.lookup(locations,xy,m)
    def rbf(a,b):
        return np.exp(-cdist(a,b,'sqeuclidean')/(2*FIXED_RADIUS**2))
    inverse=np.linalg.inv(rbf(locations,locations)+RIDGE*np.eye(len(locations)))
    delta=(rbf(xy,locations)@inverse)@z
    return sy,locations,delta,inverse,z


def fit_repeat_map(histories,support,penalty):
    """One frozen source strength or H+S-only EB; outputs a reusable query map."""
    if len(support['xy'])<=1 or penalty==np.inf:
        return fit_map(histories,support)
    if penalty!='eb' and (not np.isfinite(penalty) or penalty<0):
        raise ValueError('Need nonnegative finite shrinkage, infinity, or eb')
    hs=[h for h in histories if len(h['rss'])]
    visible=np.logical_or.reduce([(h['rss']!=100).any(0) for h in [*hs,support]])
    m,xy=smooth_history(tpm.history_map(hs,None,None),10.,.5)
    sy,sxy,delta,inv,z=correction_map(m[:,visible],xy,support['rss'][:,visible],support['xy'])
    moments=loo_moments(inv,z)
    gain=target_eb(inv,z,moments) if penalty=='eb' else shrunk_gain(moments,penalty)
    prot=np.vstack([np.clip(m[:,visible]+gain*delta,-110.,0.),sy])
    return FingerprintMap(prot,np.vstack([xy,sxy]),visible)


def run(train,phone,jobs,*,model=None,official=None):
    rows=[]
    for j in jobs:
        b,f=j['building'],j['floor']
        t=train[b,f]
        hs=history_floors(train,b,f)
        if official is None:
            d=j['phone']
            hs=[{key:arr[phone[h['ids']]!=d] for key,arr in h.items()} for h in hs]
            hs=[h for h in hs if len(h['ids'])]
            ix=local_rows(t,np.asarray(j['query_ids']))
            q={key:v[ix] for key,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))
            if (phone[t['ids'][orders]]==d).any() or not (phone[q['ids']]==d).all():
                raise ValueError('Phone isolation failure')
        else:
            d=-1;q=official[b,f]
            orders=[split_rows(t,b,f,seed)[0] for seed in SEEDS]
        arms= {f'fixed{a}':('fixed',a) for a in FIXED}
        if model is None:
            arms.update({f'lambda{p}':('loo',p) for p in PENALTIES})
        else:
            choice=model[str(b)]
            arms.update({'raw_loo':('loo',0.),'one_anchor':('loo',1.),'empirical_bayes':('eb',None),
                         'source_tied':('fixed',choice['fixed']), 'source_loo':('loo',float(choice['lambda']))})
        full,xy=smooth_history(tpm.history_map(hs,None,None),10.,.5)
        visible=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
        weights=position_weights(q['xy'])
        for draw,srows in zip(SEEDS,orders):
            for k in BUDGETS:
                sr=srows[:k]
                mask=visible | (t['rss'][sr]!=100).any(0)
                m=full[:,mask]
                sy,sxy,delta,inv,z=correction_map(m,xy,t['rss'][sr][:,mask],t['xy'][sr])
                moments=loo_moments(inv,z)
                coords=np.vstack([xy,sxy])-xy[0]
                cache={}
                for name,(kind,param) in arms.items():
                    gain=(param if kind=='fixed' else target_eb(inv,z,moments) if kind=='eb' else shrunk_gain(moments,param))
                    if gain not in cache:
                        proto=np.vstack([np.clip(m+gain*delta,-110.,0.),sy])
                        w=tpm.tobit_weights(q['rss'][:,mask],proto,*MATCH)
                        cache[gain]=float(weights@np.linalg.norm(w@coords+xy[0]-q['xy'],axis=1))
                    if not np.isfinite(cache[gain]):
                        raise ValueError('Nonfinite MDE')
                    rows.append((b,f,d,draw,k,name,gain,cache[gain]))
        print(f'B{b}F{f} phone={d} complete',flush=True)
    return pd.DataFrame(rows,columns=['building','floor','phone','draw','K','method','gain','mde'])


def main(data,out,source_manifest,phone_manifest):
    out.mkdir(exist_ok=True,parents=True)
    train=read_floors(data,'trainingData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    src=run(train,phone,json.loads(source_manifest.read_text()))
    floor=src.groupby(['building','floor','phone','K','method'],as_index=False)[['mde','gain']].mean()
    floor.to_csv(out/'loo_source.csv',index=False)
    risks=floor.groupby(['building','floor','phone','method']).mde.mean().groupby(['building','floor','method']).mean().groupby(['building','method']).mean()
    config={};source_risks={}
    for held in sorted({b for b,_ in train}):
        risk=risks.drop(index=held,level='building').groupby('method').mean()
        source_risks[held]=risk.to_dict()
        config[held]=dict(fixed=min(FIXED,key=lambda g:(risk.loc[f'fixed{g}'],abs(g-1.))),
                          **{'lambda':str(min(PENALTIES,key=lambda p:(risk.loc[f'lambda{p}'],-p)))})
    params=out/'loo_selection.json'
    params.write_text(json.dumps(dict(choices=config,source_risks=source_risks,csv_sha256=HASHES,
        source_manifest_sha256=hashlib.sha256(source_manifest.read_bytes()).hexdigest(),
        phone_manifest_sha256=hashlib.sha256(phone_manifest.read_bytes()).hexdigest(),
        formula='g=clip(1+(sum(zhat*z)-sum(zhat²))/(sum(zhat²)+lambda*sum(z²)/K),0.5,1.5); zhat=z-(C^-1 z)/diag(C^-1). K<2 = unit.',
        objective='Mean source cross-device post-update MDE weighted equally by building/floor/device/draw/K. Entire target building excluded. No common subtraction.',
        fixed_grid=FIXED,lambda_grid=[str(v) for v in PENALTIES]),indent=2,allow_nan=False)+'\n')
    choices=json.loads(params.read_text())['choices']
    official=read_floors(data,'validationData.csv')
    run(train,phone,[dict(building=b,floor=f) for b,f in train],model=choices,official=official).to_csv(out/'loo_official.csv',index=False)
    device=json.loads(phone_manifest.read_text())
    assert device['train_sha256']==HASHES['trainingData.csv']
    run(train,phone,[j for j in device['events'] if not j.get('unavailable')],model=choices).to_csv(out/'loo_phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','output','source_manifest','phone_manifest'):
        p.add_argument(k,type=Path)
    args=p.parse_args()
    main(args.data,args.output,args.source_manifest,args.phone_manifest)
