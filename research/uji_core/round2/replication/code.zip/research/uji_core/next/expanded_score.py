"""Controlled additional-source experiment for the existing five-term score family.

UJI-only and expanded share the same UJI source event objects, objective,
regularizer, bounded optimizer, map and held tasks. Expanded additionally
reads only the designated UAH/CAR *training* trajectory episodes. It does
not consume another dataset's final evaluation surface.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import historical_prior,FingerprintMap
from residual_probe.episode_rows import nested_rows
from ..protocol import BUDGETS,SEEDS,read_floors,position_weights,split_rows,HASHES
from ..smooth_scale import local_rows
from .transport import source_design
from .additional_sources import episodes as ipin_episodes
from .ap_reliability import Episode,objective
from .score_shape import features,predict,NAMES
from .score_shape_study import FIXED,PENALTY,optimize
from .score_shape_audit import uncertainty,check

FAMILIES=('temperature','symmetric','asymmetric')
FIXED_ARMS={**FIXED,'fixed_weak_core':[.5,1.,.5,1.,.5], 'fixed_cool':[.8]*5}
LEVELS=('site','regime','floor','group','draw','K')


def make_episode(m,xy,q,mask):
    x=features(m,q['rss'][:,mask]);x-=x.mean(axis=1,keepdims=True)
    return Episode(x,xy-xy[0],q['xy']-xy[0],position_weights(q['xy']))


def rows_uji(train,valid,phone,jobs,regime,source):
    for job in jobs:
        b,f=job['building'],job['floor'];dev=job.get('phone',-1);t=train[b,f]
        hs=[];gaps=[]
        for (bb,ff),h in sorted(train.items()):
            if b!=bb or f==ff:continue
            if regime=='device':h={k:v[phone[h['ids']]!=dev] for k,v in h.items()}
            if len(h['rss']):hs.append(h);gaps.append(abs(f-ff))
        if regime=='period':
            q=valid[b,f]
            if source:orders=[nested_rows(t['xy'],range(len(t['xy'])),BUDGETS,0,f'early-late-src/{b}/{f}/{d}')['support_rows'][20] for d in range(3)]
            else:orders=[split_rows(t,b,f,d)[0] for d in SEEDS]
        else:
            qr=local_rows(t,np.asarray(job['query_ids']));q={k:v[qr] for k,v in t.items()}
            orders=local_rows(t,np.asarray(job['support_orders'][:3] if source else job['support_orders']))
        prior,hxy=historical_prior(hs,10.,.5,gaps)
        hseen=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
        for draw,order in enumerate(orders):
            for k in BUDGETS:
                sr=order[:k];mask=hseen|(t['rss'][sr]!=100).any(0)
                s=dict(rss=t['rss'][sr][:,mask],xy=t['xy'][sr])
                m,xy=tpm.calibrate((prior[:,mask],hxy),s,(40.,1.));model=FingerprintMap(m,xy,mask)
                yield (f'UJI_B{b}',regime,int(f),str(dev),draw,k),make_episode(m,xy,q,mask),model,q


def rows_ipin(prepared):
    for row,hs,s,q in ipin_episodes(prepared):
        gaps=[abs(f-row['floor']) for f in row['history_floors']]
        prior,xy=historical_prior(hs,10.,.5,gaps);proto,xy=tpm.calibrate((prior,xy),s,(40.,1.))
        meta=(row['site'],'device_period',row['floor'],f"R{row['query_route']}_{row['query_phone']}",row['draw'],row['K'])
        mask=np.ones(proto.shape[1],bool);yield meta,make_episode(proto,xy,q,mask)


def weights(data):
    frame=pd.DataFrame([row for row,_ in data],columns=LEVELS);mass=np.ones(len(frame));groups=[]
    for col in LEVELS:
        mass/=frame.groupby(groups)[col].transform('nunique').to_numpy() if groups else frame[col].nunique()
        groups.append(col)
    np.testing.assert_allclose(mass.sum(),1.,rtol=0.,atol=1e-12)
    bysite=frame.assign(mass=mass).groupby('site').mass.sum().to_dict()
    return [(w,ep) for w,(_,ep) in zip(mass,data)],bysite


def fit_cell(spec,base,extra):
    held,kind=spec
    source=[r for r in base if r[0][0]!=f'UJI_B{held}']
    only_count=len(source)
    if kind=='expanded':source=source+extra
    weighted,bysite=weights(source);coef={};quality={}
    for family in FAMILIES:
        coef[family],quality[family]=optimize(weighted,family)
    fixed_risk={name:sum(w*float(objective(np.array(v),ep)) for w,ep in weighted) for name,v in FIXED_ARMS.items()}
    select=min(FIXED_ARMS,key=fixed_risk.get);coef['best_fixed_source']=FIXED_ARMS[select]
    print(f'fit {held} {kind} with {len(source)} source events; fixed={select}',flush=True)
    return str(held),kind,dict(coefficients=coef,optimizer=quality,mass=bysite,n_uji_source=only_count,n_total=len(source),
                               best_fixed_source=select,fixed_risks=fixed_risk)


def manifest_digest(prepared):
    return {name:hashlib.sha256((prepared/name).read_bytes()).hexdigest() for name in ('ipin_manifest.json','ipin_episodes.json','UAH.npz','CAR.npz')}


def train_stage(a):
    train=read_floors(a.data,'trainingData.csv');valid=read_floors(a.data,'validationData.csv')
    phones=pd.read_csv(a.data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=[dict(building=b,floor=f) for b,f in train];device=source_design(train,phones);base=[]
    for regime,source in [('period',jobs),('device',device)]:
        base.extend((key,ep) for key,ep,_,_ in rows_uji(train,valid,phones,source,regime,True))
    extra=list(rows_ipin(a.ipin));meta=pd.DataFrame([key for key,_ in base+extra],columns=LEVELS);meta.to_csv(a.out/'source_events.csv',index=False)
    print('reusable UJI and separate IPIN source event counts',len(base),len(extra),flush=True)
    fits={str(b):{} for b in (0,1,2,'external')}
    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        for held,kind,cell in pool.map(lambda spec:fit_cell(spec,base,extra),[(h,t) for h in (0,1,2,'external') for t in ('uji','expanded')]):fits[held][kind]=cell
    record=dict(folds=fits,source_levels=LEVELS,source_counts=meta.groupby('site').size().to_dict(),sha256=HASHES,
                ipin_input_sha256=manifest_digest(a.ipin),features=NAMES,penalty=PENALTY,candidates=FAMILIES,fixed=FIXED_ARMS,
                map='Gap coefficient 2 in public historical_prior, half10/40, unchanged raw S with candidate multiplicity.',
                source='UJI period: other building official later Q; UJI device: training-file held-phone and location-disjoint Q. Three identical nested support draws per scenario in the two arms. Adds standardized IPIN UAH and CAR *training* data only, 5 draws/site, 1/3/5/10/20 K, with temporal and device isolation. All errors in UJI coordinate units. One equally weighted physical site, then equal observed regime/floor/group/draw/K and equal Q position. External fold denotes all source sites only; no external evaluation loaded.',
                fitting='Original five-term monotone score features and exact existing optimizer. Family weights [.25,2], ridge .1 on expanded five-vector about 1, direct mean 2-D distance; matched UJI only/expanded. Best-fixed control selects among seven predetermined alternatives by source loss only.')
    (a.out/'fit.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')


def test_stage(a):
    train=read_floors(a.data,'trainingData.csv');valid=read_floors(a.data,'validationData.csv');phones=pd.read_csv(a.data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    fits=json.loads((a.out/'fit.json').read_text())['folds'];alltiers=[];checks=[{'metric':'feature gradient finite difference','value':float(check())}]
    for stage,regime,jobs in [('official','period',[dict(building=b,floor=f) for b,f in train]),('phone','device',json.loads((a.old/'device_stress_design.json').read_text())['events'])]:
        rows=[];max_gap=0.
        for (site,_,f,dev,draw,k),ep,model,q in rows_uji(train,valid,phones,jobs,regime,False):
            b=int(site[-1]);cores={**FIXED_ARMS}
            for t in ('uji','expanded'):
                cores.update({t+'_'+name:v for name,v in fits[str(b)][t]['coefficients'].items()})
            risks={method:float(objective(np.asarray(c),ep)) for method,c in cores.items()}
            if draw==0 and k==5:
                for name in ('default','uji_symmetric','expanded_symmetric','expanded_asymmetric'):
                    yp=model.predict(q['rss']) if name=='default' else predict(model,q['rss'],cores[name]);v=ep.qw@np.linalg.norm(yp-q['xy'],axis=1);max_gap=max(max_gap,abs(v-risks[name]))
            rows.append(dict(building=b,floor=f,draw=draw,K=k,**risks))
        df=pd.DataFrame(rows).set_index(['building','floor','draw','K']).sort_index()
        old=pd.read_csv(a.paired/f'paired_map_{stage}.csv').set_index(df.index.names).sort_index()
        if not df.index.equals(old.index) or len(df)!=650:raise ValueError('Incomplete paired events')
        difference=float(abs(old.field_tobit-df.default).max());np.testing.assert_allclose(old.field_tobit,df.default,rtol=0.,atol=1e-8)
        if max_gap>1e-8:raise ValueError('Public score predictor disagrees')
        checks.extend([dict(metric=stage+' parent MDE gap, all 650 events',value=difference),dict(metric=stage+' production score MDE gap, 13 floor checks',value=max_gap)])
        df=df.join(old[['field_wknn','old_wknn_gap_fit']]);df.to_csv(a.out/(stage+'.csv'))
        floors=df.groupby(['building','floor','K']).mean();builds=floors.groupby(['building','K']).mean()
        floors.to_csv(a.out/(stage+'_floor.csv'));builds.to_csv(a.out/(stage+'_building.csv'));builds.groupby('K').mean().to_csv(a.out/(stage+'_K.csv'))
        fixed_means=builds.mean()[list(FIXED_ARMS)];best_fixed=fixed_means.idxmin()
        for method in ('uji_symmetric','expanded_symmetric','uji_asymmetric','expanded_asymmetric','uji_temperature','expanded_temperature'):
            arm=method.split('_')[0]
            refs=['default','fixed_weak_core',arm+'_best_fixed_source',best_fixed,'field_wknn','old_wknn_gap_fit']
            if not method.endswith('temperature'):refs.append(arm+'_temperature')
            if arm=='expanded':refs.append('uji_'+method.split('_')[1])
            for ref in dict.fromkeys(refs):
                delta=builds[method]-builds[ref];fd=floors[method]-floors[ref];ci=uncertainty(df,method,ref)
                alltiers.append(dict(stage=stage,method=method,reference=ref,macro_MDE=builds[method].mean(),ref_MDE=builds[ref].mean(),
                                     delta=delta.mean(),conditional95_low=ci[0],conditional95_high=ci[1],building_K_wins=int((delta< -1e-8).sum()),
                                     floor_K_wins=int((fd< -1e-8).sum()),draw_K_wins=int((df[method]-df[ref]< -1e-8).sum()),
                                     meanK_decreases=int((builds[method].groupby('building').diff().dropna()<0).sum()),
                                     floor_K_decreases=int((floors[method].groupby(['building','floor']).diff().dropna()<0).sum()),
                                     best_measured_fixed=best_fixed))
        print(stage, builds.mean().round(4).to_dict(),flush=True)
    pd.DataFrame(alltiers).to_csv(a.out/'tiers.csv',index=False);pd.DataFrame(checks).to_csv(a.out/'parity.csv',index=False)
    figure(a.out,fits)


def figure(out,fits):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(9.6,6.2),layout='constrained')
    for ax,stage in zip(axes[0],('official','phone')):
        table=pd.read_csv(out/(stage+'_K.csv')).set_index('K')
        for name,label,colour,mark in [('default','Parent','#424b51','o'),('fixed_weak_core','Fixed weak core','#cd6b18','x'),('uji_symmetric','UJI, symmetric','#42749c','s'),('expanded_symmetric','UJI + IPIN, symmetric','#168172','^')]:
            ax.plot(range(5),table[name],label=label,color=colour,marker=mark,linewidth=1.7,markersize=4.)
        ax.set(xticks=range(5),xticklabels=list(BUDGETS),xlabel='Calibration locations K',ylabel='Mean localization error (UJI units)',title='Official queries' if stage=='official' else 'Held-phone queries');ax.grid(axis='y',alpha=.2)
    axes[0,0].legend(frameon=False,fontsize=8)
    for ax,regime in zip(axes[1],('uji','expanded')):
        v=np.array([[fits[str(b)][regime]['coefficients']['symmetric'][i] for i in (0,1,4)] for b in [0,1,2]])
        for row,b in zip(v,[0,1,2]):ax.plot(range(3),row,marker='o',label=f'Held B{b}')
        ax.axhline(1,color='gray',ls=':',lw=1);ax.set(xticks=range(3),xticklabels=['Core','Tail','Non-detection'],ylim=(0,2.15),ylabel='Learned coefficient',title='UJI source buildings' if regime=='uji' else 'UJI sources + UAH and CAR');ax.grid(axis='y',alpha=.2)
    axes[1,0].legend(frameon=False,fontsize=8)
    fig.savefig(out/'learning.svg');plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['train','test','both'])
    for name in ('data','ipin','old','paired','out'):p.add_argument(name,type=Path)
    p.add_argument('--workers',type=int,default=3);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    if a.stage in ('train','both'):train_stage(a)
    if a.stage in ('test','both'):test_stage(a)
