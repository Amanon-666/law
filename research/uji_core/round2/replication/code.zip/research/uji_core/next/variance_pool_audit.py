"""Compare pre-existing variance laws under the same 1/2 normalized posterior pool."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import softmax
from ..summarize import INDEX,intervals
from .score_shape_audit import uncertainty
from . import map_variance_study as study
from .map_variance import variance

ARMS=('full','shuffle_same','AP_mean_same','AP_mean_fit','physical','moderate','constant')


def summary(d,mode,method,refs):
    d=d.set_index(INDEX).sort_index()
    f=d.groupby(['building','floor','K']).mean();b=f.groupby(['building','K']).mean()
    rows=[]
    for ref in refs:
        step=intervals(d[[method,ref]].rename(columns={method:'core'}),ref,'d')
        lo,hi=uncertainty(d,method,ref)
        row=dict(mode=mode,method=method,reference=ref,mde=b[method].mean(),ref_mde=b[ref].mean(),
                 delta=(b[method]-b[ref]).mean(),macro_lower95=lo,macro_upper95=hi,
                 sim_upper_below_zero=sum(v[4]<0 for v in step))
        for name,tab,groups in [('building',b,['building']),('floor',f,['building','floor']),('draw',d,['building','floor','draw'])]:
            delta=tab[method]-tab[ref]
            adj=tab[method].groupby(groups).diff().dropna()
            row[name+'_K_wins']=int((delta< -1e-8).sum())
            row[name+'_K_ties']=int((abs(delta)<=1e-8).sum())
            row[name+'_K_count']=len(delta)
            row[name+'_adj_improve']=int((adj< -1e-8).sum());row[name+'_adj_count']=len(adj)
        rows.append(row)
    return rows


def main(data,frozen,out,floor_ref):
    study.init(data)
    choices=json.loads((out/'fit.json').read_text())['choices']
    official=[dict(building=b,floor=f) for b,f in study.TR]
    device=json.loads((frozen/'device_stress_design.json').read_text())['events']
    pool_rows=[];gate_rows=[]
    for mode,regime,jobs in [('official','period',official),('phone','device',device)]:
        rows=[]
        for j in jobs:
            b,f=j['building'],j['floor']
            params=choices[str(b)]
            for draw,k,field,terms,q,w in study.episodes(j,regime,False):
                xy=field.xy-field.xy[0];truth=q['xy']-field.xy[0]
                neutral=softmax(terms.scores(field.prototypes,np.array([[144.]])),axis=1)@xy
                record=dict(building=b,floor=f,draw=draw,K=k,default=w@np.linalg.norm(neutral-truth,axis=1))
                stats={law:field.statistics(law) for law in ('local','AP_mean','shuffled')}
                cache={}
                for name in ARMS:
                    law,*c=params[name];key=tuple(params[name])
                    if key not in cache:
                        scores=terms.scores(field.prototypes,variance(*stats[law],c))
                        other=softmax(scores,axis=1)@xy
                        cache[key]=float(w@np.linalg.norm(.5*(neutral+other)-truth,axis=1))
                    record[name]=cache[key]
                rows.append(record)
        d=pd.DataFrame(rows)
        original=pd.read_csv(out/('gate_'+mode+'.csv'))
        np.testing.assert_allclose(d.set_index(INDEX).sort_index().full,
                                   original.set_index(INDEX).sort_index().fixed_half,rtol=0.,atol=1e-8)
        if len(d)!=650 or not np.isfinite(d.to_numpy()).all():
            raise ValueError('Missing matched event')
        if floor_ref:
            wk=pd.read_csv(floor_ref/('floor_wknn_'+mode+'.csv')).query("method=='gap_fit'").set_index(INDEX).mde
            d=d.set_index(INDEX).join(wk.rename('floor_wknn'),validate='one_to_one').reset_index()
            original=original.set_index(INDEX).join(wk.rename('floor_wknn'),validate='one_to_one').reset_index()
        extra=['floor_wknn'] if floor_ref else []
        pool_rows+=summary(d,mode,'full',['default',*ARMS[1:],*extra])
        gate_rows+=summary(original,mode,'conditioned',['fixed12','always_local','trained_constant_sigma','fixed_half',
                                                        'constant_mix','shuffled','diagnostic_regime_oracle',*extra])
        d.to_csv(out/('half_'+mode+'.csv'),index=False)
    pd.DataFrame(pool_rows).to_csv(out/'half_tiers.csv',index=False)
    pd.DataFrame(gate_rows).to_csv(out/'gate_tiers.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','out'):p.add_argument(n,type=Path)
    p.add_argument('--floor-reference',type=Path)
    a=p.parse_args();main(a.data,a.frozen,a.out,a.floor_reference)
