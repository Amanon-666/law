"""Fit history-field smoothing through the real support update and positional loss."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.sparse import csr_matrix
from scipy.spatial.distance import cdist
from scipy.special import expit,ndtr,softmax
from residual_probe.episode_rows import nested_rows
from external_baselines import tpm_adapter as tpm
from ..protocol import BUDGETS,SEEDS,read_floors,position_weights,split_rows
from ..smooth_scale import local_rows
from ..summarize import INDEX
from .history_smooth import HistorySmoother,NAMES
from .transport import source_design

SOURCE_K=(1,5,20)
PENALTY=.05
FAMILIES={'scalar':[0], 'W':[0,1], 'B':[0,2], 'variance_only':[0,1,2],
          'contrast_coverage':[0,3,4], 'full':list(range(5))}
GROUPS=[]


@dataclass
class Case:
    mask: np.ndarray
    rows: np.ndarray
    lookup: np.ndarray
    projection: np.ndarray
    sy: np.ndarray
    qdet: csr_matrix
    qrss: csr_matrix
    anchors: np.ndarray
    coords: np.ndarray
    truth: np.ndarray
    weight: np.ndarray


def score(m,det,rss):
    z=(-85.-m)/12.
    cdf=ndtr(z)
    missing=np.log(cdf)
    # Drop per-query RSS-square constant, valid for every candidate and theta.
    logits=missing.sum(1)[None,:]+rss@(m.T/144.)+det@(-.5*m*m/144.-missing).T
    return logits,cdf,z


def prepare_case(bank,t,s_rows,q,columns):
    raw=t['rss'][s_rows];sx=t['xy'][s_rows]
    active=(bank.hseen|(raw!=100).any(0))[columns]
    sy,sx=tpm.position_map(tpm.dbm(raw[:,columns][:,active]),sx)
    distance=cdist(sx,bank.xy)
    indices=np.argsort(distance,axis=1)[:,:3]
    a=1./(np.take_along_axis(distance,indices,axis=1)+1.)
    a/=a.sum(1,keepdims=True)
    cross=np.exp(-cdist(bank.xy,sx,'sqeuclidean')/(2.*(40.*bank.unit)**2))
    ss=np.exp(-cdist(sx,sx,'sqeuclidean')/(2.*(40.*bank.unit)**2))
    projection=np.linalg.solve(ss+np.eye(len(sx)),cross.T).T
    qr=q['rss'][:,columns][:,active];seen=qr!=100
    det=csr_matrix(seen.astype(float));rs=csr_matrix(np.where(seen,qr,0.).astype(float))
    return Case(active,indices,a,projection,sy,det,rs,score(sy,det,rs)[0],
                np.vstack((bank.xy,sx))-bank.xy[0],q['xy']-bank.xy[0],position_weights(q['xy']))


def evaluate_prior(prior,case,want_grad):
    a=case;m=prior[:,a.mask]
    lookup=(a.lookup[:,:,None]*m[a.rows]).sum(1)
    virtual=m+a.projection@(a.sy-lookup)
    bounded=np.clip(virtual,-110.,0.)
    logits,cdf,z=score(bounded,a.qdet,a.qrss)
    prob=softmax(np.column_stack((logits,a.anchors)),axis=1)
    mean=prob@a.coords
    delta=mean-a.truth
    distance=np.linalg.norm(delta,axis=1)
    value=a.weight@distance
    if not want_grad:return float(value)
    direct=delta*(a.weight/np.maximum(distance,1e-10))[:,None]
    # The anchors have no signal-map derivative but participate in the softmax.
    ds=(prob[:,:len(m)]*(direct@a.coords[:len(m)].T-(direct*mean).sum(1,keepdims=True)))
    seen=(a.qdet.T@ds).T
    derivative=((a.qrss.T@ds).T-seen*bounded)/144.
    derivative+=(ds.sum(0)[:,None]-seen)*(-np.exp(-z*z/2)/(12.*np.sqrt(2*np.pi)*cdf))
    derivative*=((virtual>-110.) & (virtual<0.))
    through_S=a.projection.T@derivative
    for i in range(a.rows.shape[1]):
        np.add.at(derivative,a.rows[:,i],-a.lookup[:,i,None]*through_S)
    return float(value),derivative


def task_data(train,valid,phones,job,regime,source):
    b,f=job['building'],job['floor'];t=train[b,f];hs=[];gaps=[]
    for (bb,ff),h in train.items():
        if bb!=b or ff==f:continue
        if regime=='device':
            ok=phones[h['ids']]!=job['phone'];h={k:v[ok] for k,v in h.items()}
        if len(h['rss']):hs.append(h);gaps.append(abs(ff-f))
    bank=HistorySmoother(hs,gaps)
    if regime=='period':
        q=valid[b,f]
        if source:
            rng=np.random.default_rng(int.from_bytes(sha256(f'history-smooth/{b}/{f}/Q'.encode()).digest()[:4],'little'))
            pos,grp=np.unique(q['xy'],axis=0,return_inverse=True)
            samples=[rng.choice(np.flatnonzero(grp.ravel()==i)) for i in rng.choice(len(pos),min(24,len(pos)),replace=False)]
            q={k:v[samples] for k,v in q.items()}
            orders=[nested_rows(t['xy'],range(len(t['xy'])),BUDGETS,0,f'early-late-src/{b}/{f}/{i}')['support_rows'][20] for i in range(2)]
        else:orders=[split_rows(t,b,f,d)[0] for d in SEEDS]
    else:
        qr=local_rows(t,np.asarray(job['query_ids']));q={k:v[qr] for k,v in t.items()}
        orders=local_rows(t,np.asarray(job['support_orders']))
        if source:orders=orders[:2]
    return bank,t,q,orders


def data_group(train,valid,phones,job,regime):
    bank,t,q,orders=task_data(train,valid,phones,job,regime,True)
    # Compress storage only. Each inner case re-applies its own current-S AP mask.
    columns=bank.hseen|(t['rss'][np.unique(np.concatenate(orders))]!=100).any(0)
    cases=[prepare_case(bank,t,order[:k],q,columns) for order in orders for k in SOURCE_K]
    key=(regime,job['building'],job['floor'],job.get('phone',-1))
    return key,(bank.raw[:,columns].copy(),bank.contrast[:,columns].copy(),bank.features[:,columns].copy(),cases)


def risk(theta,groups):
    loss=0.;grad=np.zeros(5)
    for wt,(_,data) in groups:
        raw,dx,features,cases=data
        g=expit(features@theta);prior=raw+dx*g
        delta=np.zeros_like(raw);v=0.
        for case in cases:
            val,dm=evaluate_prior(prior,case,True)
            delta[:,case.mask]+=dm
            v+=val
        loss+=wt*v/len(cases)
        grad+=wt*np.einsum('xa,xap->p',delta*dx*g*(1.-g),features)/len(cases)
    return loss,grad


def groups_for(held):
    groups=[v for v in GROUPS if held=='external' or v[0][1]!=held]
    ids=pd.DataFrame([v[0] for v in groups],columns=['regime','b','f','dev'])
    wt=np.ones(len(ids))
    for i,n in enumerate(ids.columns):
        wt/=ids.groupby(list(ids.columns[:i]))[n].transform('nunique').to_numpy() if i else ids[n].nunique()
    np.testing.assert_allclose(wt.sum(),1.)
    return list(zip(wt,groups))


def fit_groups(groups,family):
    cols=FAMILIES[family]
    def obj(v):
        theta=np.zeros(5);theta[cols]=v
        loss,grad=risk(theta,groups)
        return loss+PENALTY*(theta@theta),grad[cols]+2*PENALTY*v
    start=np.zeros(len(cols))
    minimum=minimize(obj,start,jac=True,method='L-BFGS-B',bounds=[(-3.,3.)]*len(cols),
                  options=dict(maxiter=38,ftol=1e-8,gtol=2e-4,maxls=20))
    if not np.isfinite(minimum.fun) or not np.isfinite(minimum.x).all():
        raise RuntimeError(f'Nonfinite fit: {family}')
    t=np.zeros(5);t[cols]=minimum.x
    # Explicitly count boundary-active components using projected gradients.
    grad=minimum.jac.copy()
    grad[((minimum.x<=-3.+1e-8)&(grad>0))|((minimum.x>=3.-1e-8)&(grad<0))]=0.
    status=dict(iterations=int(minimum.nit),success=bool(minimum.success),message=str(minimum.message),
            objective=float(minimum.fun),projected_gradient=float(np.max(abs(grad))),theta=t.tolist())
    return status


def train_one(job):
    held,family=job
    status=fit_groups(groups_for(held),family)
    print(f"fit {held}/{family}: {status['iterations']} grad={status['projected_gradient']:.4g}",flush=True)
    return str(held),family,status


def evaluate(train,valid,phones,jobs,regime,fits):
    records=[]
    for j in jobs:
        b,f=j['building'],j['floor'];cfg=fits[str(b)]
        bank,t,q,orders=task_data(train,valid,phones,j,regime,False)
        vals={k:(cfg['fits'][k]['theta'],'learned') for k in FAMILIES}
        vals.update(half=(np.zeros(5),'half'),physical=(np.zeros(5),'fixed_ratio'),single_best=vals[cfg['single_best']],
                    shuffled=(vals['full'][0],'shuffled'),AP_mean=(vals['full'][0],'AP_mean'))
        held=np.array(vals['full'][0])
        vals['remove_variance']=(held*np.array([1,0,0,1,1]),'learned')
        vals['remove_contrast_coverage']=(held*np.array([1,1,1,0,0]),'learned')
        priors={name:bank.prior(a,mode) for name,(a,mode) in vals.items()}
        for draw,ord_ in enumerate(orders):
            for k in BUDGETS:
                sr=ord_[:k];case=prepare_case(bank,t,sr,q,np.ones_like(bank.hseen))
                row=dict(building=b,floor=f,draw=draw,K=k)
                for name,prior in priors.items():
                    row[name]=evaluate_prior(prior,case,False)
                if draw==0 and k==5:
                    public=bank.condition(dict(rss=t['rss'][sr],xy=t['xy'][sr]),*vals['full']).predict(q['rss'])
                    np.testing.assert_allclose(row['full'],case.weight@np.linalg.norm(public-q['xy'],axis=1),rtol=0.,atol=1e-8)
                records.append(row)
    return pd.DataFrame(records)


def main(data,frozen,trust,out,workers):
    out.mkdir(parents=True,exist_ok=True)
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    ph=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    fs=[dict(building=b,floor=f) for b,f in tr]
    for regime,jobs in [('period',fs),('device',source_design(tr,ph))]:
        for j in jobs:GROUPS.append(data_group(tr,va,ph,j,regime))
    # Check directional derivatives away from the zero start (clip kinks).
    probe=groups_for('external')[:1];t=np.array([.11,-.13,.09,.21,-.1]);direction=np.array([.3,-.4,.2,-.3,.6])
    value,g=risk(t,probe);eps=1e-5
    finite=(risk(t+eps*direction,probe)[0]-risk(t-eps*direction,probe)[0])/(2*eps)
    if abs(finite-g@direction)>2e-4:raise ValueError(f'Gradient check failed: {finite}, {g@direction}')
    print('start fit',len(GROUPS),'groups; gradient gap',abs(finite-g@direction),flush=True)
    # Fork shares read-only historical matrices and preserves outer-building exclusions.
    import multiprocessing as mp
    with ProcessPoolExecutor(max_workers=workers,mp_context=mp.get_context('fork')) as pool:
        solved=list(pool.map(train_one,[(b,n) for b in (0,1,2,'external') for n in FAMILIES]))
    folds={}
    for b in ('0','1','2','external'):
        v={n:s for held,n,s in solved if held==b}
        one=min(('W','B'),key=lambda n:v[n]['objective'])
        folds[b]=dict(fits=v,single_best=one)
    p=out/'fit.json'
    p.write_text(json.dumps(dict(folds=folds,features=NAMES,coefficient_bounds=[-3.,3.],ridge=PENALTY,
        source='Two geometry-only S draws, K1/5/20, one scan per up to 24 distinct true later source-building query positions or 12 genuine other-phone source queries. Both regimes and source buildings/floors/phones/draws/K/query positions equally weighted. Whole target building excluded; external uses all UJI source buildings, including their later labels. Full post-S location MDE and analytic clip/conditioning derivatives. One neutral initialization; report projected gradients, not a global-optimum claim.',
        map='Historical gap2 reliability fixes raw and 10U neighborhood prototype averages; g(x,a) interpolates between them. Standardize W/B/signed contrast/detection probability over H-visible candidate cells, 3-SD clip. Zero g logits recover exactly half smoothing. Physical reference W/(W+B), fallback .5 if neither component has spread. Every method repeats the same 40U S update after its prior changes.',
        directional_gradient_check=dict(analytic=float(g@direction),finite_difference=float(finite),gap=float(abs(finite-g@direction)))),indent=2,allow_nan=False)+'\n')
    folds=json.loads(p.read_text())['folds']
    for mode,reg,jobs in [('official','period',fs),('phone','device',json.loads((frozen/'device_stress_design.json').read_text())['events'])]:
        d=evaluate(tr,va,ph,jobs,reg,folds)
        old=pd.read_csv(trust/(mode+'.csv')).query("method=='gap_only'").set_index(INDEX).mde
        np.testing.assert_allclose(d.set_index(INDEX).half.sort_index(),old.sort_index(),rtol=0.,atol=1e-8)
        if len(d)!=650 or not np.isfinite(d.to_numpy()).all():raise ValueError('Incomplete comparison')
        d.to_csv(out/(mode+'.csv'),index=False)
        print(mode,d.groupby(['building','K']).mean().groupby('building').mean().round(3),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','trust','out'):p.add_argument(n,type=Path)
    p.add_argument('--workers',type=int,default=5)
    a=p.parse_args();main(a.data,a.frozen,a.trust,a.out,a.workers)
