"""Replay fixed conditional-mean coefficients on existing UJI draws 10–49 only.

No parameter estimation, design regeneration, external dataset reads or selection.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap
from ..protocol import BUDGETS,HASHES,read_floors,position_weights
from ..smooth_scale import local_rows
from .conditional_mean_inference import historical_moments,ConditionalMeanMap,BAND_EDGES
from .conditional_mean_gate import FIXED,score_design,coefficients
from .ap_reliability import Episode,objective

FIT_SHA='0b36024f6832eddde20c044739b2b48edcbf8c8e107fd51c24ecbdcbfc1e2386'


def summarize(d,stage):
    cols=['gate','scalar',*FIXED,'source_fixed','floor_wknn','mapped_wknn']
    rng=np.random.default_rng(261101);arr=[];bootarr=[];floorrows=[]
    for b,bgroup in d.groupby('building'):
        floors=[];bootfloors=[]
        for f,group in bgroup.groupby('floor'):
            ordered=group.sort_values(['draw','K'])
            assert np.array_equal(ordered['draw'],np.repeat(np.arange(10,50),5)) and np.array_equal(ordered.K,np.tile(BUDGETS,40))
            cube=ordered[cols].to_numpy().reshape(40,5,len(cols));draw_weights=rng.multinomial(40,np.full(40,1./40.),size=10000)/40.
            floor=cube.mean(0);bootfloor=(draw_weights@cube.reshape(40,-1)).reshape(10000,5,len(cols))
            floors.append(floor);bootfloors.append(bootfloor)
            for i,k in enumerate(BUDGETS):floorrows.append(dict(stage=stage,building=b,floor=f,K=k,**dict(zip(cols,floor[i]))))
        arr.append(np.mean(floors,axis=0));bootarr.append(np.mean(bootfloors,axis=0))
    arr=np.stack(arr);rep=np.stack(bootarr,axis=1)
    def interval(x):return tuple(map(float,np.quantile(x,[.025,.975])))
    contrasts={};br=[];macro=arr.mean((0,1));primary=cols.index('gate')
    for j,ref in enumerate(cols):
        if j==primary:continue
        delta=arr[:,:,primary]-arr[:,:,j];tau=rep[:,:,:,primary]-rep[:,:,:,j]
        lo,hi=interval(tau.mean((1,2)));contrasts[ref]=dict(mde=float(macro[j]),delta=float(delta.mean()),interval=[lo,hi],building_K_nonloss=int((delta<=1e-9).sum()),all_bk_pointwise_upper_below_zero=int((np.quantile(tau,.975,axis=0)<0).sum()))
    for b in range(3):
        for i,k in enumerate(BUDGETS):
            entry=dict(stage=stage,building=b,K=k,**dict(zip(cols,arr[b,i])))
            for j,ref in enumerate(cols):
                if j==primary:continue
                contrast=rep[:,b,i,primary]-rep[:,b,i,j];lo,hi=interval(contrast)
                entry[ref+'_delta']=arr[b,i,primary]-arr[b,i,j];entry[ref+'_lo']=lo;entry[ref+'_hi']=hi
            if i>0:
                change=rep[:,b,i,primary]-rep[:,b,i-1,primary];entry['adjacent']=arr[b,i,primary]-arr[b,i-1,primary];entry['adjacent_lo'],entry['adjacent_hi']=interval(change)
            br.append(entry)
    floorpd=pd.DataFrame(floorrows);fcurve=floorpd.set_index(['building','floor','K']).gate.unstack('K');control=[*FIXED,'scalar','source_fixed']
    best_fixed=min(FIXED,key=lambda k:contrasts[k]['mde']);lim=max(control,key=lambda k:contrasts[k]['delta']);fixed_floor_wins={ref:int((floorpd.gate<=floorpd[ref]+1e-9).sum()) for ref in ['floor_wknn','mapped_wknn','scalar','fixed0.0','fixed_rising']}
    result=dict(n=len(d),gate_mde=float(macro[primary]),K_curve=arr[:,:,primary].mean(0).tolist(),A_building_decreases=int((np.diff(arr[:,:,primary],axis=1)<0).sum()),
                A_floor_decreases=int((np.diff(fcurve,axis=1)<0).sum()),A_draw_decreases=int((d.sort_values(['building','floor','draw','K']).groupby(['building','floor','draw']).gate.diff() <0).sum()),
                B_both_wknn=int(np.sum((arr[:,:,primary]<=arr[:,:,cols.index('floor_wknn')]+1e-9)&(arr[:,:,primary]<=arr[:,:,cols.index('mapped_wknn')]+1e-9))),
                C_all_point=all(contrasts[k]['delta']< -1e-9 for k in control),C_all_upper95=all(contrasts[k]['interval'][1]<0 for k in control),
                C_limiting=lim,best_measured_fixed=best_fixed,all_contrasts=contrasts,floor_wins=fixed_floor_wins)
    return result,br,floorrows


def main(data,fresh,fit_file,out):
    out.mkdir(parents=True,exist_ok=True);raw=fit_file.read_bytes();assert hashlib.sha256(raw).hexdigest()==FIT_SHA
    config=json.loads(raw)['folds'];manifest=json.loads((fresh/'freeze.json').read_text());draws=manifest['new_draws'];assert draws==list(range(10,50)) and manifest['data_sha256']==HASHES
    train=read_floors(data,'trainingData.csv');valid=read_floors(data,'validationData.csv');phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    summary={};floorall=[];ball=[];checks=[]
    for stage in ['official','phone']:
        records=[];parity=0.
        for job in [j for j in manifest['jobs'] if j['mode']==stage]:
            b,f,dev=job['building'],job['floor'],job['device'];t=train[b,f];hs=[];gaps=[]
            for (bb,ff),h in sorted(train.items()):
                if bb!=b or ff==f:continue
                keep=np.ones(len(h['ids']),bool) if dev is None else phones[h['ids']]!=dev
                if keep.any():hs.append({k:v[keep] for k,v in h.items()});gaps.append(abs(ff-f))
            source=valid[b,f] if dev is None else t
            qr=local_rows(source,np.asarray(job['qids']));q={k:v[qr] for k,v in source.items()};orders=local_rows(t,np.asarray(job['orders']))
            if dev is not None and ((phones[t['ids'][orders]]==dev).any() or not (phones[q['ids']]==dev).all()):raise ValueError('Phone separation failed')
            w=position_weights(q['xy']);m,xy,p,c=historical_moments(hs,gaps);hm=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs]);bases={**FIXED,**config[str(b)]['values']}
            for draw,sr in zip(draws,orders):
                for k in BUDGETS:
                    ss=sr[:k];mask=hm|(t['rss'][ss]!=100).any(0)
                    proto,loc=tpm.calibrate((m[:,mask],xy),dict(rss=t['rss'][ss][:,mask],xy=t['xy'][ss]),(40.,1.));bands=np.searchsorted(BAND_EDGES,p[:,mask],side='right');corr=c[:,mask]-m[:,mask]
                    design=score_design(proto,q['rss'][:,mask],len(xy),corr,bands);ep=Episode(design,loc-loc[0],q['xy']-loc[0],w)
                    values={name:float(objective(coefficients(g),ep)) for name,g in bases.items()}
                    if draw==draws[0] and k in (1,20):
                        selfmap=ConditionalMeanMap(FingerprintMap(proto,loc,mask),corr,bands,tuple(bases['gate']))
                        for key in ('gate','scalar','fixed0.0','fixed_rising'):
                            pred=selfmap.predict(q['rss'],bases[key]);parity=max(parity,abs(float(w@np.linalg.norm(pred-q['xy'],axis=1))-values[key]))
                    records.append(dict(building=b,floor=f,draw=draw,K=k,**values))
            print(stage,b,f,flush=True)
        table=pd.DataFrame(records);idx=['building','floor','draw','K'];arch=pd.read_csv(fresh/f'{stage}.csv');table=table.merge(arch,on=idx,validate='one_to_one');assert len(table)==2600 and not table.isna().any().any()
        pgap=float(abs(table['fixed0.0']-table['public']).max());assert max(parity,pgap)<1e-8
        table.to_csv(out/f'{stage}.csv',index=False);result,brows,frows=summarize(table,stage);summary[stage]=result;ball.extend(brows);floorall.extend(frows);checks.append(dict(mode=stage,old_public_max_MDE_gap=pgap,frozen_predict_max_MDE_gap=parity))
    pd.DataFrame(ball).to_csv(out/'building_curves.csv',index=False);pd.DataFrame(floorall).to_csv(out/'floor_curves.csv',index=False)
    summary['checks']=checks;summary['scope']='Previously fixed draws 10–49, fixed floors/queries/gates, 10,000 paired draws within each floor preserving correlations across K and models; building/floors equal. Intervals are pointwise unless marked.';summary['gate_fit_sha256']=FIT_SHA;summary['order_sha256']=hashlib.sha256((fresh/'freeze.json').read_bytes()).hexdigest()
    (out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('data','fresh','fit_file','out'):p.add_argument(key,type=Path)
    a=p.parse_args();main(a.data,a.fresh,a.fit_file,a.out)
