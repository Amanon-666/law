"""Whole-building source training and paired count-normalization diagnostic."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from itertools import product
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import ndtr,softmax
from ..summarize import INDEX
from . import map_variance_study as study
from .transport import source_design
from .count_normalization import log_count_probabilities,components,predict
from .variance_pool_audit import summary

GAMMAS=tuple(np.arange(21)/20.)


def losses(field,base,logcount,q,weight,gammas):
    xy=field.xy-field.xy[0]
    truth=q['xy']-field.xy[0]
    values={}
    for gamma in set(gammas):
        pred=softmax(base-gamma*logcount,axis=1)@xy
        values[gamma]=float(weight@np.linalg.norm(pred-truth,axis=1))
    return values


def run(args):
    regime,j,choices=args
    source=choices is None
    b,f=j['building'],j['floor']
    grid=GAMMAS if source else list(choices.values())
    rows=[]
    for draw,k,field,_,q,w in study.episodes(j,regime,source):
        base,logcount=components(field,q['rss'])
        errs=losses(field,base,logcount,q,w,grid)
        row=dict(regime=regime,building=b,floor=f,phone=j.get('phone',-1),draw=draw,K=k)
        if source:
            rows.extend(dict(**row,gamma=g,mde=errs[g]) for g in grid)
            continue
        row.update({name:errs[g] for name,g in choices.items()})
        qr=q['rss'][:,field.visible]
        seen=qr!=100
        row['mean_permitted_count']=float(w@seen.sum(1))
        row['detected_below_threshold_fraction']=float(w@((seen&(qr< -85.)).sum(1))/max(w@seen.sum(1),1e-12))
        if draw==0 and k==5:
            np.testing.assert_allclose(row['learned'],w@np.linalg.norm(predict(field,q['rss'],choices['learned'])-q['xy'],axis=1),
                                       rtol=0.,atol=1e-8)
        rows.append(row)
    return rows


def check():
    m=np.array([[-65.,-84.,-92.,-102.],[-78.,-88.,-96.,-60.]])
    logp=log_count_probabilities(m,4)
    p=ndtr((m+85.)/12.);explicit=np.zeros_like(logp)
    for state in product((0,1),repeat=4):
        state=np.array(state,dtype=bool)
        explicit[:,int(state.sum())]+=np.where(state,p,1.-p).prod(1)
    np.testing.assert_allclose(np.exp(logp),explicit,atol=1e-14,rtol=1e-12)
    np.testing.assert_allclose(np.log(explicit)[:,:3],log_count_probabilities(m[:,::-1],2),atol=1e-12,rtol=0.)
    from refi import FingerprintMap
    f=FingerprintMap(m,np.array([[0.,0.],[2.,0.]]),np.ones(4,dtype=bool))
    q=np.full((1,4),100)
    np.testing.assert_allclose(predict(f,q,1.),[[1.,0.]],atol=1e-12,rtol=0.)
    return dict(enumeration_max_absolute_probability_gap=float(abs(np.exp(logp)-explicit).max()),
                AP_permutation_and_truncation=True,empty_scan_gamma1_uniform=True)


def main(data,frozen,out,workers,wref):
    out.mkdir(parents=True,exist_ok=True)
    study.init(data);tr=study.TR;ph=study.PH
    fs=[dict(building=b,floor=f) for b,f in tr]
    with ProcessPoolExecutor(max_workers=workers,initializer=study.init,initargs=(data,)) as pool:
        regs={'period':fs,'device':source_design(tr,ph)}
        runs=list(pool.map(run,[(reg,j,None) for reg,jobs in regs.items() for j in jobs]))
        table=pd.DataFrame([row for group in runs for row in group])
        # All regimes contain the same number of source K/draws per task.
        risk=table.groupby(['regime','building','floor','phone','gamma']).mde.mean().groupby(
            ['regime','building','floor','gamma']).mean().groupby(['regime','building','gamma']).mean()
        risk.to_csv(out/'source_risks.csv')
        fits={}
        for held in [0,1,2,'external']:
            r=risk if held=='external' else risk.drop(index=held,level='building')
            best=lambda series: min(GAMMAS,key=lambda g:series.loc[g])
            combined=r.groupby('gamma').mean()
            fits[str(held)]=dict(default=0.,fixed_half=.5,fixed_full=1.,learned=best(combined),
                period_only=best(r.xs('period',level='regime').groupby('gamma').mean()),
                device_only=best(r.xs('device',level='regime').groupby('gamma').mean()))
        path=out/'fit.json'
        path.write_text(json.dumps(dict(folds=fits,grid=GAMMAS,source='Actual later query labels from other UJI source buildings and their disjoint-phone pseudo tasks. Three nested S draws, all K. Equal regime/building/floor/source phone/draw/K/Q location; whole target excluded. External fit uses all three buildings and their late labels.',
            model='Input map is the original half10 smoothed H with 40U S update and original fixed σ12, θ−85. Permitted APs only. Independent threshold probabilities imply a Poisson-binomial count mass; subtract gamma times its log (stable count DP). UJI actually reports some detected RSS below threshold, so this is a score diagnostic.'),indent=2,allow_nan=False)+'\n')
        choices=json.loads(path.read_text())['folds']
        alltiers=[];checks=check()
        for mode,regime,jobs in [('official','period',fs),('phone','device',json.loads((frozen/'device_stress_design.json').read_text())['events'])]:
            results=list(pool.map(run,[(regime,j,choices[str(j['building'])]) for j in jobs]))
            d=pd.DataFrame([row for group in results for row in group])
            old=pd.read_csv(frozen/('smooth_scale_official.csv' if mode=='official' else 'smooth_scale_phone.csv')).query("method=='half10'").set_index(INDEX).mde
            delta=d.set_index(INDEX).default-old
            checks[mode+'_neutral_max_MDE_gap']=float(abs(delta).max())
            if len(d)!=650 or not np.isfinite(d.drop(columns='regime').to_numpy()).all() or abs(delta).max()>1e-8:
                raise ValueError('Incomplete comparison or base mismatch')
            d=d.drop(columns='regime')
            if wref:
                wk=pd.read_csv(wref/('floor_wknn_'+mode+'.csv')).query("method=='gap_fit'").set_index(INDEX).mde
                d=d.set_index(INDEX).join(wk.rename('floor_wknn'),validate='one_to_one').reset_index()
            refs=['default','fixed_half','fixed_full','period_only','device_only']+(['floor_wknn'] if wref else [])
            alltiers+=summary(d,mode,'learned',refs)
            d.to_csv(out/(mode+'.csv'),index=False)
            print(mode,d.groupby(['building','K']).mean(numeric_only=True).groupby('building').mean().round(4),flush=True)
    pd.DataFrame(alltiers).to_csv(out/'tiers.csv',index=False)
    (out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','out'):p.add_argument(n,type=Path)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--floor-reference',type=Path)
    a=p.parse_args();main(a.data,a.frozen,a.out,a.workers,a.floor_reference)
