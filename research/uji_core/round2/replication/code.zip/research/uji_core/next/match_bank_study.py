"""Falsification on row-frozen official and held-phone UJI events for fit_bank."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import softmax
import refi
from ..device_stress import subset
from ..protocol import BUDGETS, history_floors, position_weights, read_floors
from ..summarize import INDEX
from .match_episodes import eval_tasks
from .match_bank import WIDTHS, TrainedBank, fit_bank
from .match_coupled import conditional_scores,marginal

TRAIN, PHONES, JOBS = {},None,{}


def init(data,frozen):
    global TRAIN,PHONES,JOBS
    TRAIN=read_floors(data,'trainingData.csv')
    PHONES=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    manifest=json.loads((frozen/'device_stress_design.json').read_text())
    JOBS={(x['building'],x['floor']):x for x in manifest['events']}


def inputs(mode,b,f):
    h=history_floors(TRAIN,b,f)
    if mode=='device':
        dev=JOBS[b,f]['phone']
        h=[subset(x,PHONES[x['ids']]!=dev) for x in h]
    # Only spatially labelled raw fingerprints are admitted to the learner.
    return tuple(dict(rss=x['rss'],xy=x['xy']) for x in h if len(x['rss']))


def train_one(key):
    mode,b,f=key
    h=inputs(mode,b,f)
    bank=fit_bank(h)
    print(f'Fitted {mode} B{b}F{f}: {bank.width:g}',flush=True)
    return mode,b,f,bank.audit


def main(data,frozen,out,workers):
    out.mkdir(parents=True,exist_ok=True)
    init(data,frozen)
    keys=[(mode,b,f) for mode in ('official','device') for b,f in TRAIN]
    # Freeze all widths before loading official validation. For held-phone trials,
    # the outer partition removes the query phone before H is passed to fit_bank.
    with ProcessPoolExecutor(max_workers=workers,initializer=init,initargs=(data,frozen)) as pool:
        records=list(pool.map(train_one,keys))
    report=dict(method='Leave-one-available-H-floor-out. Each eligible raw H target gets 10 geometry-only draws: 12 Q positions (up to 3 real scans/position), disjoint nested K=1,3,5,10,20 S with one scan/position. Equal Q position, budget, draw and historical target weights. No phone, timestamp, global IDs or target queries in fit_bank(). Width acts on pre-censoring scan-level gain only. Tie/fallback to 6. All fixed widths and previous held-building learner are controls.',
        widths=WIDTHS,fits=[dict(mode=m,building=b,floor=f,**r) for m,b,f,r in records])
    target=out/'bank_selection.json'
    target.write_text(json.dumps(report,allow_nan=False)+'\n')
    selections={(x['mode'],x['building'],x['floor']):x for x in json.loads(target.read_text())['fits']}
    source=json.loads((out/'coupled_selection.json').read_text())['folds']
    official=read_floors(data,'validationData.csv')
    for mode,file in [('official','manifest.json'),('device','device_stress_design.json')]:
        manifest=json.loads((frozen/file).read_text())
        rows=[]
        api_gap=0.
        for b,f in TRAIN:
            history=inputs(mode,b,f)
            cfg=selections[mode,b,f]
            bank=TrainedBank(history,cfg['selected'],cfg)
            target_rows=TRAIN[b,f]
            jobs=eval_tasks(TRAIN,official,PHONES,manifest,b,f,mode)
            _,_,draws=jobs[0]
            for draw,order,q in draws:
                for k in BUDGETS:
                    sr=order[:k]
                    support=dict(rss=target_rows['rss'][sr],xy=target_rows['xy'][sr])
                    target=bank.condition(support)
                    field=target.field
                    scores=conditional_scores(q['rss'][:,field.visible],field.prototypes)
                    weight=position_weights(q['xy'])
                    losses={}
                    for width in WIDTHS:
                        p=softmax(marginal(scores,width),axis=1)
                        pred=p@(field.xy-field.xy[0])+field.xy[0]
                        if draw==0 and k==5 and width==bank.width:
                            api_gap=max(api_gap,float(np.abs(target.predict(q['rss'])-pred).max()))
                        losses[width]=float(weight@np.linalg.norm(pred-q['xy'],axis=1))
                    selected=bank.width
                    rows.append(dict(building=b,floor=f,draw=draw,K=k,selected=selected,
                        source_width=source[str(b)]['default'],bank=losses[selected],external_source=losses[source[str(b)]['default']],
                        **{f'fixed{int(w)}':v for w,v in losses.items()}))
        result=pd.DataFrame(rows)
        if len(result)!=650 or not np.isfinite(result.to_numpy()).all() or api_gap>1e-8:
            raise ValueError('Incomplete evaluation or prediction API mismatch')
        old=pd.read_csv(out/('coupled_'+mode+'.csv')).set_index(INDEX).sort_index()
        actual=result.set_index(INDEX).sort_index()
        np.testing.assert_allclose(actual[['fixed0','fixed6','external_source']],
                                   old[['default_zero','default_fixed6','default_source']],atol=1e-8,rtol=0.)
        result.to_csv(out/('bank_'+mode+'.csv'),index=False)
        print(mode,'api gap',api_gap,result.groupby(['building','K']).mean().groupby('building').mean().round(3),flush=True)

    summarize(frozen,out)


def summarize(frozen,out):
    """All prespecified fixed-width controls and hierarchical pairing."""
    summaries=[]
    for mode in ('official','device'):
        d=pd.read_csv(out/('bank_'+mode+'.csv')).set_index(INDEX).sort_index()
        if mode=='official':
            r=pd.read_csv(frozen/'wknn_events.csv').query("method=='joint_tuned'")
        else:
            r=pd.read_csv(frozen/'device_stress_events.csv').query("method=='strong_wknn'").rename(columns={'seed':'draw'})
        d['strong_wknn']=r.set_index(INDEX).mde
        f=d.groupby(['building','floor','K']).mean()
        b=f.groupby(['building','K']).mean()
        deltas=[('bank',x) for x in ('fixed0','fixed3','fixed6','fixed9','fixed12','external_source','strong_wknn')]
        for method,ref in deltas:
            row={'mode':mode,'method':method,'reference':ref,'mde':b[method].mean(),
                 'reference_mde':b[ref].mean(),'delta':(b[method]-b[ref]).mean()}
            for name,frame,groups in [('building',b,['building']),('floor',f,['building','floor']),
                                      ('draw',d,['building','floor','draw'])]:
                v=frame[method]-frame[ref]
                row[name+'_K_wins']=int((v< -1e-8).sum())
                row[name+'_K_ties']=int((abs(v)<=1e-8).sum())
                row[name+'_K_count']=len(v)
                adjacent=frame[method].groupby(groups).diff().dropna()
                row[name+'_K_improve']=int((adjacent< -1e-8).sum())
                row[name+'_adjacent_count']=len(adjacent)
            summaries.append(row)
    pd.DataFrame(summaries).to_csv(out/'bank_tiers.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','out'):p.add_argument(n,type=Path)
    p.add_argument('--workers',type=int,default=4)
    args=p.parse_args()
    main(args.data,args.frozen,args.out,args.workers)
