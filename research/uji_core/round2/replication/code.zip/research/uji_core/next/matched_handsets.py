"""Retrospective paired two-handset comparison on the same library month-25 XY.

No fitting. H=month23/trn01 and sampled S=month24/trn01, both S3. Month25
tst02–04 (S3) pair exactly with tst07–09 (A5), in separate sessions.
"""
import argparse
from datetime import datetime,timedelta
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import pandas as pd
from residual_probe.episode_rows import nested_rows
from . import longitudinal as lib
from .map_variance import VarianceBank
from .external import METRES_PER_UJI_UNIT as UNIT
from ..protocol import BUDGETS,SEEDS


def stamp(value):
    s=str(int(value))
    # Some timestamps in the full release encode a leap / carry at seconds=60.
    return datetime.strptime(s[:12],'%Y%m%d%H%M')+timedelta(seconds=int(s[12:14]),milliseconds=int(s[14:]))


def range_text(times):
    return [stamp(np.min(times)).isoformat(),stamp(np.max(times)).isoformat()]


def norm_floor(d,rows=None):
    if rows is None:rows=slice(None)
    return dict(rss=d['rss'][rows],xy=d['xy'][rows]/UNIT)


def ci_support(coords):
    # Support draws within each floor retain BOTH devices, all XY and all K.
    rng=np.random.default_rng(831527)
    out={}
    for model in ('local','half'):
        name='DID_'+model
        cube=coords.groupby(['floor','draw','K'])[name].mean()
        by={}
        for floor in (3,5):
            x=cube.xs(floor,level='floor').unstack('K').loc[list(SEEDS),list(BUDGETS)].values
            by[floor]=x[rng.integers(len(SEEDS),size=(10000,len(SEEDS)))].mean(1)
        boot=np.mean(list(by.values()),axis=0)
        actual=cube.groupby('K').mean()
        for k,mean,rep in [('all',actual.mean(),boot.mean(1)),*[(str(k),actual.loc[k],boot[:,i]) for i,k in enumerate(BUDGETS)]]:
            lo,hi=np.quantile(rep,[.025,.975]);out[model+'_'+k]=[float(mean),float(lo),float(hi)]
    return out


def main(archive,fit,out,source_design=None,previous=None):
    out.mkdir(parents=True,exist_ok=True)
    coeff=json.loads(fit.read_text())['choices']['external']['full']
    if coeff!=['local',12.,1.,.25]:
        raise ValueError('Expected the previously frozen all-UJI local variance law')
    old={}
    if source_design:
        design=json.loads(source_design.read_text())['records']
        old={(x['floor'],x['draw']):x for x in design if x['stage']=='late' and x['month']==25}
        if len(old)!=20:raise ValueError('Incomplete month-25 reference support design')
    with ZipFile(archive) as z:
        doc=z.read('db/Readme.txt').decode('latin1')
        if 'tests 6-10 from month 25' not in doc:raise ValueError('Release device assignment changed')
        with z.open('shelves/shelves.csv') as f:shelves=pd.read_csv(f)
    manifest=dict(archive_sha256=lib.SHA256,variance_fit_sha256=hashlib.sha256(fit.read_bytes()).hexdigest(),
        DOI='10.5281/zenodo.3748719',collection_paper='10.3390/data3010003',score_unit='metres',
        settings={'fixed12':[12.,0.,0.],'local':coeff[1:],'half':'Arithmetic mean of coordinates from the two normalized posteriors'},
        geometry='Within-floor exact XY matches; equal acquisition weight in each location, then equal location, floor, draw and K. S3 tst02/03/04 paired with A5 tst07/08/09 on the same dates. Two contiguous numbered floors of the same library wing among bookshelves, per collection paper; released shelf polygons describe nominal layout, not occupancy or a verified immutable physical scene.',
        shelf_polygons=int(shelves.number.nunique()),draws='Use exactly S3 late/25 split keys for both handsets; build a single field for each floor/draw/K then score both. The A5-specific prior-stage random split is deliberately not used.',
        difference_in_differences='(A5 local−fixed12)−(S3 local−fixed12), computed at each paired XY after averaging its repeats; negative means more relative local-variance benefit on A5. Same contrast for fixed half.',
        uncertainty='Percentile intervals resample whole nested support draws independently within each of these two fixed floors. Not a new-phone/site/time population interval.',
        support=[],floors=[],session_times=[])
    location=[]
    for floor in (3,5):
        h=lib.on_floor(archive,23,'trn',1,floor)
        s=lib.on_floor(archive,24,'trn',1,floor)
        pairs=[]
        for n in (2,3,4):
            oldq=lib.on_floor(archive,25,'tst',n,floor)
            newq=lib.on_floor(archive,25,'tst',n+5,floor)
            # The release orders the same point/facing-direction and repeated
            # sample index the same way; collection times remain different.
            np.testing.assert_array_equal(oldq['xy'],newq['xy'])
            if any(a[4:]!=b[4:] for a,b in zip(oldq['ids'],newq['ids'])):
                raise ValueError('Point and repeat ID suffix differs between sessions')
            pos,inv,counts=np.unique(oldq['xy'],axis=0,return_inverse=True,return_counts=True)
            if not np.all(counts==12):raise ValueError('Unexpected repeats/XY')
            if not h['times'].max()<s['times'].min()<=s['times'].max()<oldq['times'].min()<newq['times'].min():
                raise ValueError('Invalid campaign chronology')
            if not oldq['times'].max()<newq['times'].min():raise ValueError('Unexpected within-floor session overlap')
            lags=[]
            for group in range(len(pos)):
                iq=np.flatnonzero(inv.ravel()==group)
                dif=np.array([(stamp(newq['times'][i])-stamp(oldq['times'][i])).total_seconds()/60. for i in iq])
                lags.append(float(np.median(dif)))
            manifest['session_times'].append(dict(floor=floor,S3_session=n,A5_session=n+5,S3_window=range_text(oldq['times']),
                A5_window=range_text(newq['times']),matched_positions=len(pos),scans_per_phone=len(inv),
                within_XY_median_lag_minutes=[float(np.min(lags)),float(np.median(lags)),float(np.max(lags))]))
            pairs.append((n,oldq,newq,pos,inv.ravel(),counts))
        qloc=np.vstack([p[3] for p in pairs])
        if len(np.unique(qloc,axis=0))!=len(qloc):raise ValueError('Unexpected overlap between collection position groups')
        hxy={tuple(v) for v in h['xy']};sxy={tuple(v) for v in s['xy']}
        if sxy!=hxy or set(map(tuple,qloc)) & sxy:raise ValueError('Query overlaps H/S survey anchors or changed training XY')
        manifest['floors'].append(dict(floor=floor,H_window=range_text(h['times']),S_pool_window=range_text(s['times']),
            survey_positions=len(sxy),history_rows=len(h['ids']),support_pool_rows=len(s['ids']),
            n_matched=len(qloc),matched_query_bounds=[qloc.min(0).tolist(),qloc.max(0).tolist()]))
        bank=VarianceBank([norm_floor(h)])
        for draw in SEEDS:
            order=np.array(nested_rows(s['xy'],range(len(s['rss'])),BUDGETS,0,
                               f'uji-lib-lag-v1/late/25/{floor}/{draw}/support')['support_rows'][20])
            if old and old[floor,draw]['support_order']!=s['ids'][order].tolist():
                raise ValueError('Original S3 rows changed')
            manifest['support'].append(dict(floor=floor,draw=draw,order=s['ids'][order].tolist()))
            for k in BUDGETS:
                field=bank.condition(norm_floor(s,order[:k]))
                for n,oldq,newq,pos,inv,counts in pairs:
                    errors={}
                    for phone,q in [('S3',oldq),('A5',newq)]:
                        fixed=field.predict(q['rss'],(12.,0.,0.))*UNIT
                        local=field.predict(q['rss'],coeff[1:])*UNIT
                        for method,xy in [('fixed',fixed),('local',local),('half',.5*(fixed+local))]:
                            e=np.linalg.norm(xy-q['xy'],axis=1)
                            errors[phone+'_'+method]=np.bincount(inv,weights=e)/counts
                    df=pd.DataFrame(dict(floor=floor,draw=draw,K=k,session_pair=str(n)+'-'+str(n+5),x=pos[:,0],y=pos[:,1],**errors))
                    for method in ('local','half'):
                        for phone in ('S3','A5'):
                            df[phone+'_delta_'+method]=df[phone+'_'+method]-df[phone+'_fixed']
                        df['DID_'+method]=df['A5_delta_'+method]-df['S3_delta_'+method]
                    location.append(df)
    coords=pd.concat(location,ignore_index=True)
    cols=['S3_fixed','S3_local','S3_half','A5_fixed','A5_local','A5_half',
          'S3_delta_local','A5_delta_local','DID_local','S3_delta_half','A5_delta_half','DID_half']
    per=coords.groupby(['floor','draw','K'])[cols].mean()
    if previous:
        prev=pd.read_csv(previous).query("stage=='late' and month==25 and method=='fixed_refi'").rename(columns={'seed':'draw'})
        np.testing.assert_allclose(per.S3_fixed.sort_index(),prev.set_index(['floor','draw','K']).mde.sort_index(),atol=1e-8,rtol=0.)
    if len(per)!=100 or len(coords)!=8200 or not np.isfinite(per.values).all():raise ValueError('Incomplete matched study')
    per.to_csv(out/'paired_events.csv')
    coords.groupby(['floor','x','y','session_pair','K'])[cols].mean().to_csv(out/'paired_xy_by_K.csv.gz')
    coords.groupby(['floor','session_pair'])[cols].mean().to_csv(out/'paired_sessions.csv')
    summary=per.groupby('K').mean()
    summary.loc['all']=per.mean()
    summary.to_csv(out/'effects.csv')
    manifest['support_intervals']=ci_support(coords)
    manifest['timing_note']='Time windows are as logged; no timezone assumption. All paired sessions are sequential, phone S3 first in each pair. Difference-in-differences controls locations and shared H/S, not radio state, elapsed time, user pose, or device-session order.'
    (out/'design.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
    print(summary.round(4).to_string(),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('archive','fit','out'):p.add_argument(n,type=Path)
    p.add_argument('--source-design',type=Path);p.add_argument('--previous',type=Path)
    a=p.parse_args();main(a.archive,a.fit,a.out,a.source_design,a.previous)
