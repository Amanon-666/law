"""Audit mean/median decisions on exactly the same posterior over measured XY.

Every geometric median has an optimality certificate for weighted mean distance.
No estimator receives the real query position until all decisions are computed.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize, linprog
from scipy.spatial.distance import cdist
from external_baselines import tpm_adapter as tpm
from .match_episodes import eval_tasks, maps
from ..protocol import read_floors

TOL = 0.0005  # absolute posterior expected Euclidean distance in UJI units


def terms(x, xy, w):
    difference=x[:,None,:]-xy
    d=np.linalg.norm(difference,axis=2)
    hit=d==0.
    inv=np.divide(w,d,where=~hit,out=np.zeros_like(w))
    grad=np.einsum('qm,qmd->qd',inv,difference)
    magnitude=np.linalg.norm(grad,axis=1)
    factor=np.divide((w*hit).sum(1),magnitude,where=magnitude>0,out=np.zeros(len(w)))
    # At an atom this is the minimum-norm subgradient; elsewhere the usual gradient.
    grad*=np.maximum(0.,1.-factor)[:,None]
    # Convexity: f(x)-f* <= max over z in conv(XY) of grad.(x-z).
    bound=np.maximum(0.,(grad*x).sum(1)-(grad@xy.T).min(1))
    return (w*d).sum(1),grad,inv.sum(1),bound


def certify_cuts(x, xy, w):
    """Tighten a loose one-subgradient bound using globally valid tangent cuts."""
    directions=np.array([[1.,0.],[0.,1.],[-1.,0.],[0.,-1.],[1.,1.],[-1.,1.],[1.,-1.],[-1.,-1.]])
    probes=np.vstack([x,x+1e-4*directions,x+.05*directions])
    best=x.copy()
    lower_xy,upper_xy=xy.min(0),xy.max(0)
    values,grad,_,_=terms(probes,xy,np.broadcast_to(w,(len(probes),len(w))))
    best=probes[values.argmin()].copy()
    upper=float(values.min())
    intercept=values-(grad*probes).sum(1)
    for _ in range(80):
        cuts=np.column_stack((grad,-np.ones(len(grad))))
        lp=linprog([0.,0.,1.],A_ub=cuts,b_ub=-intercept,
                   bounds=[*zip(lower_xy,upper_xy),(0.,None)],method='highs')
        if not lp.success:
            raise ArithmeticError(f'Convex cut lower bound failed: {lp.message}')
        gap=max(0.,upper-lp.fun)+1e-8
        if gap<=TOL: return best,gap
        probe=lp.x[:2]
        v,g,_,_=terms(probe[None],xy,w[None])
        if v[0]<upper: best,upper=probe.copy(),float(v[0])
        grad=np.vstack((grad,g));intercept=np.append(intercept,v[0]-g[0]@probe)
    raise ArithmeticError('Convex cutting-plane certificate did not close')

def decisions(p, coords):
    offset=coords[0]
    xy,idx=np.unique(coords-offset,axis=0,return_inverse=True)
    w=np.zeros((len(p),len(xy))); np.add.at(w.T,idx.ravel(),p.T)
    w/=w.sum(1,keepdims=True)
    dist=cdist(xy,xy)
    loss_atoms=w@dist
    medoid=xy[loss_atoms.argmin(1)]
    mean=w@xy
    best=mean.copy()
    # Cheaper atom test: if any atom is optimal it is a minimizing medoid as
    # well. Its subgradient ball contains zero when ||sum_i!=j p_i u_ji||<=p_j.
    _,_,_,ga=terms(medoid,xy,w)
    atom=ga<=1e-9
    best[atom]=medoid[atom]
    active=np.where(~atom)[0]
    max_iter=0
    for i in range(220):
        if not len(active): break
        value,g,inverse,bound=terms(best[active],xy,w[active])
        pending=bound>TOL
        if not pending.any(): active=active[:0]; break
        active=active[pending]
        # Modified Weiszfeld: omit coincident points in denominator and
        # use the minimum-norm subgradient also when the iterate is an atom.
        best[active]-=g[pending]/inverse[pending,None]
        max_iter=i+1
    for row in active:
        def fun(y):
            value,g,_,_=terms(y[None],xy,w[row:row+1]); return value[0],g[0]
        res=minimize(fun,best[row],jac=True,method='BFGS',options={'gtol':1.e-11,'maxiter':600})
        best[row]=res.x
    _,_,_,gap=terms(best,xy,w)
    cuts=np.flatnonzero(gap>TOL)
    for row in cuts:
        best[row],gap[row]=certify_cuts(best[row],xy,w[row])
    if not np.isfinite(gap).all() or gap.max()>TOL+1e-7:
        raise ArithmeticError(f'Uncertified continuous median: upper gap {gap.max()}')
    postloss={name:terms(point,xy,w)[0] for name,point in [('mean',mean),('median',best)]}
    if np.any(postloss['median']>postloss['mean']+TOL+1e-9):
        raise AssertionError('Median posterior risk exceeds mean beyond certificate tolerance')
    return {key:x+offset for key,x in dict(mean=mean,geometric_median=best,
                                           medoid=medoid,map_xy=xy[w.argmax(1)]).items()},dict(
        max_posterior_risk_gap=gap.max(),max_weiszfeld_steps=max_iter,
        exact_atom=int(atom.sum()),fallback=int(len(active)),extra_cut_certificates=len(cuts),queries=len(p),
        mean_model_risk_gain=float(np.mean(postloss['mean']-postloss['median'])))


def main(data,frozen,out):
    out.mkdir(exist_ok=True,parents=True)
    train=read_floors(data,'trainingData.csv');valid=read_floors(data,'validationData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    records=[]; checks=[]
    for mode,manifest in [('official','manifest.json'),('phone','device_stress_design.json')]:
        design=json.loads((frozen/manifest).read_text())
        for b,f in sorted(train):
            ts=eval_tasks(train,valid,phones,design,b,f,mode)
            for e in maps(train,b,f,ts):
                p=tpm.tobit_weights(e['query'],e['prototypes'],12.,-85.)
                locations,check=decisions(p,e['xy'])
                key=dict(mode=mode,building=b,floor=f,draw=e['draw'],K=e['K'])
                checks.append(dict(**key,**check))
                for method,xy in locations.items():
                    error=np.linalg.norm(xy-e['truth'],axis=1)
                    records.append(dict(**key,method=method,mde=e['weight']@error))
            print(mode,b,f,'complete',flush=True)
    pd.DataFrame(records).to_csv(out/'readout_events.csv',index=False)
    pd.DataFrame(checks).to_csv(out/'readout_certificate.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','out'):p.add_argument(n,type=Path)
    a=p.parse_args();main(a.data,a.frozen,a.out)
