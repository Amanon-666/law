"""Fixed-k WKNN on EXACTLY the candidate's detected/missed RSS mean pair.

No selection: use the old independently fitted same-map k (7/7/3). This
only compares two readouts on the original 650+650 UJI development events.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from ..protocol import BUDGETS,SEEDS,read_floors,split_rows,position_weights
from ..smooth_scale import local_rows
from ..inverse import order,vote
from .paired_map_wknn import group_ids
from .conditional_mean_inference import historical_moments,BAND_EDGES
from .conditional_mean_fresh import FIT_SHA
from external_baselines import tpm_adapter as tpm


def readout(query,base,h_delta,bands,g,ids,xy,k):
    nh=len(h_delta);mu=base.copy();mu[:nh]+=np.asarray(g)[bands]*(np.clip(base[:nh]+h_delta,-110.,0.)-base[:nh]);x=np.where(query!=100,query.astype(float)+110.,0.);seen=(query!=100).astype(float)
    # Distinguish actual -110 detection vs the 100 missing sentinel using seen.
    d2=np.maximum((x*x).sum(1)[:,None]+seen@((mu+110.)**2).T+(1.-seen)@((base+110.)**2).T-2*x@(mu+110.).T,0.)
    ix=order(d2,ids,k);return vote(np.take_along_axis(d2,ix,axis=1),xy[ix]-xy[0],query.shape[1])[0]+xy[0]


def main(data,old,paired,fit,out):
    out.mkdir(exist_ok=True,parents=True);raw=fit.read_bytes();assert hashlib.sha256(raw).hexdigest()==FIT_SHA;cfg=json.loads(raw)['folds']
    train=read_floors(data,'trainingData.csv');valid=read_floors(data,'validationData.csv');ph=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy();jobs={(j['building'],j['floor']):j for j in json.loads((old/'device_stress_design.json').read_text())['events']};ks=json.loads((paired/'paired_map_parameters.json').read_text())['choices']
    cols=['building','floor','draw','K'];summary={}
    for stage in ['official','phone']:
        rows=[]
        for (b,f),t in train.items():
            j=jobs[b,f];dev=j['phone'];hs=[];gaps=[]
            for (bb,ff),h in train.items():
                if bb!=b or ff==f:continue
                ix=np.ones(len(h['rss']),bool) if stage=='official' else ph[h['ids']]!=dev
                if ix.any():hs.append({k:v[ix] for k,v in h.items()});gaps.append(abs(f-ff))
            m,hh,p,cd=historical_moments(hs,gaps);mask_h=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs]);hx,hid=group_ids(np.vstack([h['xy'] for h in hs]),np.concatenate([h['ids'] for h in hs]));assert np.array_equal(hx,hh)
            if stage=='official':q=valid[b,f];orders=[split_rows(t,b,f,d)[0] for d in SEEDS]
            else:q={k:v[local_rows(t,j['query_ids'])] for k,v in t.items()};orders=local_rows(t,j['support_orders'])
            weight=position_weights(q['xy']);g=cfg[str(b)]['values']['gate'];kn=ks[str(b)]
            for draw,sr in enumerate(orders):
                for k in BUDGETS:
                    select=sr[:k];s={key:v[select] for key,v in t.items()};mask=mask_h|(s['rss']!=100).any(0);proto,xy=tpm.calibrate((m[:,mask],hh),dict(rss=s['rss'][:,mask],xy=s['xy']),(40.,1.))
                    sx,sid=group_ids(s['xy'],s['ids']);assert np.array_equal(xy[len(hx):],sx);ids=np.r_[hid,sid];bands=np.searchsorted(BAND_EDGES,p[:,mask],side='right');delta=cd[:,mask]-m[:,mask]
                    scores={}
                    for label,gate in [('same_pair_wknn',g),('unit_wknn',[0.,0.,0.])]:
                        yp=readout(q['rss'][:,mask],proto,delta,bands,gate,ids,xy,kn);scores[label]=float(weight@np.linalg.norm(yp-q['xy'],axis=1))
                    rows.append(dict(building=b,floor=f,draw=draw,K=k,**scores))
        r=pd.DataFrame(rows).set_index(cols).sort_index();orig=pd.read_csv(fit.parent/f'{stage}.csv').set_index(cols).sort_index();assert orig.index.equals(r.index)
        m=float(abs(orig.field_wknn-r.unit_wknn).max());assert m<1e-8;r=r.join(orig[['gate','fixed0.0','field_wknn','old_wknn_gap_fit']]);r.to_csv(out/f'{stage}.csv')
        fmean=r.groupby(['building','floor','K']).mean();bmean=fmean.groupby(['building','K']).mean();bmean.to_csv(out/f'{stage}_building.csv');summary[stage]=dict(ungated_WKNN_parity=m,macro=bmean.mean().to_dict(),same_pair_wknn_worse_buildingK=int((bmean.same_pair_wknn>bmean.gate).sum()),same_pair_wknn_worse_floorK=int((fmean.same_pair_wknn>fmean.gate).sum()))
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','old','paired','fit','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.old,a.paired,a.fit,a.out)
