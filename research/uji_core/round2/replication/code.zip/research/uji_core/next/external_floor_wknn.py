"""Historical floor-gap-aware WKNN; learn settings only on cross-device UJI sources.

python -m research.uji_core.next.external_floor_wknn DATA UJI_RESULTS OUTPUT
Every raw historical neighbor from floor j gets adjusted RSS distance
d' = d exp(alpha (|j-target|-1)); support distances are unchanged.
"""
import argparse
import json
from itertools import product
from pathlib import Path
import numpy as np
import pandas as pd
from residual_probe.episode_rows import nested_rows
from ..inverse import signal, squared, order, vote
from ..protocol import BUDGETS, SEEDS, split_rows, read_floors, position_weights
from ..study import NEIGHBORS
from ..wknn_reference import pool_floor
from ..smooth_scale import local_rows
from .transport import source_design

ALPHAS=(0.,.35,.7,1.4)


class GapReference:
    def __init__(self, histories, gaps, representation):
        self.hseen=np.logical_or.reduce([(h['rss']!=100).any(0) for h in histories])
        floors=histories if representation=='raw' else [pool_floor(h) for h in histories]
        self.refs=[(signal(h['rss'])[:,self.hseen],h['xy'],h['ids'],float(g))
                   for h,g in zip(floors,gaps)]
        if any(g<1 for _,_,_,g in self.refs):
            raise ValueError('Only other-floor histories are allowed')

    def query(self,rss):
        q=signal(rss)
        distances,coords,ids,gaps=[],[],[],[]
        for feats,xy,row,gap in self.refs:
            d=squared(q[:,self.hseen],feats)
            ix=order(d,row,max(NEIGHBORS))
            distances.append(np.take_along_axis(d,ix,axis=1))
            coords.append(xy[ix]);ids.append(row[ix]);gaps.extend([gap]*ix.shape[1])
        return q,np.hstack(distances),np.concatenate(coords,axis=1),np.hstack(ids),np.array(gaps)

    def event(self,matched,s,alphas=ALPHAS):
        q,dh,hxy,hid,gaps=matched
        sy=signal(s['rss'])
        mask=self.hseen|sy.any(0)
        # New support-only APs add the same query-dependent offset to every
        # squared historical distance before the floor-specific multiplier.
        hd=dh+(q[:,mask & ~self.hseen]**2).sum(1)[:,None]
        sd=squared(q[:,mask],sy[:,mask])
        ids=np.hstack((hid,np.broadcast_to(s['ids'],sd.shape)))
        coords=np.concatenate((hxy,np.broadcast_to(s['xy'],(*sd.shape,2))),axis=1)
        estimates={}
        for alpha in alphas:
            d=np.column_stack((hd*np.exp(2.*alpha*(gaps-1.)),sd))
            ix=order(d,ids,max(NEIGHBORS))
            dist=np.take_along_axis(d,ix,axis=1)
            x=np.take_along_axis(coords,ix[:,:,None],axis=1)
            for k in NEIGHBORS:
                estimates[alpha,k]=vote(dist[:,:k],x[:,:k],int(mask.sum()))[0]
        return estimates


def measure(train,phones,jobs,choices=None,valid=None,source_period=False):
    records=[]
    for job in jobs:
        b,f=job['building'],job['floor']
        target=train[b,f]
        query_phone=job.get('phone',-1)
        hs=[]; gaps=[]
        for (building,floor),h in train.items():
            if building!=b or floor==f: continue
            if valid is None:
                h={key:z[phones[h['ids']]!=query_phone] for key,z in h.items()}
            if len(h['ids']):
                hs.append(h);gaps.append(abs(floor-f))
        if valid is None:
            qrows=local_rows(target,np.asarray(job['query_ids']))
            q={key:z[qrows] for key,z in target.items()}
            orders=local_rows(target,np.asarray(job['support_orders']))
            if not (phones[q['ids']]==query_phone).all() or (phones[target['ids'][orders]]==query_phone).any():
                raise AssertionError('Cross-device split violation')
        else:
            q=valid[b,f]
            if source_period:
                orders=[nested_rows(target['xy'],range(len(target['rss'])),(1,3,5,10,20),0,
                                    f'early-late-src/{b}/{f}/{d}')['support_rows'][20] for d in range(3)]
            else:
                orders=[split_rows(target,b,f,seed)[0] for seed in SEEDS]
        qw=position_weights(q['xy'])
        for rep in ('raw','prototype'):
            params=({f'{rep}:{a}:{k}':(rep,a,k) for a,k in product(ALPHAS,NEIGHBORS)} if choices is None
                    else {n:p for n,p in choices[str(b)].items() if p[0]==rep})
            if not params: continue
            bank=GapReference(hs,gaps,rep)
            matched=bank.query(q['rss'])
            alphas=sorted({p[1] for p in params.values()})
            for draw,order in enumerate(orders):
                for k in BUDGETS:
                    s={key:z[order[:k]] for key,z in target.items()}
                    preds=bank.event(matched,s,alphas)
                    for label,(_,alpha,n) in params.items():
                        err=np.linalg.norm(preds[alpha,n]-q['xy'],axis=1)
                        records.append((b,f,query_phone,draw,k,label,rep,alpha,n,float(qw@err)))
    return pd.DataFrame(records,columns=['building','floor','phone','draw','K','method',
                                          'reference','alpha','neighbors','mde'])


def selected(src,previous):
    keys=['reference','alpha','neighbors']
    risk=src.groupby(['building','floor','phone',*keys]).mde.mean().groupby(
        ['building','floor',*keys]).mean().groupby(['building',*keys]).mean()
    choices={}
    for held in [0,1,2,'external']:
        r=(risk if held=='external' else risk.drop(held,level='building')).groupby(keys).mean()
        opts=list(product(('raw','prototype'),ALPHAS,NEIGHBORS))
        best=lambda options:min(options,key=lambda p:(r.loc[p],p[1],p[0]!='raw',p[2]))
        old=previous[str(held)]
        choices[str(held)]=dict(previous=(old['reference'],0.,old['neighbors']),
                                no_gap_refit=best([p for p in opts if p[1]==0]),gap_fit=best(opts))
    return choices


def main(data,old,out):
    out.mkdir(exist_ok=True,parents=True)
    train=read_floors(data,'trainingData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=source_design(train,phones)
    for j in jobs: j['support_orders']=j['support_orders'][:4]
    src=measure(train,phones,jobs)
    keys=['building','floor','phone','reference','alpha','neighbors']
    src.groupby(keys,as_index=False).mde.mean().to_csv(out/'floor_wknn_source.csv',index=False)
    previous={k:v['joint_tuned'] for k,v in json.loads((old/'wknn_parameters.json').read_text())['selected'].items()}
    orig=pd.read_csv(old/'wknn_source.csv').groupby(['building','reference','neighbors']).mde.mean()
    r=orig.groupby(['reference','neighbors']).mean()
    rep,n=min(product(('raw','prototype'),NEIGHBORS),key=lambda p:r.loc[p])
    previous['external']=dict(reference=rep,neighbors=n)
    params=selected(src,previous)
    path=out/'floor_wknn_parameters.json'
    path.write_text(json.dumps(dict(candidates=dict(reference=['raw','prototype'],alpha=ALPHAS,k=NEIGHBORS),
                  formula='Distance of historical floor j multiplied by exp(alpha*(abs(j-target_floor)-1)). '
                  'Support distance multiplier 1. Ties by training CSV row, or smallest prototype member row.',
                  source='UJI training-only, source_trust cross-device 2 eligible query phones per floor, '
                  '4 support draws x all budgets. Equal building/floor/device/draw/K. '
                  'Test building excluded; external uses all UJI sources.',selected=params),indent=2)+'\n')
    fit=json.loads(path.read_text())['selected']
    valid=read_floors(data,'validationData.csv')
    official=[dict(building=b,floor=f) for b,f in train]
    measure(train,phones,official,fit,valid).to_csv(out/'floor_wknn_official.csv',index=False)
    stress=json.loads((old/'device_stress_design.json').read_text())['events']
    measure(train,phones,[s for s in stress if not s.get('unavailable')],fit).to_csv(out/'floor_wknn_phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','old','out'):p.add_argument(n,type=Path)
    a=p.parse_args(); main(a.data,a.old,a.out)
