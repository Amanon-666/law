"""Reconstruct fixed B1 low-K held-phone losses at individual query locations.

No hyperparameter, Q subset, or method is selected here. B1 is a post-hoc
counterexample from the previous scan-level evaluation, not a new benchmark.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from refi import fit_map
from ..protocol import read_floors
from ..smooth_scale import local_rows
from .external_floor_wknn import GapReference


def main(data,manifest,wk_fit,paired,out):
    out.mkdir(exist_ok=True,parents=True)
    train=read_floors(data,'trainingData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    fixed=json.loads(manifest.read_text());ref,alpha,k_w=json.loads(wk_fit.read_text())['selected']['1']['gap_fit']
    jobs=[j for j in fixed['events'] if j['building']==1];rows=[]
    for job in jobs:
        f,dev=job['floor'],job['phone'];target=train[1,f];hs=[];gaps=[]
        for (b,floor),h in sorted(train.items()):
            if b!=1 or f==floor:continue
            keep=phone[h['ids']]!=dev
            if keep.any():hs.append({key:v[keep] for key,v in h.items()});gaps.append(abs(f-floor))
        if [len(h['ids']) for h in hs]!=job['retained_history_scans']:raise AssertionError('History mismatch')
        qi=local_rows(target,np.asarray(job['query_ids']));q={key:v[qi] for key,v in target.items()}
        orders=local_rows(target,np.asarray(job['support_orders']));assert (phone[q['ids']]==dev).all() and not (phone[target['ids'][orders]]==dev).any()
        if len(q['rss'])!=12 or len(np.unique(q['xy'],axis=0))!=12:raise ValueError('Unexpected query units')
        hdist=cKDTree(np.vstack([h['xy'] for h in hs])).query(q['xy'])[0]
        bank=GapReference(hs,gaps,ref);matched=bank.query(q['rss']);empty={key:v[:0] for key,v in target.items()}
        field0=fit_map(hs,empty,floor_gaps=gaps).predict(q['rss'])
        match0=bank.event(matched,empty,alphas=(alpha,))[alpha,k_w]
        for draw,order in enumerate(orders):
            for k in (1,3):
                s={key:v[order[:k]] for key,v in target.items()}
                model=fit_map(hs,s,floor_gaps=gaps);field=model.predict(q['rss']);match=bank.event(matched,s,alphas=(alpha,))[alpha,k_w]
                sd=cKDTree(s['xy']).query(q['xy'])[0]
                for i,(qx,qy) in enumerate(q['xy']):
                    values={}
                    for name,a in [('field',field),('wk',match),('field_H',field0),('wk_H',match0)]:
                        values[name+'_error']=float(np.linalg.norm(a[i]-q['xy'][i]))
                        values[name+'_x']=float(a[i,0]);values[name+'_y']=float(a[i,1])
                    rows.append(dict(building=1,floor=f,phone=dev,draw=draw,K=k,query_id=int(q['ids'][i]),
                                     x=qx,y=qy,AP_observed=int((q['rss'][i]!=100).sum()),AP_permitted=int((q['rss'][i,model.visible]!=100).sum()),
                                     near_H=float(hdist[i]),near_S=float(sd[i]),**values))
    x=pd.DataFrame(rows);x['delta']=x.field_error-x.wk_error;x['delta_H']=x.field_H_error-x.wk_H_error
    x.to_csv(out/'b1_predictions.csv.gz',index=False)
    key=['building','floor','draw','K'];orig=pd.read_csv(paired).query('building==1 and K in [1,3]').set_index(key).sort_index()
    computed=x.groupby(key)[['field_error','wk_error']].mean().sort_index()
    if len(computed)!=80 or not computed.index.equals(orig.index):raise ValueError('Event alignment mismatch')
    gap=np.absolute(computed.to_numpy()-orig[['field_tobit','old_wknn_gap_fit']].to_numpy()).max(0)
    if gap.max()>1e-8:raise AssertionError('Original results did not replicate')
    qs=x.groupby(['floor','phone','K','query_id'],as_index=False).agg({c:'mean' for c in ['x','y','delta','delta_H','field_error','wk_error','field_H_error','wk_H_error','near_H','near_S','AP_observed','AP_permitted']})
    # Fixed 4 floors and 12 query locations per floor: this signed column sums
    # to the B1 mean across all 48 positions at the same K.
    qs['contribution_to_B1_mean']=qs.delta/48.
    qs.to_csv(out/'b1_positions.csv',index=False)
    floors=[]
    for (f,d,k),g in qs.groupby(['floor','phone','K']):
        lead=g.loc[g.delta.idxmax()];top=-np.sort(-g.delta.to_numpy())
        floors.append(dict(floor=int(f),phone=int(d),K=int(k),field=g.field_error.mean(),wk=g.wk_error.mean(),delta=g.delta.mean(),
                           field_H=g.field_H_error.mean(),wk_H=g.wk_H_error.mean(),delta_H=g.delta_H.mean(),
                           n_field_worse=int((g.delta>0).sum()),positive_contribution_to_B1=g.delta.clip(lower=0).sum()/48.,
                           negative_contribution_to_B1=g.delta.clip(upper=0).sum()/48.,worst_query_id=int(lead.query_id),
                           worst_gap=float(lead.delta),top3_positive_fraction=float(top[:3].clip(0).sum()/g.delta.clip(lower=0).sum())))
    fs=pd.DataFrame(floors);fs.to_csv(out/'b1_floor.csv',index=False)
    charts={}
    for k,g in qs.groupby('K'):
        ordered=g.sort_values('delta',ascending=False)
        top=ordered.iloc[0];remain=g[g.query_id!=top.query_id].groupby('floor').delta.mean().mean()
        # Leave-one-location-out retains equal floor weights; this is purely a sensitivity diagnostic.
        charts[int(k)]=dict(mean=float(g.delta.mean()),H_only=float(g.delta_H.mean()),locations_worse=int((g.delta>0).sum()),
                            positive_mass=float(g.delta.clip(lower=0).sum()/48),negative_mass=float(g.delta.clip(upper=0).sum()/48),
                            worst_id=int(top.query_id),worst_floor=int(top.floor),worst_gap=float(top.delta),
                            remove_worst_equal_floor=float(remain),
                            top3=ordered.head(3)[['floor','phone','query_id','delta','delta_H','near_H','near_S']].to_dict('records'))
    rec=dict(known='Post-hoc B1, K1/K3, same 48 preselected positions for all support draws. Deltas are field minus strong WKNN. UJI original coordinate units. Query IDs are zero-based data rows.',
             comparator=dict(reference=ref,alpha=alpha,k=k_w),n_event_rows=len(x),unique_locations=int(qs[['floor','query_id']].drop_duplicates().shape[0]),
             public_MDE_max_abs_error=float(gap[0]),WKNN_MDE_max_abs_error=float(gap[1]),by_K=charts)
    (out/'b1_counterexample.json').write_text(json.dumps(rec,indent=2,allow_nan=False)+'\n')
    cluster={}
    for k,g in qs[qs.floor==2].groupby('K'):
        top=g.nlargest(3,'delta');xy=top[['x','y']].to_numpy()
        cluster[int(k)]=dict(posthoc_selection='three largest signed floor-2 excesses',
                             ids=top.query_id.tolist(),APs=top.AP_observed.tolist(),
                             max_pair_distance=float(np.linalg.norm(xy[:,None]-xy,axis=2).max()),
                             share_of_positive_F2=float(top.delta.sum()/g.delta.clip(lower=0).sum()),
                             contribution_to_B1=float(top.delta.sum()/48.),
                             F2_excluding_group=float(g[~g.query_id.isin(top.query_id)].delta.mean()))
    (out/'b1_spatial_group.json').write_text(json.dumps(cluster,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','manifest','wk_fit','paired','out'):p.add_argument(n,type=Path)
    a=p.parse_args();main(a.data,a.manifest,a.wk_fit,a.paired,a.out)
