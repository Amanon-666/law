"""Validate offset scores and compare building/K, floor/K, and draw/K pairs."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import multivariate_normal
from scipy.spatial import cKDTree
from scipy.special import log_ndtr
from ..protocol import read_floors, history_floors
from .match_episodes import maps, eval_tasks, source_tasks
from ..summarize import INDEX
from .match import terms, detected_score


def check_integral():
    q = np.array([[-73.,-81.,100.,-67.],[100.,100.,100.,100.]])
    m = np.array([[-82.,-86.,-98.,-84.],[-73.,-94.,-102.,-63.]])
    sigma,tau=12.,6.
    score=detected_score(terms(q,m),sigma,tau)
    seen=q[0]!=100
    covariance=sigma**2*np.eye(seen.sum())+tau**2*np.ones((seen.sum(),seen.sum()))
    exact=[multivariate_normal.logpdf(q[0,seen],mean=x[seen],cov=covariance) for x in m]
    np.testing.assert_allclose(np.diff(score[0]),np.diff(exact),atol=1e-11,rtol=0.)
    np.testing.assert_array_equal(score[1],0)
    return float(abs(np.diff(score[0])[0]-np.diff(exact)[0]))


def table(win,tier):
    return dict(**{f'{tier}_wins':int((win< -1e-8).sum()),f'{tier}_ties':int((np.abs(win)<=1e-8).sum()),
                   f'{tier}_n':len(win)})


def bias_diagnostics(data, frozen, out):
    """After scoring, trace the MAP motion of the rejected reporting offset."""
    train=read_floors(data,'trainingData.csv')
    valid=read_floors(data,'validationData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    rows=[]
    for mode,filename in [('official','manifest.json'),('device','device_stress_design.json')]:
        manifest=json.loads((frozen/filename).read_text())
        for b,f in train:
            jobs=eval_tasks(train,valid,phones,manifest,b,f,mode)
            for e in maps(train,b,f,jobs):
                m,q=e['prototypes'],e['query']
                t=terms(q,m)
                seen=1.-t['missed']
                total=(np.where(seen,q.astype(float)+75.,0.).sum(1,keepdims=True)
                       -seen@(m+75.).T)
                miss=t['missed']@log_ndtr((-85.-m)/12.).T
                old=(detected_score(t,12.,0.)+miss).argmax(1)
                new=(detected_score(t,12.,6.)+miss).argmax(1)
                i=np.arange(len(q))
                gain=total/(t['n']+4.)
                magnitude=np.linalg.norm(e['xy'][old]-e['xy'][new],axis=1)
                sums=seen@m.T
                difference=(sums[i,old]-sums[i,new])/np.maximum(t['n'].ravel(),1)
                w=e['weight']
                rows.append(dict(mode=mode,building=b,floor=f,draw=e['draw'],K=e['K'],
                    changed=w@(old!=new),signed_shift_at_base_db=w@gain[i,old],
                    signed_shift_at_shifted_db=w@gain[i,new],shifted_weaker_candidate_db=w@difference,
                    mean_map_coordinate_shift=w@magnitude))
    pd.DataFrame(rows).to_csv(out/'bias_diagnostic.csv',index=False)


def geometry(data, frozen, out):
    """Descriptive coverage of historical information in training/evaluation tasks."""
    train=read_floors(data,'trainingData.csv')
    valid=read_floors(data,'validationData.csv')
    raw=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID','TIMESTAMP'])
    phone,time=raw.PHONEID.to_numpy(),raw.TIMESTAMP.to_numpy()
    official=json.loads((frozen/'manifest.json').read_text())
    device=json.loads((frozen/'device_stress_design.json').read_text())
    summaries=[]
    for b,f in train:
        all_xy=np.vstack([h['xy'] for h in history_floors(train,b,f)])
        total=len(np.unique(all_xy,axis=0))
        groups={'source':source_tasks(train,phone,time,b,f),
                'official':eval_tasks(train,valid,phone,official,b,f,'official'),
                'device':eval_tasks(train,valid,phone,device,b,f,'device')}
        for mode,tasks in groups.items():
            for dev,hist,draws in tasks:
                xy=np.vstack([h['xy'] for h in hist])
                points=np.unique(xy,axis=0)
                tree=cKDTree(points)
                seen=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hist])
                dist,absent=[],[]
                for _,_,q in draws:
                    dist.append(tree.query(np.unique(q['xy'],axis=0))[0].mean())
                    detected=q['rss']!=100
                    absent.append((detected[:,~seen].sum(1)/np.maximum(1,detected.sum(1))).mean())
                summaries.append(dict(mode=mode,b=b,f=f,dev=dev,scans=len(xy)/len(all_xy),
                    prop_positions=len(points)/total,mean_qdist=np.mean(dist),query_det_aps_absent_H=np.mean(absent)))
    pd.DataFrame(summaries).to_csv(out/'source_geometry.csv',index=False)


def main(frozen,out):
    gaps={'dense_normal_candidate_logodds_gap':check_integral()}
    reports=[]
    for mode,reference in [('official','smooth_scale_official.csv'),('device','smooth_scale_phone.csv')]:
        d=pd.read_csv(out/(mode+'_events.csv')).set_index(INDEX).drop(columns='phone')
        c=pd.read_csv(out/('coupled_'+mode+'.csv')).set_index(INDEX).drop(columns='phone').add_prefix('coupled_')
        joined=d.join(c,validate='one_to_one')
        ref=pd.read_csv(frozen/reference).query("method=='half10'").set_index(INDEX).mde.sort_index()
        gaps[mode+'_baseline_MDE_max_diff']=float(abs(joined.default-ref).max())
        np.testing.assert_allclose(joined.default.sort_index(),ref,atol=1e-8,rtol=0.)
        if mode=='official':
            strong=pd.read_csv(frozen/'wknn_events.csv').query("method=='joint_tuned'").set_index(INDEX).mde
        else:
            strong=pd.read_csv(frozen/'device_stress_events.csv').query("method=='strong_wknn'").rename(
                columns={'seed':'draw'}).set_index(INDEX).mde
        joined['strong_wknn']=strong
        if len(joined)!=650 or not np.isfinite(joined).all().all():
            raise ValueError('Missing or invalid pairs')
        byfloor=joined.groupby(['building','floor','K']).mean()
        byb=byfloor.groupby(['building','K']).mean()
        for method in ('default','global_fit','fixed_offset','fixed_offset_fit','offset_only_fit','joint_fit',
                       'remove_offset','default_no_misses','global_restore_misses','coupled_default_fixed6',
                       'coupled_default_source','coupled_global_fixed6','coupled_global_source'):
            for baseline in ('default','strong_wknn','global_fit','coupled_default_fixed6'):
                delta=byb[method]-byb[baseline]
                record=dict(mode=mode,method=method,baseline=baseline,MDE=byb[method].mean(),delta=delta.mean(),
                       **table(joined[method]-joined[baseline],'drawK'),**table(byfloor[method]-byfloor[baseline],'floorK'),
                       **table(delta,'buildingK'))
                for name,frame,groups in [('draw',joined,['building','floor','draw']),
                                          ('floor',byfloor,['building','floor']),('building',byb,['building'])]:
                    changes=frame[method].groupby(groups).diff().dropna()
                    record[f'{name}_adjacent_improved']=int((changes < -1e-8).sum())
                    record[f'{name}_adjacent_n']=len(changes)
                reports.append(record)
    pd.DataFrame(reports).to_csv(out/'tiers.csv',index=False)
    (out/'checks.json').write_text(json.dumps(gaps,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('frozen',type=Path)
    p.add_argument('out',type=Path)
    p.add_argument('--data',type=Path,help='Regenerate the additional MAP-motion diagnostic.')
    args=p.parse_args()
    main(args.frozen,args.out)
    if args.data:
        bias_diagnostics(args.data,args.frozen,args.out)
        geometry(args.data,args.frozen,args.out)
