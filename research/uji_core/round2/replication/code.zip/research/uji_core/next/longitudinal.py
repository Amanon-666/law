"""Early/validation/late tasks on UJI library v2.2, Zenodo 3748719, CC BY 4.0.

python -m research.uji_core.next.longitudinal ARCHIVE OUTPUT
These are same-floor campaign transfers, not cross-floor UJIIndoorLoc episodes.
The script only validates data identity, task geometry, and chronology; no scores.
"""
import argparse
import hashlib
import json
import random
import zipfile
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

from residual_probe.episode_rows import nested_rows
from ..protocol import BUDGETS, SEEDS, position_weights

SHA256='0a74d814be48359dc4b9f7aee26cf8905574d4999db722aa477cfd571a2ce505'
STAGES={'source':tuple(range(3,8)),'validation':tuple(range(10,16)),
        'late':tuple(range(18,26)),'late_A5':(25,)}


@lru_cache(maxsize=4)
def verified(archive):
    if hashlib.sha256(Path(archive).read_bytes()).hexdigest()!=SHA256:
        raise ValueError('Unexpected UJI LIB v2.2 archive')
    return True


@lru_cache(maxsize=128)
def campaign(archive,month,stream,campaign_number):
    """Full released campaign. XY is the original metric horizontal frame."""
    verified(archive)
    if stream not in ('trn','tst'): raise ValueError(stream)
    pref=f'db/{month:02}/{stream}{campaign_number:02}'
    with zipfile.ZipFile(archive) as zip_:
        def load(suffix,dtype):
            with zip_.open(pref+suffix+'.csv') as f:
                return pd.read_csv(f,header=None,dtype=dtype,float_precision='round_trip').to_numpy()
        rss=load('rss',np.int16); coord=load('crd',float)
        ids=load('ids',str)[:,0].astype('U10'); times=load('tms',np.int64)[:,0]
    if rss.shape!=(len(coord),620) or len(np.unique(ids))!=len(ids) or len(times)!=len(ids):
        raise ValueError(pref)
    if np.any((rss!=100)&((rss< -110)|(rss>0))): raise ValueError('Invalid measured RSS')
    return dict(rss=rss,xy=coord[:,:2],floor=coord[:,2].astype(int),ids=ids,times=times)


def take(table, rows):
    return {k:v[rows] for k,v in table.items()}


def on_floor(archive,month,stream,n,floor):
    a=campaign(archive,month,stream,n)
    return take(a,a['floor']==floor)


def episodes(archive,stage,seeds=SEEDS):
    """Yield metadata, one old history dict, K target support rows, and query dict.

    Draws in each month/floor are independent, K shares a prefix. In early
    training, select Q on four of the 24 reference positions, all repeats.
    Validation/late Q come from separate, later measured, off-grid test files.
    """
    if stage not in STAGES: raise ValueError(stage)
    for t in STAGES[stage]:
        for floor in (3,5):
            h=on_floor(archive,t-2,'trn',15 if t==3 else 1,floor)
            calibration=on_floor(archive,t-1,'trn',1,floor)
            if stage=='source':
                stream='trn'; files=(1,)
            else:
                stream='tst'; files=(7,8,9) if stage=='late_A5' else (2,3,4)
            qs=[on_floor(archive,t,stream,n,floor) for n in files]
            available={k:np.concatenate([x[k] for x in qs]) for k in qs[0]}
            if not h['times'].max()<calibration['times'].min() or not calibration['times'].max()<available['times'].min():
                raise ValueError('Noncausal measurement timestamps')
            train_xy={tuple(p) for p in calibration['xy']}
            query_xy={tuple(p) for p in available['xy']}
            if stage=='source' and query_xy!=train_xy: raise ValueError('Source grid changed')
            if stage!='source' and not train_xy.isdisjoint(query_xy): raise ValueError('Test position overlaps')
            for draw in seeds:
                key=f'uji-lib-lag-v1/{stage}/{t}/{floor}/{draw}'
                permitted=list(range(len(calibration['rss'])))
                if stage=='source':
                    fixed=set(random.Random(key+'/query').sample(sorted(train_xy),4))
                    q=take(available,[i for i,p in enumerate(available['xy']) if tuple(p) in fixed])
                    permitted=[i for i in permitted if tuple(calibration['xy'][i]) not in fixed]
                else:
                    q=dict(available)
                q['weights']=position_weights(q['xy'])
                order=nested_rows(calibration['xy'],permitted,BUDGETS,0,key+'/support')['support_rows'][max(BUDGETS)]
                for k in BUDGETS:
                    s=take(calibration,order[:k])
                    yield dict(stage=stage,month=t,history_month=t-2,support_month=t-1,floor=floor,
                               draw=draw,K=k,query_stream=stream,query_campaigns=files,
                               device='S3->S3->A5' if stage=='late_A5' else 'S3->S3->S3'),h,s,q


def prepare(archive,out):
    verified(archive);out.mkdir(exist_ok=True,parents=True)
    stage_summary={}; rows=[]
    for stage in STAGES:
        count=0
        for m,h,s,q in episodes(archive,stage):
            count+=1
            if m['K']!=max(BUDGETS):continue
            # All file positions repeat across seeds on held-out streams;
            # a fixed hash compactly checks Q membership without duplicating IDs.
            rows.append(dict(**m,support_order=s['ids'].tolist(),n_H=len(h['rss']),
                             n_Q=len(q['rss']),unique_Q=len(np.unique(q['xy'],axis=0)),
                             hash_ordered_Q=hashlib.sha256(','.join(q['ids']).encode()).hexdigest(),
                             latest_H=int(h['times'].max()),earliest_S=int(s['times'].min()),
                             latest_S=int(s['times'].max()),earliest_Q=int(q['times'].min())))
        stage_summary[stage]=count
    raw_counts={'trn':0,'tst':0}; campaigns={'trn':0,'tst':0};uids=set()
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            if not name.endswith('ids.csv'):continue
            stream=Path(name).name[:3]
            ids=z.read(name).splitlines()
            if set(ids)&uids: raise ValueError('Duplicate sample IDs across campaigns')
            uids.update(ids); raw_counts[stream]+=len(ids); campaigns[stream]+=1
    record=dict(doi='10.5281/zenodo.3748719',sha256=SHA256,license='CC BY 4.0',
        release='2.2',unit='meters',site='Universitat Jaume I library, floors 3 and 5',aps=620,
        reference='G. M. Mendoza-Silva, P. Richter, J. Torres-Sospedra, E. S. Lohan, J. Huerta, Data (2018), doi:10.3390/data3010003',
        raw_counts=raw_counts,campaigns=campaigns,publisher_landing_page_scan_count=103584,
        protocol='Same-floor temporal transfer H=t-2, S=t-1, Q=t on strictly time-ordered acquisitions. '
        'Early Q uses only training files (4 held coordinates per draw); later Q uses off-grid publisher test files. '
        'S3 block ranges 1-7, 8-15, and 16-25 have disjoint raw months; same underlying library and recurrent XY. '
        'Month25_A5 shares the late S3 environment and is not another independent site. '
        'Different from the prior adjacent-month H_{t-1}, S_t, Q_t protocol. '
        'Timestamp strings are ordered directly including four documented seconds=60 rows.',
        stages=STAGES,budgets=BUDGETS,draws=SEEDS,event_counts=stage_summary,records=rows)
    (out/'longitudinal_design.json').write_text(json.dumps(record,indent=2)+'\n')
    print(stage_summary,raw_counts,campaigns)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('archive','output'):p.add_argument(n,type=Path)
    a=p.parse_args();prepare(a.archive,a.output)
