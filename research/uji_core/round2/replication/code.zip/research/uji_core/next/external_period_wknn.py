"""Tune the same ordinal-gap WKNN grid on the same source labels as the field matcher.

Source period episodes use real later surveys in *other* UJI buildings; targets
are excluded for each fold. Device-only controls remain separately identifiable.
"""
import argparse
import json
from itertools import product
from pathlib import Path
import pandas as pd
from ..protocol import read_floors
from ..study import NEIGHBORS
from .transport import source_design
from .external_floor_wknn import ALPHAS, measure


def main(data,old,device_fit,out):
    out.mkdir(parents=True,exist_ok=True)
    train,validation=(read_floors(data,f) for f in ('trainingData.csv','validationData.csv'))
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    periods=[dict(building=b,floor=f) for b,f in train]
    devices=source_design(train,phones)
    for job in devices: job['support_orders']=job['support_orders'][:3]
    p=measure(train,phones,periods,valid=validation,source_period=True).assign(regime='period')
    d=measure(train,phones,devices).assign(regime='device')
    keys=['reference','alpha','neighbors']
    risk=pd.concat([p,d]).groupby(['regime','building','floor','phone',*keys]).mde.mean()
    risk.to_csv(out/'period_wknn_source.csv')
    # mde already averages query scans within exact location; no large floor or
    # source device should receive extra weight because it supplies more scans.
    byfloor=risk.groupby(['regime','building','floor',*keys]).mean()
    bybuilding=byfloor.groupby(['regime','building',*keys]).mean()
    device_settings=json.loads(device_fit.read_text())['selected']
    fits={}
    options=list(product(('raw','prototype'),ALPHAS,NEIGHBORS))
    for held in [0,1,2,'external']:
        source=bybuilding if held=='external' else bybuilding.drop(held,level='building')
        costs=source.groupby(['regime',*keys]).mean().groupby(keys).mean()
        best=lambda grid:min(grid,key=lambda op:(costs.loc[op],op[1],op[0]!='raw',op[2]))
        previous=device_settings[str(held)]
        fits[str(held)]=dict(previous=previous['previous'],device_gap=previous['gap_fit'],
                             no_gap_refit=best([op for op in options if op[1]==0]),gap_fit=best(options))
    cfg=out/'period_wknn_parameters.json'
    cfg.write_text(json.dumps(dict(selected=fits,grid=dict(reference=['raw','prototype'],alpha=ALPHAS,k=NEIGHBORS),
                  source='Same three nested draws and authentic other-building later queries as map_variance_study, '
                  'plus three nested draws of its training-file held-device episodes. Equal regime, building, floor, '
                  'device, draw, K and query position within event. Entire held building excluded. External fit uses '
                  'all UJI source floors, never an external query. Ties to smaller alpha, raw, smaller k.'),indent=2)+'\n')
    fits=json.loads(cfg.read_text())['selected']
    measure(train,phones,periods,fits,validation).to_csv(out/'period_wknn_official.csv',index=False)
    stress=json.loads((old/'device_stress_design.json').read_text())['events']
    measure(train,phones,[s for s in stress if not s.get('unavailable')],fits).to_csv(out/'period_wknn_phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','old','device_fit','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.old,a.device_fit,a.out)
