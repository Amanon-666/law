"""Frozen distance-only parent vs vertical projection under identical episodes."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from ..protocol import BUDGETS,SEEDS,read_floors,split_rows,position_weights
from ..smooth_scale import local_rows
from .transport import source_design
from .vertical import RIDGES, VerticalBank


def run(train,phone,jobs,gap,selection=None,official=None):
    rows=[]
    for j in jobs:
        b,f=j['building'],j['floor']
        target=train[b,f]
        hs,floors=[],[]
        for (bb,ff),history in train.items():
            if bb!=b or ff==f:
                continue
            if official is None:
                mask=phone[history['ids']]!=j['phone']
                history={k:v[mask] for k,v in history.items()}
            if len(history['rss']):
                hs.append(history);floors.append(ff)
        decay=gap[str(b)] if selection is not None else gap
        bank=VerticalBank(hs,floors,f,decay=decay)
        if selection is None:
            priors={str(l):bank.prior(l) for l in RIDGES}
            rho,pairs=None,None
        else:
            lam=selection[str(b)]['ridge']
            rho,pairs=bank.history_shrinkage()
            # Common slope scaling; the remaining AP-identity controls use the same ridge.
            priors=dict(parent=bank.constant,nearest=bank.nearest,ols=bank.prior(0.),
                ridge1=bank.prior(1.),ridge4=bank.prior(4.),ridge_quarter=bank.prior(.25),
                source=bank.prior(lam),shared=bank.prior(lam,'shared'),shuffled=bank.prior(lam,'shuffled'),
                H_closed=bank.constant+rho*(bank.prior(0.)-bank.constant))
        if official is None:
            qr=local_rows(target,np.asarray(j['query_ids']))
            q={k:v[qr] for k,v in target.items()}
            orders=local_rows(target,np.asarray(j['support_orders']))
        else:
            q=official[b,f]
            orders=[split_rows(target,b,f,d)[0] for d in SEEDS]
        w=position_weights(q['xy'])
        for draw,order in enumerate(orders):
            for k in BUDGETS:
                s={name:target[name][order[:k]] for name in ('rss','xy')}
                vals={}
                for name,prior in priors.items():
                    identity=id(prior)
                    if identity not in vals:
                        pred=bank.condition_prior(s,prior).predict(q['rss'])
                        vals[identity]=float(w@np.linalg.norm(pred-q['xy'],axis=1))
                    rows.append((b,f,j.get('phone',-1),draw,k,name,vals[identity],rho,pairs))
        print(f"B{b}F{f} phone={j.get('phone',-1)}",flush=True)
    return pd.DataFrame(rows,columns=['building','floor','phone','draw','K','method','mde','H_rho','H_pairs'])


def main(data,design,trust,out):
    out.mkdir(parents=True,exist_ok=True)
    train=read_floors(data,'trainingData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    gaps={k:float(x['gap_only'][0]) for k,x in json.loads((trust/'fit.json').read_text()).items()}
    jobs=source_design(train,phone)
    for j in jobs:j['support_orders']=j['support_orders'][:4]
    risks={}
    for gamma in sorted(set(gaps.values())):
        source=run(train,phone,jobs,gamma)
        risks[gamma]=source.groupby(['building','floor','method']).mde.mean().groupby(['building','method']).mean()
    fits={}
    for held in ('0','1','2','external'):
        g=gaps[held]
        risk=risks[g]
        if held!='external':risk=risk.drop(int(held),level='building')
        r=risk.groupby('method').mean()
        lam=min(RIDGES,key=lambda v:r[str(v)])
        fits[held]=dict(decay=g,ridge=lam,source_risks={str(v):r[str(v)] for v in RIDGES})
    path=out/'fit.json'
    path.write_text(json.dumps(dict(method='Signed-height weighted local linear interpolation, slope clip ±12 dB/floor, separate exact/smoothed terms. Ridge in floor², null=distance-only. Color-free no-op at one source or zero height variance. Readout, anchors and support residual propagation shared with gap parent.',
        source='Same cross-device source pseudo tasks as source_trust (4 draws, all K), entire target building excluded. External uses all three UJI source buildings. No external target data read.',
        direct_H='Bounded closed-form H-to-H OLS damping at identical registered positions of held source floors; equal eligible H pseudo floors, position, AP; zero when not identifiable.',
        fits=fits),indent=2,allow_nan=False)+'\n')
    fits=json.loads(path.read_text())['fits']
    valid=read_floors(data,'validationData.csv')
    for mode,queue,official in [('official',[dict(building=b,floor=f) for b,f in train],valid),
                              ('phone',json.loads(design.read_text())['events'],None)]:
        result=run(train,phone,[j for j in queue if not j.get('unavailable')],gaps,fits,official)
        ix=['building','floor','draw','K']
        parent=pd.read_csv(trust/(mode+'.csv')).query("method=='gap_only'").set_index(ix).mde.sort_index()
        observed=result.query("method=='parent'").set_index(ix).mde.sort_index()
        np.testing.assert_allclose(observed,parent,rtol=0.,atol=1e-8)
        wide=result.pivot(index=ix,columns='method',values='mde')
        if len(wide)!=650 or wide.shape[1]!=10 or not np.isfinite(wide.values).all():
            raise ValueError('Incomplete vertical comparison')
        wide.to_csv(out/(mode+'.csv'))
        result.drop_duplicates(['building','floor'])[['building','floor','H_rho','H_pairs']].to_csv(out/(mode+'_calibration.csv'),index=False)
        print(mode,wide.groupby(['building','K']).mean().groupby('building').mean().round(3),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','design','trust','out'):p.add_argument(n,type=Path)
    a=p.parse_args()
    main(a.data,a.design,a.trust,a.out)
