"""One frozen conditional-mean test on the original registered external rows.

'prepare' verifies configuration files without reading empirical outcomes;
'score' is a separate, explicit action following the saved freeze receipt.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap
from ..inverse import order,squared,vote
from ..protocol import BUDGETS,position_weights
from .b1_detected_mean import moments
from .conditional_mean_gate import CUTS,frozen_predict
from .external import DATASETS,METRES_PER_UJI_UNIT,read_sod,read_tau
from .external_uncertainty import estimate
from .paired_map_wknn import group_ids


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(designs,fit_path,mapped_params,out):
    constants=Path(__file__).resolve().parents[1]/'round2'/'holdout_protocol.json'
    hashes=json.loads(constants.read_text())['files_sha256']
    split_sha={k:sha(designs/f'external_{k}_protocol.json') for k in DATASETS}
    if any(split_sha[k]!=hashes[f'external_{k}_protocol.json'] for k in DATASETS):
        raise ValueError('External split differs from public precommit')
    conf=json.loads(fit_path.read_text())
    if sha(fit_path)!='0b36024f6832eddde20c044739b2b48edcbf8c8e107fd51c24ecbdcbfc1e2386':
        raise ValueError('Outcome-independent source fit changed')
    vals=conf['folds']['external']['values']
    if conf['bins']!=list(CUTS):raise ValueError('Gate bins differ')
    if sha(mapped_params)!='09037ad1bb36b8f700f9ac202c0ef2421ea4c5f6ca477257458177fb7ea0f516':
        raise ValueError('Same-map neighbor choice changed')
    params={**conf['fixed'],'fixed_gap2':[0.,0.,0.],'conditional_gate':vals['gate'],'tied_scalar':vals['scalar'],
            'source_fixed':vals['source_fixed']}
    out.mkdir(exist_ok=True,parents=True)
    full=dict(hashes=split_sha,fit_sha256=sha(fit_path),fit_source='Only the three UJI buildings; no external fitting.',
              gate_bins=CUTS,params=params,corrected_map_k=json.loads(mapped_params.read_text())['choices']['external'],
              sites={k:v['sites'] for k,v in DATASETS.items()},scale_m=METRES_PER_UJI_UNIT,
              information='All arms use identical H/S/Q IDs and H union current S AP axes for each budget. '
              'Gate changes detected RSS scores over H candidates only; public gap2 m prototypes remain available '
              'to the fixed conditional matcher, tied scalar, selected fixed, and map WKNN. '
              'Join the three separately frozen WKNN tables for comparisons. '
              'Same H/S across increasing K, per-location mean distance in meters.',
              constraints='No reselecting controls or coefficients from any outer data; report all three physical sites, '
              'all six eligible floors, five budgets and ten draws, including deterioration. '
              'TIE1 F0 / SAH1 F1,F2 are same previously studied buildings (SAH1 F2 official previously used). '
              'CETC331 was previously examined for geometry, with 30-scan averages on the training side.')
    (out/'external_gate_freeze.json').write_text(json.dumps(full,indent=2,allow_nan=False)+'\n')
    return full


def score(data,ds,designs,out):
    cfg=json.loads((out/'external_gate_freeze.json').read_text())
    pp=designs/f'external_{ds}_protocol.json'
    if sha(pp)!=cfg['hashes'][ds]:raise ValueError('Changed split after freeze')
    protocol=json.loads(pp.read_text())
    read=read_tau if ds=='tau' else read_sod
    rows=[];per_query=[];checks=[]
    for site in DATASETS[ds]['sites']:
        train,valid=[read(data,site,v) for v in ('training','test')]
        for f,q in sorted(valid.items()):
            jobs=[j for j in protocol['events'] if j['site']==site and j['floor']==f]
            if not jobs:continue
            hs=[v for ff,v in sorted(train.items()) if ff!=f]
            gaps=[abs(ff-f) for ff in sorted(train) if ff!=f]
            m,hxy,prob,cond=moments(hs,gaps)
            allowed_h=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
            xx,hid=group_ids(np.vstack([h['xy'] for h in hs]),np.concatenate([h['ids'] for h in hs]))
            if not np.array_equal(xx,hxy):raise ArithmeticError('Candidate order mismatch')
            bands=np.searchsorted(cfg['gate_bins'],prob,side='right')
            shift=cond-m
            qw=position_weights(q['xy']);t=train[f];parity=0.
            for j in jobs:
                sr=j['support_local']
                if t['ids'][sr].tolist()!=j['support_ids'] or q['ids'].tolist()!=j['query_ids']:
                    raise ValueError('External CSV rows do not reproduce')
                for k in BUDGETS:
                    ids=sr[:k];mask=allowed_h|(t['rss'][ids]!=100).any(0)
                    s=dict(rss=t['rss'][ids][:,mask],xy=t['xy'][ids])
                    proto,xy=tpm.calibrate((m[:,mask],hxy),s,(40.,1.))
                    model=FingerprintMap(proto,xy,mask)
                    store={};pred={}
                    for arm,gate in cfg['params'].items():
                        key=tuple(gate)
                        if key not in store:
                            store[key]=frozen_predict(model,q['rss'],gate,shift[:,mask],bands[:,mask])
                        pred[arm]=store[key]
                    if j['seed']==0 and k in (1,20):
                        er=float(np.max(np.abs(pred['fixed_gap2']-model.predict(q['rss']))))
                        if er>1e-8:raise ArithmeticError('Public readout does not match gate at zero')
                        parity=max(parity,er)
                    _,sids=group_ids(s['xy'],t['ids'][ids])
                    dist=squared(tpm.dbm(q['rss'][:,mask])+110.,proto+110.)
                    nn=order(dist,np.r_[hid,sids],cfg['corrected_map_k'])
                    pred['same_map_wknn']=vote(np.take_along_axis(dist,nn,axis=1),xy[nn]-xy[0],mask.sum())[0]+xy[0]
                    for arm,y in pred.items():
                        e=np.linalg.norm(y-q['xy'],axis=1)*METRES_PER_UJI_UNIT
                        if not np.isfinite(e).all():raise FloatingPointError((site,f,k,arm))
                        key=dict(site=site,floor=f,seed=j['seed'],K=k,method=arm)
                        rows.append(dict(**key,mde=float(qw@e)))
                        per_query.append(pd.DataFrame(dict(**key,row_id=q['ids'],err_m=e,w=qw)))
            checks.append(dict(site=site,floor=f,zero_vs_public_max_coord_diff=parity))
    new=pd.DataFrame(rows)
    known=[pd.read_csv(designs/name)[['site','floor','seed','K','method','mde']] for name in [
        f'external_{ds}_events.csv',f'external_{ds}_challengers.csv',f'external_{ds}_period_challengers.csv']]
    combined=pd.concat([new,*known],ignore_index=True)
    ix=['site','floor','seed','K','method']
    counts=combined.groupby('method').size()
    if combined.duplicated(ix).any() or counts.nunique()!=1 or counts.iloc[0]!=len(protocol['events'])*len(BUDGETS):
        raise ValueError('Unmatched external arms or events')
    combined.to_csv(out/f'{ds}_gate_events.csv',index=False)
    pd.concat(per_query).to_csv(out/f'{ds}_gate_queries.csv.gz',index=False)
    pd.DataFrame(checks).to_csv(out/f'{ds}_parity.csv',index=False)
    ctrls=list(dict.fromkeys([key for key in cfg['params'] if key!='conditional_gate'] + ['strong_wknn','floor_wknn','period_floor_wknn','same_map_wknn']))
    pd.concat([estimate(combined,'conditional_gate',r) for r in ctrls]).to_csv(out/f'{ds}_contrasts.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='action',required=True)
    a=sub.add_parser('prepare')
    for n in ('designs','fit','mapped','out'):a.add_argument(n,type=Path)
    a=sub.add_parser('score')
    a.add_argument('dataset',choices=DATASETS)
    for n in ('data','designs','out'):a.add_argument(n,type=Path)
    arg=p.parse_args()
    if arg.action=='prepare':prepare(arg.designs,arg.fit,arg.mapped,arg.out)
    else:score(arg.data,arg.dataset,arg.designs,arg.out)
