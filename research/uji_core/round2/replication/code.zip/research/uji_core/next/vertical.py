"""Predict a registered target-floor fingerprint by local linear regression in height.

The only new fitted quantity is a nonnegative ridge (square floor indices).
None gives the same distance-weighted constant-height model as source_trust.
"""
from dataclasses import dataclass
import numpy as np
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap
from .source_trust import Bank

RIDGES = (None, 4., 1., .25, 0.)
MAX_SLOPE = 12.  # dB of filled fingerprint value per floor


@dataclass
class Moments:
    mean: np.ndarray
    height: np.ndarray
    variance: np.ndarray
    covariance: np.ndarray
    nearest: np.ndarray


def moments(num,den,z,decay):
    # num[j,x,a] is den[j,x] times the component's RSS prototype.
    w=np.exp(-decay*(np.abs(z)-np.abs(z).min()))[:,None]
    mass=(w*den).sum(0)
    height=(w*den*z[:,None]).sum(0)/mass
    centered=z[:,None]-height
    mean=np.einsum('jx,jxa->xa',np.broadcast_to(w,den.shape),num)/mass[:,None]
    variance=(w*den*centered**2).sum(0)/mass
    covariance=np.einsum('jx,jxa->xa',w*centered,num)/mass[:,None]
    gap=np.where(den>0,np.abs(z)[:,None],np.inf)
    nearest=(gap==gap.min(0))
    nearest_mean=np.einsum('jx,jxa->xa',nearest.astype(float),num)/(nearest*den).sum(0)[:,None]
    return Moments(mean,height,variance,covariance,nearest_mean)


class VerticalBank:
    def __init__(self,histories,floors,target_floor,*,decay=2.,unit=1.):
        self.histories=tuple(histories)
        self.floors=np.asarray(floors,dtype=float)
        if len(self.histories)!=len(self.floors) or not len(self.floors):
            raise ValueError('Need one floor per registered history')
        if (not np.isfinite(self.floors).all() or not np.isfinite(target_floor) or
                not np.isfinite(decay) or decay<0 or not np.isfinite(unit) or unit<=0):
            raise ValueError('Invalid height, distance decay or coordinate unit')
        if target_floor in self.floors:
            raise ValueError('Target floor cannot be part of its own history')
        self.unit,self.decay=unit,decay
        z=self.floors-target_floor
        base=Bank(histories,np.abs(z),unit=unit)
        self.xy,self.hmask=base.xy,base.hmask
        self.blocks=(moments(base.numer,base.exact,z,decay),
                     moments(base.num_smooth,base.den_smooth,z,decay))
        self.constant=.5*(self.blocks[0].mean+self.blocks[1].mean)
        self.nearest=.5*(self.blocks[0].nearest+self.blocks[1].nearest)
        # Derangement within quartiles of H peak strength controls AP identity.
        active=np.flatnonzero(self.hmask)
        ordered=active[np.argsort(self.constant[:,active].max(0),kind='stable')]
        permutation=np.arange(len(self.hmask))
        rng=np.random.default_rng(480970)
        for group in np.array_split(ordered,4):
            p=rng.permutation(group)
            permutation[p]=np.roll(p,1)
        self.permutation=permutation

    def prior(self,ridge,mode='per_ap'):
        if ridge is None:
            return self.constant
        if not np.isfinite(ridge) or ridge<0:
            raise ValueError('Expected a finite nonnegative height ridge, or None')
        components=[]
        for block in self.blocks:
            scale=block.variance+ridge
            slope=np.divide(block.covariance,scale[:,None],out=np.zeros_like(block.covariance),
                            where=block.variance[:,None]>1e-10)
            slope=np.clip(slope,-MAX_SLOPE,MAX_SLOPE)
            if mode=='shared':
                value=slope[:,self.hmask].mean(1) if self.hmask.any() else np.zeros(len(slope))
                slope=np.broadcast_to(value[:,None],slope.shape).copy()
                slope[:,~self.hmask]=0.
            elif mode=='shuffled':
                slope=slope[:,self.permutation]
            elif mode!='per_ap':
                raise ValueError('Unknown per-AP slope control')
            components.append(np.clip(block.mean-block.height[:,None]*slope,-110.,0.))
        return .5*(components[0]+components[1])

    def condition(self,support,ridge=None):
        prior=self.prior(ridge)
        return self.condition_prior(support,prior)

    def condition_prior(self,support,prior):
        sxy=np.asarray(support['xy'],dtype=float)
        rss=np.asarray(support['rss'])
        if (rss.ndim!=2 or rss.shape[1]!=len(self.hmask) or sxy.shape!=(len(rss),2)
                or not np.isfinite(rss).all() or not np.isfinite(sxy).all()):
            raise ValueError('Expected finite support scans, aligned APs and XY')
        active=self.hmask|(rss!=100).any(0)
        value,xy=tpm.calibrate((prior[:,active],self.xy),dict(rss=rss[:,active],xy=sxy),(40.*self.unit,1.))
        return FingerprintMap(value,xy,active)

    def history_shrinkage(self):
        """Fit a bounded multiplier by predicting other H floors at exact shared XY.

        The score is filled RSS squared error, equal means across eligible held
        H floors and their shared positions / historically visible APs. S and
        real target data do not enter this slope calibration.
        """
        cross,quad,pairs=0.,0.,0
        for j,h in enumerate(self.histories):
            others=self.histories[:j]+self.histories[j+1:]
            if len(others)<2:
                continue
            source=VerticalBank(others,np.delete(self.floors,j),self.floors[j],
                                decay=self.decay,unit=self.unit)
            anchor,xy=tpm.position_map(tpm.dbm(h['rss']),h['xy'])
            indices={tuple(v):i for i,v in enumerate(source.xy)}
            paired=[(i,indices[tuple(v)]) for i,v in enumerate(xy) if tuple(v) in indices]
            if not paired or not source.hmask.any():
                continue
            qi,mi=np.asarray(paired).T
            pred=source.constant[mi][:,source.hmask]
            difference=source.prior(0.)[mi][:,source.hmask]-pred
            innovation=anchor[qi][:,source.hmask]-pred
            cross+=float(np.mean(innovation*difference))
            quad+=float(np.mean(difference**2))
            pairs+=len(qi)
        rho=float(np.clip(cross/quad,0.,1.)) if quad>1e-12 else 0.
        return rho,pairs
