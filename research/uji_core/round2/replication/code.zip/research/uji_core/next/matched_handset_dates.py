"""Frozen local-variance versus fixed12 on four matching grid campaigns in month 25.

Run from the repository with python -m research.uji_core.next.matched_handset_dates
ARCHIVE MAP_VARIANCE_FIT_JSON OUTPUT. H/S are month 23/24, both Galaxy S3.
Each measured point is excluded from S in the fold in which it serves as Q.
"""
import argparse
from itertools import combinations
import hashlib
import json
from pathlib import Path
import random

import numpy as np
import pandas as pd

from residual_probe.episode_rows import nested_rows
from ..protocol import BUDGETS, SEEDS
from . import longitudinal as lib
from .external import METRES_PER_UJI_UNIT as UNIT
from .map_variance import VarianceBank
from .matched_handsets import norm_floor, range_text, stamp


CELLS = {'S3_Jul06': 1, 'A5_Jul06': 6, 'S3_Jul13': 5, 'A5_Jul13': 10}
DATES = ('Jul06', 'Jul13')
PHONES = ('S3', 'A5')


def get_cells(archive, floor, history, support):
    cells = {key: lib.on_floor(archive, 25, 'tst', number, floor)
             for key, number in CELLS.items()}
    xy = cells['S3_Jul06']['xy']
    distinct, inverse, counts = np.unique(xy, axis=0, return_inverse=True, return_counts=True)
    if len(distinct) != 24 or not np.all(counts == 12):
        raise ValueError('Unexpected grid or repeat counts')
    for past in (history, support):
        np.testing.assert_array_equal(np.unique(past['xy'], axis=0), distinct)
    for key, cell in cells.items():
        np.testing.assert_array_equal(xy, cell['xy'])
        np.testing.assert_array_equal([x[4:] for x in cell['ids']],
                                      [x[4:] for x in cells['S3_Jul06']['ids']])
        date = '2018-07-06' if key.endswith('Jul06') else '2018-07-13'
        if not all(stamp(t).date().isoformat() == date for t in cell['times']):
            raise ValueError('Campaign timestamp changed')
    for ca, cb in combinations(cells.values(), 2):
        if np.array_equal(ca['rss'], cb['rss']) or set(ca['ids']) & set(cb['ids']):
            raise ValueError('Duplicate scans or identifiers')
    for date in DATES:
        if cells['S3_'+date]['times'].max() >= cells['A5_'+date]['times'].min():
            raise ValueError('Unexpected session order')
    if not history['times'].max() < support['times'].min() <= support['times'].max() < min(cell['times'].min() for cell in cells.values()):
        raise ValueError('H/S/Q chronology failed')
    return cells, distinct, inverse.ravel()


def add_contrasts(results):
    """Scalar differences in measured paired Euclidean errors, in metres."""
    for key in CELLS:
        results[key+'_delta'] = results[key+'_local'] - results[key+'_fixed']
    for metric in ('fixed', 'local', 'delta'):
        for date in DATES:
            results['A5_minus_S3_'+date+'_'+metric] = results['A5_'+date+'_'+metric] - results['S3_'+date+'_'+metric]
        for phone in PHONES:
            results['Jul13_minus_Jul06_'+phone+'_'+metric] = results[phone+'_Jul13_'+metric] - results[phone+'_Jul06_'+metric]
        results['date_phone_interaction_'+metric] = results['A5_minus_S3_Jul13_'+metric] - results['A5_minus_S3_Jul06_'+metric]
    return results


def main(archive, fit, out):
    out.mkdir(parents=True, exist_ok=True)
    law = json.loads(fit.read_text())['choices']['external']['full']
    if law != ['local', 12., 1., .25]:
        raise ValueError('Frozen all-UJI variance law changed')
    manifest = dict(archive_sha256=lib.SHA256, variance_fit_sha256=hashlib.sha256(fit.read_bytes()).hexdigest(),
        archive_doi='10.5281/zenodo.3748719', source='month23 trn01 S3 historical; month24 trn01 S3 calibration',
        local=law, fixed12=[12.,0.,0.], unit='metres', test_campaigns=CELLS, draws=list(SEEDS), K=list(BUDGETS),
        protocol='Two floors. Six pre-seeded folds/floor of four held-out survey positions, yielding disjoint Q/S for each field. H covers all 24 original grid points from an older survey. Each held Q position and all 12 measured scans are shared over the four sessions, all K, and ten draws. Each support row and corrected map are shared by all four cells. No query radio values or prediction errors used to split the grid. This panel is on the survey grid; off-grid results are separate.',
        contrast='delta = local minus fixed12. Within-date phone contrast (A5 minus S3) compares variance benefit. Within-phone date contrast is July13 minus July06. Date-phone interaction in delta is the July13 phone contrast minus the July06 phone contrast. Each averages a within-XY, support-matched difference. Positive = larger error difference.',
        time_limit='All four scans per matched point/facing/repeat are measured in different sessions. Phones collected sequentially with S3 first each day. Date and session order are real; handset-only causal effects are unidentified.',
        floors=[], splits=[])
    points = []
    for floor in (3, 5):
        h = lib.on_floor(archive, 23, 'trn', 1, floor)
        s = lib.on_floor(archive, 24, 'trn', 1, floor)
        cells, xy, inverse = get_cells(archive, floor, h, s)
        manifest['floors'].append(dict(floor=floor,history_window=range_text(h['times']),
            support_window=range_text(s['times']),campaign_windows={key:range_text(v['times']) for key,v in cells.items()},
            scans_per_cell=len(inverse),positions_per_cell=len(xy),scans_per_location=12))
        bank = VarianceBank([norm_floor(h)])
        indices = list(range(len(xy)))
        random.Random(f'lib-m25-handset-date-v1/{floor}/geometry').shuffle(indices)
        for block in range(6):
            held = sorted(indices[4*block:4*block+4])
            held_xy = {tuple(xy[i]) for i in held}
            eligible = [i for i, pt in enumerate(s['xy']) if tuple(pt) not in held_xy]
            qrows = np.flatnonzero(np.isin(inverse, held))
            if len(qrows) != 48:
                raise ValueError('Unexpected query count')
            for draw in SEEDS:
                key = f'lib-m25-handset-date-v1/{floor}/{block}/{draw}'
                order = nested_rows(s['xy'], eligible, BUDGETS, 0, key)['support_rows'][20]
                chosen = set(map(tuple, s['xy'][order]))
                if len(chosen) != 20 or chosen & held_xy:
                    raise ValueError('Nonunique or overlapping support')
                manifest['splits'].append(dict(floor=floor,block=block,draw=draw,
                    held_xy=xy[held].tolist(),nested_support=s['ids'][order].tolist()))
                for k in BUDGETS:
                    field = bank.condition(norm_floor(s, order[:k]))
                    errors = {}
                    for label, cell in cells.items():
                        rss = cell['rss'][qrows]
                        for method, sigma in [('fixed', (12.,0.,0.)), ('local', law[1:])]:
                            e = np.linalg.norm(field.predict(rss, sigma)*UNIT - cell['xy'][qrows], axis=1)
                            errors[label+'_'+method] = [e[inverse[qrows] == i].mean() for i in held]
                    points.append(pd.DataFrame(dict(floor=floor, block=block,draw=draw,K=k,
                        x=xy[held,0],y=xy[held,1],**errors)))
    rows = add_contrasts(pd.concat(points,ignore_index=True))
    if len(rows)!=2*24*10*5 or rows[['floor','draw','K','x','y']].duplicated().any() or not np.isfinite(rows.values).all():
        raise ValueError('Incomplete paired panel')
    metrics = [k for k in rows if k not in ('floor','block','draw','K','x','y')]
    rows.to_csv(out/'paired_panel_xy_draw_K.csv.gz',index=False)
    rows.groupby(['floor','x','y'])[metrics].mean().to_csv(out/'paired_panel_xy.csv')
    rows.groupby('floor')[metrics].mean().to_csv(out/'paired_panel_floor.csv')
    by_k = rows.groupby('K')[metrics].mean()
    by_k.loc['all'] = rows[metrics].mean()
    by_k.to_csv(out/'paired_panel_effects.csv')
    (out/'design.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
    print(by_k[[c for c in metrics if c.endswith('_delta')]].round(4).to_string())


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('archive','fit','out'):
        p.add_argument(n, type=Path)
    a = p.parse_args()
    main(a.archive, a.fit, a.out)
