"""Can the K labeled scans tell which historical floor is useful in each region?

Keep the half-smoothed map, support update and matcher fixed. Only the weights
in the two existing historical averages vary. A source's vote depends on its
floor gap and how well its own map localized the support scans near x.
"""
import argparse
import json
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from external_baselines import tpm_adapter as tpm
from refi import smooth_history, FingerprintMap
from ..protocol import BUDGETS, SEEDS, read_floors, position_weights, split_rows
from ..smooth_scale import local_rows
from .transport import source_design

GAP = (0., .7, 2.)
TRUST = (0., 1., 3.)
KEYS = [(gap, trust, local) for gap, trust in product(GAP, TRUST)
        for local in ((False, True) if trust else (False,))]


class Bank:
    def __init__(self, histories, gaps, unit=1.):
        """unit is the map coordinate length corresponding to one UJI unit."""
        self.unit = unit
        self.gap = np.asarray(gaps, dtype=float)
        self.hmask = np.logical_or.reduce([(h['rss']!=100).any(0) for h in histories])
        maps = [tpm.position_map(tpm.dbm(h['rss']), h['xy']) for h in histories]
        self.maps = [smooth_history(m, 10.*unit, .5) for m in maps]
        self.xy = np.unique(np.vstack([m[1] for m in maps]),axis=0)
        ix = {tuple(p):i for i,p in enumerate(self.xy)}
        m = np.zeros((len(maps),len(self.xy),len(self.hmask)))
        counts = np.zeros(m.shape[:2])
        for j,(v,loc) in enumerate(maps):
            idx = [ix[tuple(p)] for p in loc]
            counts[j,idx] = 1.
            m[j,idx] = v
        self.exact = counts / counts.sum(0)
        self.numer = m*self.exact[:,:,None]
        ker = np.exp(-cdist(self.xy,self.xy,'sqeuclidean') / (2*(10.*unit)**2))
        ker /= ker.sum(1, keepdims=True)
        self.den_smooth = self.exact @ ker.T
        self.num_smooth = ker @ self.numer

    def support_features(self, rss, xy, visible):
        # Errors are measured in the common target/reference coordinate frame.
        # A centered, clipped error removes each support scan's difficulty.
        errors = []
        for m, locations in self.maps:
            w = tpm.tobit_weights(rss[:,visible],m[:,visible],12.,-85.)
            pred = w @ (locations-locations[0]) + locations[0]
            errors.append(np.minimum(np.linalg.norm(pred-xy,axis=1)/(20.*self.unit),3.))
        e = np.stack(errors)
        e -= e.mean(0)
        k = np.exp(-cdist(self.xy,xy,'sqeuclidean')/(2*(40.*self.unit)**2))
        local = (e @ k.T) / (1+k.sum(1))
        global_ = e.sum(1,keepdims=True)/(1+e.shape[1])
        return global_,local

    def adapt(self, rss, sxy, mask, features, params):
        gap, trust, local = params
        logits = -gap*self.gap[:,None] - trust*features[int(local)]
        w = np.exp(logits-logits.max(0))
        def average(num, den):
            return np.einsum('jx,jxa->xa',w,num[:,:,mask]) / (w*den).sum(0)[:,None]
        prior = .5*(average(self.numer,self.exact)+average(self.num_smooth,self.den_smooth))
        signals,coords = tpm.calibrate((prior,self.xy),dict(rss=rss[:,mask],xy=sxy),(40.*self.unit,1.))
        return FingerprintMap(signals, coords, mask)


def run_jobs(train, phone, jobs, selection=None, official=None):
    records=[]
    for j in jobs:
        b,f=j['building'],j['floor']
        t=train[b,f]
        hist=[]
        gaps=[]
        for (hb,hf), h in train.items():
            if hb!=b or hf==f:
                continue
            if official is None:
                h={key:v[phone[h['ids']]!=j['phone']] for key,v in h.items()}
            if len(h['rss']):
                hist.append(h)
                gaps.append(abs(hf-f))
        bank=Bank(hist,gaps)
        if official is None:
            qidx=local_rows(t,np.asarray(j['query_ids']))
            q={key:v[qidx] for key,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))
        else:
            q=official[b,f]
            orders=[split_rows(t,b,f,s)[0] for s in SEEDS]
        qw=position_weights(q['xy'])
        arms={str(p):p for p in KEYS} if selection is None else selection[str(b)]
        for draw,order in enumerate(orders):
            for k in BUDGETS:
                sr=order[:k]
                rss,xy=t['rss'][sr],t['xy'][sr]
                mask=bank.hmask|(rss!=100).any(0)
                feat=bank.support_features(rss,xy,mask)
                cache={}
                for name,params in arms.items():
                    p=tuple(params)
                    if p not in cache:
                        model=bank.adapt(rss,xy,mask,feat,p)
                        error=np.linalg.norm(model.predict(q['rss'])-q['xy'],axis=1)
                        cache[p]=qw @ error
                    records.append((b,f,j.get('phone',-1),draw,k,name,*p,cache[p]))
    return pd.DataFrame(records,columns=['building','floor','phone','draw','K','method','gap','trust','local','mde'])


def main(data, design_path, out):
    out.mkdir(parents=True,exist_ok=True)
    train=read_floors(data,'trainingData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=source_design(train,phone)
    # Four nested draws per source device and full ten draws at test time.
    for j in jobs:
        j['support_orders']=j['support_orders'][:4]
    src=run_jobs(train,phone,jobs)
    keys=['gap','trust','local']
    risk=src.groupby(['building','floor',*keys]).mde.mean().groupby(['building',*keys]).mean()
    risk.to_csv(out/'source_risk.csv')
    choices={}
    for held in [0,1,2,'external']:
        r=(risk if held=='external' else risk.drop(held,level='building')).groupby(keys).mean()
        best=lambda ps:min(ps,key=lambda p:(r.loc[p],sum(p)))
        choices[str(held)]=dict(identity=(0.,0.,False),fixed_gap=(.7,0.,False),
            fixed_local=(.7,1.,True),fixed_agreement=(0.,1.,True),
            gap_only=best(p for p in KEYS if p[1]==0), global_fit=best(p for p in KEYS if not p[2]),
            local_fit=best(p for p in KEYS if p[2] or p[1]==0))
    file=out/'fit.json'
    file.write_text(json.dumps(choices,indent=2)+'\n')
    fitted=json.loads(file.read_text())
    official=read_floors(data,'validationData.csv')
    run_jobs(train,phone,[dict(building=b,floor=f) for b,f in train],fitted,official).to_csv(out/'official.csv',index=False)
    stress=json.loads(design_path.read_text())['events']
    run_jobs(train,phone,[s for s in stress if not s.get('unavailable')],fitted).to_csv(out/'phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('data','design','out'):
        p.add_argument(key,type=Path)
    a=p.parse_args()
    main(a.data,a.design,a.out)
