"""Separate temperature from a learned ranking residual; protect source regimes.

All residual features are orthogonal to temperature under the original
posterior's plausible candidate distribution. The scalar temperature is
frozen after a source-only fit. Minimize smooth worst-domain excess MDE over
other buildings and acquisition regimes. Each test scan supplies RSS only.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import softmax,logsumexp
from .learned_match import data_stream,design_matrix,error,fit,N,parameter_map
from .transport import source_design
from ..protocol import read_floors

def orthogonal(x):
    # Tempering provides nonzero weight to alternatives to the top candidate.
    a=x[:,:,0:1].astype(float)
    p=softmax(.25*a,axis=1)
    z=a-np.sum(p*a,axis=1,keepdims=True)
    cov=np.einsum('qci,qci,qcf->qf',p,z,x[:,:,1:])
    den=(p*z*z).sum(1)[:,0]
    slopes=np.divide(cov,den[:,None],out=np.zeros_like(cov),where=den[:,None]>1e-9)
    result=x.copy()
    result[:,:,1:]-=(z*slopes[:,None,:]).astype('f')
    return result


def robust_fit(rows,alpha,kind,robust):
    from collections import defaultdict
    groups=defaultdict(list)
    for label,ep in rows:
        groups[label[0],label[2]].append((label,ep))
    active=parameter_map(kind)[:,1:]
    samples=[]
    temp=np.zeros(N); temp[0]=alpha
    for cases in groups.values():
        ix=pd.DataFrame([k for k,_ in cases],columns=['b','f','reg','dev','d','K'])
        w=np.ones(len(ix)); g=[]
        for col in ('f','dev','d','K'):
            w/=ix.groupby(g)[col].transform('nunique').values if g else ix[col].nunique()
            g.append(col)
        base=sum(m*error(ep,temp) for m,(_,ep) in zip(w,cases))
        samples.append((w,cases,base))
    def fun(v):
        a=temp+active@v
        risks=[];grads=[]
        for w,cases,base in samples:
            val=-base;gr=np.zeros(N)
            for mass,(_,ep) in zip(w,cases):
                loss,diff=error(ep,a,True)
                val+=mass*loss; gr+=mass*diff
            risks.append(val);grads.append(gr)
        risques=np.array(risks)
        if robust:
            p=softmax(risques/.15)
            obj=.15*(logsumexp(risques/.15)-np.log(len(risques)))
        else:
            p=np.ones(len(risques))/len(risques);obj=risques.mean()
        adj=active@v
        return obj+.15*adj@adj,active.T@(p@np.stack(grads)+.3*adj)
    r=minimize(fun,np.zeros(active.shape[1]),jac=True,method='L-BFGS-B',bounds=[(-1.,1.)]*active.shape[1],options=dict(maxiter=55,ftol=2e-8))
    return (temp+active@r.x).tolist(),dict(success=bool(r.success),iterations=r.nit,loss=r.fun)


def predict(target_map, q, coefficients):
    # Small batches bound memory on external buildings with many APs.
    values=[]
    for start in range(0,len(q),32):
        x=orthogonal(design_matrix(target_map.prototypes,q[start:start+32,target_map.visible]))
        values.append(softmax(x@coefficients,axis=1)@(target_map.xy-target_map.xy[0])+target_map.xy[0])
    return np.vstack(values)


def main(data,design,out):
    out.mkdir(exist_ok=True,parents=True)
    tr=read_floors(data,'trainingData.csv');va=read_floors(data,'validationData.csv')
    phones=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=[dict(building=b,floor=f) for b,f in tr]
    rows=list(data_stream(tr,va,phones,jobs,True,True))+list(data_stream(tr,va,phones,source_design(tr,phones),False,True))
    for i,(k,(x,xy,truth,w)) in enumerate(rows):
        rows[i]=k,(orthogonal(x),xy,truth,w)
    cfg={};status={}
    for b in (0,1,2,'external'):
        sub=[r for r in rows if r[0][0]!=b]
        temp,ts=fit(sub,'temperature',.1)
        cp={'identity':[1.]+[0.]*(N-1),'temperature':temp};st={}
        for name,kind,robust in [('detection','detection',True),('risk_average','full',False),('risk_robust','full',True)]:
            cp[name],st[name]=robust_fit(sub,temp[0],kind,robust)
        a=np.array(cp['risk_robust']);c=a[1:].reshape(4,5).copy();c[1:]=c[1:][::-1]
        cp['swap_strength']=np.r_[a[0],c.ravel()].tolist()
        cfg[str(b)]=cp;status[str(b)]=st
    fp=out/'fit.json';fp.write_text(json.dumps(dict(configs=cfg,diagnostics=status),indent=2)+'\n')
    cfg=json.loads(fp.read_text())['configs']
    del rows
    for name,period,js in [('official',True,jobs),('phone',False,json.loads(design.read_text())['events'])]:
        rec=[]
        for key,(x,xy,t,w) in data_stream(tr,va,phones,js,period,False):
            b,f,_,_,d,k=key
            ep=(orthogonal(x),xy,t,w)
            for method,params in cfg[str(b)].items():
                rec.append((b,f,d,k,method,error(ep,np.array(params))))
        pd.DataFrame(rec,columns=['building','floor','draw','K','method','mde']).to_csv(out/(name+'.csv'),index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('data','design','out'):p.add_argument(k,type=Path)
    a=p.parse_args();main(a.data,a.design,a.out)
