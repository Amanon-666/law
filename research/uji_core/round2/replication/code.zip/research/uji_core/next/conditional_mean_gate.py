"""Target-blind fit of one conditional detected-RSS correction after a local diagnosis.

All prototypes, nondetection scores, geometry and support updates are fixed.
A bounded coefficient interpolates only the detected-RSS mean of H candidates
using the actual H records' conditional first moment. No empirical curve of
RSS given a predicted scalar, no modification to deployment S templates.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr,softmax
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap
from residual_probe.episode_rows import nested_rows
from ..protocol import BUDGETS,SEEDS,HASHES,read_floors,position_weights,split_rows
from ..smooth_scale import local_rows
from .transport import source_design
from .b1_detected_mean import moments
from .ap_reliability import Episode,objective
from .score_shape_audit import uncertainty

CUTS=(.2,.8)
FIXED={**{f'fixed{v}':[v]*3 for v in (0.,.25,.5,.75,1.)},'fixed_rising':[0.,.5,1.],'fixed_falling':[1.,.5,0.]}
PENALTY=.1
N_PERM=3


def score_design(prototypes,rss,nh,hdiff,band):
    # Adding g*u to the expected detected RSS gives an exact quadratic in g.
    # Compute in a shifted (unchanged-distance) frame to avoid cancellation.
    v=prototypes+75.;d=(rss!=100).astype(float);r=np.where(rss!=100,rss.astype(float)+75.,0.)
    base=(r@v.T-.5*d@(v*v).T)/144.+(1.-d)@log_ndtr((-85.-prototypes)/12.).T
    x=np.zeros((*base.shape,7));x[:,:,0]=base
    u=np.clip(prototypes[:nh]+hdiff,-110.,0.)-prototypes[:nh]
    for j in range(3):
        w=np.where(band==j,u,0.)
        x[:,:nh,1+j]=(r@w.T-d@(v[:nh]*w).T)/144.
        x[:,:nh,4+j]=-.5*d@(w*w).T/144.
    return x-x.mean(1,keepdims=True)


def coefficients(g):
    a=np.asarray(g,float);return np.r_[1.,a,a*a]


def permutations(hdiff,p,hseen,hs):
    """Controls keep the complete (p, uplift) pair. Never permute target S."""
    count=np.mean([(h['rss']!=100).mean(0) for h in hs],axis=0)
    ids=np.flatnonzero(hseen);sorted_aps=ids[np.argsort(count[ids],kind='stable')]
    for j in range(N_PERM):
        rng=np.random.default_rng(260110+j)
        columns=np.arange(len(hseen))
        for group in np.array_split(sorted_aps,4):columns[group]=rng.permutation(group)
        yield ('AP',j),hdiff[:,columns],p[:,columns]
        rows=rng.permutation(len(p));yield ('XY',j),hdiff[rows],p[rows]


def iter_events(train,valid,phones,jobs,period,source,need_shuffles):
    for job in jobs:
        b,f=job['building'],job['floor'];dev=job.get('phone',-1);target=train[b,f]
        hs=[];gaps=[]
        for (bb,ff),h in sorted(train.items()):
            if bb!=b or ff==f:continue
            if not period:h={k:v[phones[h['ids']]!=dev] for k,v in h.items()}
            if len(h['rss']):hs.append(h);gaps.append(abs(ff-f))
        prior,hxy,p,cond=moments(hs,gaps);hdiff=cond-prior
        hseen=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs]);controls={}
        if need_shuffles:controls={name:(dv,np.searchsorted(CUTS,pp,side='right')) for name,dv,pp in permutations(hdiff,p,hseen,hs)}
        bands=np.searchsorted(CUTS,p,side='right')
        if period:
            q=valid[b,f]
            if source:orders=[nested_rows(target['xy'],range(len(target['xy'])),BUDGETS,0,f'early-late-src/{b}/{f}/{d}')['support_rows'][20] for d in range(3)]
            else:orders=[split_rows(target,b,f,d)[0] for d in SEEDS]
        else:
            qr=local_rows(target,np.asarray(job['query_ids']));q={k:v[qr] for k,v in target.items()}
            orders=local_rows(target,np.asarray(job['support_orders'][:3] if source else job['support_orders']))
        weights=position_weights(q['xy'])
        for draw,ordered in enumerate(orders):
            for k in BUDGETS:
                sr=ordered[:k];mask=hseen|(target['rss'][sr]!=100).any(0);rss=q['rss'][:,mask]
                s={'rss':target['rss'][sr][:,mask],'xy':target['xy'][sr]}
                m,xy=tpm.calibrate((prior[:,mask],hxy),s,(40.,1.));z=score_design(m,rss,len(hxy),hdiff[:,mask],bands[:,mask])
                e=Episode(z,xy-xy[0],q['xy']-xy[0],weights)
                actual=(FingerprintMap(m,xy,mask),q,bands[:,mask],hdiff[:,mask])
                key=(b,'period' if period else 'device',f,dev,draw,k)
                yield key,e,actual,controls


def masses(rows):
    columns=['building','regime','floor','phone','draw','K'];f=pd.DataFrame([s for s,_ in rows],columns=columns);w=np.ones(len(f));groups=[]
    for c in columns:
        w/=f.groupby(groups)[c].transform('nunique').values if groups else f[c].nunique();groups.append(c)
    np.testing.assert_allclose(w.sum(),1.,atol=1e-12);return [(v,ep) for v,(_,ep) in zip(w,rows)]


def fit_cell(rows,held):
    selected=[(key,e) for key,e in rows if held=='external' or key[0]!=held];ww=masses(selected)
    def target(x,scalar,center):
        g=np.repeat(x,3) if scalar else x;coef=coefficients(g);cost=0.;grad=np.zeros(7)
        for w,ep in ww:
            l,d=objective(coef,ep,True);cost+=w*l;grad+=w*d
        derivative=grad[1:4]+2*g*grad[4:7]
        if scalar:return cost,np.array([derivative.sum()])
        return cost+PENALTY*np.sum((g-center)**2),derivative+2*PENALTY*(g-center)
    # Deterministic starts at 0,.5,1 for the single scalar; for the three-band
    # model the scalar solution is an admissible identical start.
    def optimize(scalar,center):
        starts=(0.,.5,1.) if scalar else (float(center),)
        fits=[]
        for start in starts:
            size=1 if scalar else 3
            r=minimize(lambda v:target(v,scalar,center),np.full(size,start),jac=True,method='L-BFGS-B',bounds=[(0.,1.)]*size,
                       options=dict(maxiter=80,ftol=1e-10,gtol=1e-6))
            if not r.success or not np.isfinite(r.fun):raise RuntimeError(f'Unfinished fit: {r.message}')
            fits.append(r)
        best=min(fits,key=lambda r:r.fun)
        return best.x,dict(objective=float(best.fun),iterations=int(best.nit),success=bool(best.success))
    scalar,ass=optimize(True,0.);g,abs_=optimize(False,scalar.item())
    fc={label:sum(w*objective(coefficients(v),ep) for w,ep in ww) for label,v in FIXED.items()};best=min(FIXED,key=fc.get)
    out=dict(n=len(selected),source_buildings=sorted({key[0] for key,_ in selected}),values=dict(scalar=np.repeat(scalar,3).tolist(),gate=g.tolist(),source_fixed=FIXED[best]),
             fits=dict(scalar=ass,gate=abs_),selected_fixed=best,fixed_source_risk=fc)
    print('fit',held,out['values'],flush=True);return str(held),out


def frozen_predict(model,rss,gate,hdiff,bands):
    """Portable score for a fitted H/S map + aligned historical moments.

    hdiff and bands refer only to H rows, in the map.visible column order.
    The appended support prototypes are excluded from the correction.
    """
    g=np.asarray(gate,float);m=model.prototypes;nh=len(hdiff)
    if g.shape!=(3,) or not np.isfinite(g).all() or (g<0).any() or (g>1).any():raise ValueError('Expected 3 convex coefficients')
    if bands.shape!=hdiff.shape or hdiff.shape[1]!=m.shape[1] or nh>len(m):raise ValueError('Incorrect H side information')
    correction=np.clip(m[:nh]+hdiff,-110.,0.)-m[:nh]
    mu=m.copy();mu[:nh]+=g[bands]*correction
    q=np.asarray(rss)[:,model.visible];d=(q!=100).astype(float);r=np.where(q!=100,q.astype(float)+75,0.);v=mu+75.
    logits=(r@v.T-.5*d@(v*v).T)/144.+(1-d)@log_ndtr((-85.-m)/12.).T
    return softmax(logits,axis=1)@(model.xy-model.xy[0])+model.xy[0]


def run(a):
    a.out.mkdir(exist_ok=True,parents=True);train=read_floors(a.data,'trainingData.csv');valid=read_floors(a.data,'validationData.csv')
    phones=pd.read_csv(a.data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy();periods=[dict(building=b,floor=f) for b,f in train]
    if a.stage in ('train','both'):
        rows=[]
        for jobs,period in [(periods,True),(source_design(train,phones),False)]:
            rows.extend((s,e) for s,e,_,_ in iter_events(train,valid,phones,jobs,period,True,False))
        with ThreadPoolExecutor(max_workers=a.workers) as pool:fits=dict(pool.map(lambda b:fit_cell(rows,b),[0,1,2,'external']))
        rec=dict(folds=fits,bins=CUTS,penalty=PENALTY,sha256=HASHES,fixed=FIXED,shuffle_seeds=[260110+j for j in range(N_PERM)],
            scope='Hypothesis developed on the known B1F2 three-position repeat failure, UJI development only; no external query used. Each target building excluded from both period and device source supervision. All-UJI rule frozen for potential external decision before held results.',
            design='Fixed gap2 H map, fixed S residual, original nondetection and raw S templates. Detected-RSS means of H interpolate between m and clip(m+H conditional-minus-filled shift). Shared coefficients on p<.2, .2<=p<.8, p>=.8; scalar first fitted by direct MDE, three-bin fit penalizes deviations from scalar, 0.1 sum of squared deviations. H conditional moments use actual H at each AP/location. Balanced source building/regime/floor/device/draw/K; three source draws and all budgets.',
            shuffle='Three independent controls for H XY rows and H AP columns (within H-prevalence quartiles), moving (p, H-detected correction) together. Average scored losses, not predicted coordinates.')
        (a.out/'fit.json').write_text(json.dumps(rec,indent=2,allow_nan=False)+'\n');del rows
    if a.stage=='train':return
    fits=json.loads((a.out/'fit.json').read_text())['folds'];jobs=json.loads((a.old/'device_stress_design.json').read_text())['events'];allcmp=[];checks=[]
    for stage,source,period in [('official',periods,True),('phone',jobs,False)]:
        result=[];merr=0.
        for key,ep,actual,controls in iter_events(train,valid,phones,source,period,False,True):
            b,_,f,dev,d,k=key;model,q,bands,delta=actual;params={**FIXED,**fits[str(b)]['values']}
            vals={n:float(objective(coefficients(g),ep)) for n,g in params.items()};mask=model.visible;rss=q['rss'][:,mask]
            gt=np.asarray(params['gate']);nh=len(delta);sd={}
            for (kind,j),(sv,sp) in controls.items():
                mu=model.prototypes.copy();u=np.clip(mu[:nh]+sv[:,mask],-110.,0.)-mu[:nh]
                mu[:nh]+=gt[sp[:,mask]]*u
                seen=(rss!=100).astype(float);r=np.where(rss!=100,rss.astype(float)+75.,0.);v=mu+75.
                lg=(r@v.T-.5*seen@(v*v).T)/144.+(1.-seen)@log_ndtr((-85.-model.prototypes)/12.).T
                mde=float(ep.qw@np.linalg.norm(softmax(lg,axis=1)@ep.xy-ep.truth,axis=1));vals[f'shuffle_{kind}{j}']=mde;sd.setdefault(kind,[]).append(mde)
            vals.update({f'shuffle_{kind}':np.mean(loss) for kind,loss in sd.items()})
            if d==0 and k in (1,20):
                for n in ('gate','fixed0.0','fixed1.0'):
                    pred=frozen_predict(model,q['rss'],params[n],delta,bands);err=float(ep.qw@np.linalg.norm(pred-q['xy'],axis=1));merr=max(merr,abs(err-vals[n]))
            result.append(dict(building=b,floor=f,draw=d,K=k,**vals))
        df=pd.DataFrame(result).set_index(['building','floor','draw','K']).sort_index();ref=pd.read_csv(a.paired/f'paired_map_{stage}.csv').set_index(df.index.names).sort_index()
        if len(df)!=650 or not df.index.equals(ref.index):raise ValueError('Unpaired rows')
        par=float(abs(df['fixed0.0']-ref.field_tobit).max());assert max(par,merr)<1e-8
        df=df.join(ref[['old_wknn_gap_fit','field_wknn']]);df.to_csv(a.out/f'{stage}.csv');fl=df.groupby(['building','floor','K']).mean();bu=fl.groupby(['building','K']).mean()
        fl.to_csv(a.out/f'{stage}_floor.csv');bu.to_csv(a.out/f'{stage}_building.csv');bu.groupby('K').mean().to_csv(a.out/f'{stage}_K.csv')
        winner=bu.mean()[list(FIXED)].idxmin()
        for v in dict.fromkeys(['fixed0.0','fixed0.5','fixed1.0','source_fixed',winner,'scalar','shuffle_AP','shuffle_XY','old_wknn_gap_fit','field_wknn']):
            delta0=bu.gate-bu[v];fd=fl.gate-fl[v];ci=uncertainty(df,'gate',v)
            allcmp.append(dict(stage=stage,ref=v,mde=bu.gate.mean(),ref_MDE=bu[v].mean(),delta=delta0.mean(),cond_lo=ci[0],cond_hi=ci[1],building_K_wins=(delta0< -1e-8).sum(),floor_K_wins=(fd< -1e-8).sum(),draw_K_wins=((df.gate-df[v])< -1e-8).sum(),meanK_decreases=(bu.gate.groupby('building').diff()<0).sum(),best_measured_fixed=winner))
        checks.append(dict(stage=stage,all_parent_max_abs=par,api_check_max_abs=merr));print(stage,'means',bu.mean().round(4).to_dict(),flush=True)
    pd.DataFrame(allcmp).to_csv(a.out/'tiers.csv',index=False);pd.DataFrame(checks).to_csv(a.out/'parity.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['train','test','both'])
    for name in ('data','old','paired','out'):p.add_argument(name,type=Path)
    p.add_argument('--workers',type=int,default=3);run(p.parse_args())
