"""Support-template x position-prior factorial on the unchanged H update.

Original raw S plus one vote per candidate is the exact old method. At a
measured XY already in H, the field template copies the *updated exact H row*.
At new XY it evaluates the same residual fit over the three-neighbour prior.
Equal-XY assigns equal total prior mass to each distinct coordinate while
retaining the mixture of different RSS templates available there.
"""
import argparse
import json
from pathlib import Path
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from external_baselines import tpm_adapter as tpm
from refi import smooth_history
from . import longitudinal as lib
from .match_episodes import eval_tasks, source_tasks
from ..protocol import BUDGETS, read_floors, position_weights, HASHES

WEIGHTS=(0.,.25,.5,.75,1.)


def history(hs,scale=1.):
    h=[dict(rss=v['rss'],xy=v['xy']/scale) for v in hs if len(v['rss'])]
    if not h: raise ValueError('Need historical positions')
    m,xy=smooth_history(tpm.history_map(h,None,None),10.,.5)
    mask=np.logical_or.reduce([(v['rss']!=100).any(0) for v in h])
    return m,xy,mask


@dataclass
class AnchorMeasure:
    historical: np.ndarray
    raw: np.ndarray
    posterior: np.ndarray
    xy: np.ndarray
    visible: np.ndarray
    multiplicity: np.ndarray
    n_collision: int
    exact_lookup_rms: float

    def probabilities(self,q,mixture):
        if not 0.<=mixture<=1.: raise ValueError('Mixture must lie in [0,1]')
        anchor=self.raw+mixture*(self.posterior-self.raw)
        if mixture==1.:
            # Preserve bit-identical templates for co-located posterior rows.
            anchor=self.posterior
        return tpm.tobit_weights(q[:,self.visible],np.vstack([self.historical,anchor]),12.,-85.)

    def read(self,p,unique):
        if unique:
            p=p/self.multiplicity
            p=p/p.sum(1,keepdims=True)
        return p@(self.xy-self.xy[0])+self.xy[0]

    def predict(self,q,mixture,unique):
        return self.read(self.probabilities(q,mixture),unique)


def build(prior,s,scale=1.):
    full,hxy,hmask=prior
    mask=hmask|(s['rss']!=100).any(0);m=full[:,mask]
    if not len(s['rss']):
        return AnchorMeasure(m,m[:0],m[:0],hxy*scale,mask,np.ones(len(hxy)),0,np.nan)
    sy,sxy=tpm.position_map(tpm.dbm(s['rss'][:,mask]),s['xy']/scale)
    # Keep r, kernel and ridge exactly the same for all four cells.
    local=tpm.lookup(sxy,hxy,m)
    rss_residual=sy-local
    def kernel(a,b):return np.exp(-cdist(a,b,'sqeuclidean')/(2*40.**2))
    ss=kernel(sxy,sxy)
    coef=np.linalg.solve(ss+np.eye(len(ss)),rss_residual)
    h=np.clip(m+kernel(hxy,sxy)@coef,-110.,0.)
    post=np.clip(local+ss@coef,-110.,0.)
    xy=np.vstack([hxy,sxy]);_,ix,counts=np.unique(xy,axis=0,return_inverse=True,return_counts=True)
    index={tuple(point):i for i,point in enumerate(hxy)}
    pair=[(i,index[tuple(point)]) for i,point in enumerate(sxy) if tuple(point) in index]
    rms=np.nan
    if pair:
        j,hj=np.array(pair).T
        rms=float(np.sqrt(np.mean((local[j]-m[hj])**2)))
        post[j]=h[hj]
    return AnchorMeasure(h,sy,post,xy*scale,mask,counts[ix.ravel()],len(pair),rms)


def event(model,q,methods):
    cache={};rows=[];w=position_weights(q['xy'])
    for name,(mix,unique) in methods.items():
        if mix not in cache:cache[mix]=model.probabilities(q['rss'],mix)
        pred=model.read(cache[mix],unique)
        err=float(w@np.linalg.norm(pred-q['xy'],axis=1))
        if not np.isfinite(err):raise ValueError('Nonfinite scores')
        rows.append(dict(method=name,mixture=mix,unique=bool(unique),mde=err,
                         n_collision=model.n_collision,n_h=len(model.historical),lookup_rms=model.exact_lookup_rms))
    return rows


def source_grid():
    return {f'{g}_{int(u)}':(g,u) for u in (False,True) for g in WEIGHTS}


def named_models(fit):
    models={}
    for unique,key in [(False,'multi'),(True,'unique')]:
        for label,v in [('raw',0.),('half',.5),('post',1.),('fitted',fit[key])]:
            models[f'{label}_{key}']=(v,unique)
    return models


def uji(args,mode,choices=None):
    train=read_floors(args.uji,'trainingData.csv')
    device=pd.read_csv(args.uji/'trainingData.csv',usecols=['PHONEID','TIMESTAMP'])
    if mode=='source':
        tasks=lambda b,f:source_tasks(train,device.PHONEID.to_numpy(),device.TIMESTAMP.to_numpy(),b,f)
    else:
        design=json.loads((args.frozen/('manifest.json' if mode=='official' else 'device_stress_design.json')).read_text())
        validation=read_floors(args.uji,'validationData.csv') if mode=='official' else None
        tasks=lambda b,f:eval_tasks(train,validation,device.PHONEID.to_numpy(),design,b,f,mode)
    rows=[]
    for (b,f),t in train.items():
        methods=source_grid() if mode=='source' else named_models(choices[str(b)])
        for phone,hs,draws in tasks(b,f):
            prior=history(hs)
            for d,sr,q in draws:
                for k in BUDGETS:
                    s=dict(rss=t['rss'][sr[:k]],xy=t['xy'][sr[:k]])
                    model=build(prior,s)
                    rows.extend(dict(stage=mode,building=b,floor=f,phone=phone,draw=d,K=k,**row) for row in event(model,q,methods))
    return pd.DataFrame(rows)


def freeze(args):
    src=uji(args,'source')
    means=src.groupby(['building','floor','phone','K','method','mixture','unique'],as_index=False).mde.mean()
    means.to_csv(args.out/'anchor_source.csv',index=False)
    b=means.groupby(['building','floor','phone','mixture','unique']).mde.mean().groupby(['building','floor','mixture','unique']).mean().groupby(['building','mixture','unique']).mean()
    fits={}
    for held in [*sorted(train for train in src.building.unique()),'all']:
        risk=(b if held=='all' else b.drop(index=held,level='building')).groupby(['mixture','unique']).mean()
        fits[str(held)]={k:min(WEIGHTS,key=lambda x:risk.loc[x,u]) for k,u in [('multi',False),('unique',True)]}
    params=dict(choices=fits,grid=WEIGHTS,source='UJI training only; future device Q, earlier different-phone H/S, whole held building excluded. Equal buildings/floors/phones/draws/K. all applies to library and external.',
                sha256=HASHES,scope='Post-hoc UJI/library follow-up. No library score selects mixture or defaults.',
                update='Every arm reuses the old 3-NN prior lookup for support residuals, even at H coordinates. The posterior readout copies the already updated actual H row at exact H-S XY ties. At new XY it uses that same 3-NN prior plus its kernel update.',
                prior='One vote per candidate vs one total vote per distinct XY; within an XY, alternate RSS templates share uniform probability.')
    (args.out/'anchor_frozen.json').write_text(json.dumps(params,indent=2,allow_nan=False)+'\n')


def run(args):
    args.out.mkdir(parents=True,exist_ok=True)
    if args.stage=='train':
        freeze(args);return
    fits=json.loads((args.out/'anchor_frozen.json').read_text())['choices']
    for mode in ('official','phone'):
        uji(args,mode,fits).to_csv(args.out/f'anchor_{mode}.csv',index=False)
    methods=named_models(fits['all'])
    for stage in ('validation','late','late_A5'):
        rows=[];last=None
        for m,h,s,q in lib.episodes(args.archive,stage):
            key=m['month'],m['floor']
            if key!=last:prior=history([h],.766);last=key
            model=build(prior,s,.766)
            rows.extend(dict(stage=stage,month=m['month'],floor=m['floor'],draw=m['draw'],K=m['K'],**row) for row in event(model,q,methods))
        pd.DataFrame(rows).to_csv(args.out/f'anchor_{stage}.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['train','test'])
    for name in ('uji','archive','frozen','out'):p.add_argument(name,type=Path)
    run(p.parse_args())
