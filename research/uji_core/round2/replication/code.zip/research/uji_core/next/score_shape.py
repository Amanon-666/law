"""Source-learned monotone asymmetric RSS comparison, with the original map fixed."""
import numpy as np
from scipy.special import log_ndtr, softmax

SIGMA = 12.
THRESHOLD = -85.
NAMES = ('observed_stronger_core','observed_stronger_tail','observed_weaker_core','observed_weaker_tail','missing')


def features(prototypes, query):
    """Log-score components [query, candidate, 5]. Unit coefficients recover Tobit."""
    m=np.asarray(prototypes,dtype=float)
    q=np.asarray(query,dtype=float)
    seen=q!=100
    result=np.empty((len(q),len(m),len(NAMES)),dtype=float)
    for i,(rss,active) in enumerate(zip(q,seen)):
        residual=(rss[active]-m[:,active])/SIGMA
        for start,part in ((0,np.maximum(residual,0.)),(2,np.maximum(-residual,0.))):
            tail=(np.maximum(part-1.,0.)**2).sum(axis=1)
            result[i,:,start]=-.5*((part**2).sum(axis=1)-tail)
            result[i,:,start+1]=-.5*tail
    result[:,:,4]=(~seen).astype(float) @ log_ndtr((THRESHOLD-m)/SIGMA).T
    return result


def predict(target_map,query_rss,coefficients):
    """Predict XY using a refi.FingerprintMap and five frozen positive weights."""
    q=np.asarray(query_rss,dtype=float)
    a=np.asarray(coefficients,dtype=float)
    if (q.ndim!=2 or q.shape[1]!=len(target_map.visible) or not np.isfinite(q).all()
            or a.shape!=(5,) or not np.isfinite(a).all() or (a<0).any()):
        raise ValueError('Expected aligned finite RSS and five nonnegative coefficients')
    out=np.empty((len(q),2),dtype=float)
    xy=target_map.xy
    for i in range(0,len(q),64):
        logits=features(target_map.prototypes,q[i:i+64,target_map.visible]) @ a
        out[i:i+64]=softmax(logits,axis=1)@(xy-xy[0])+xy[0]
    return out
