"""Paired comparisons and support-draw uncertainty on the two fixed query populations."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from .ap_reliability import Episode,objective
from .score_shape import features
from ..summarize import INDEX,intervals


def uncertainty(d,method,ref):
    rng=np.random.default_rng(543928)
    boots=[]
    center=[]
    for b,building in d.groupby(level='building'):
        fb,fc=[],[]
        for f,floor in building.groupby(level='floor'):
            contrast=(floor[method]-floor[ref]).groupby('draw').mean().to_numpy()
            fc.append(contrast.mean())
            fb.append(contrast[rng.integers(len(contrast),size=(5000,len(contrast)))].mean(axis=1))
        boots.append(np.mean(fb,axis=0));center.append(np.mean(fc))
    ci=np.quantile(np.mean(boots,axis=0),[.025,.975])
    return ci.tolist()


def check():
    m=np.array([[-84.,-80.,-105.],[-67.,-91.,-70.],[-76.,-63.,-99.]])
    q=np.array([[-65.,-72.,100.],[-82.,100.,-91.]])
    x=features(m,q)
    ep=Episode(x,np.array([[0.,0.],[3.,5.],[4.,-2.]]),np.array([[1.,1.],[-1.,2.]]),np.array([.5,.5]))
    a=np.array([.5,1.2,.7,1.,.6])
    value,grad=objective(a,ep,True)
    eps=1e-5
    numerical=np.array([(objective(a+i,ep)-objective(a-i,ep))/(2.*eps) for i in np.eye(5)*eps])
    np.testing.assert_allclose(grad,numerical,rtol=1e-5,atol=2e-9)
    return float(np.max(abs(grad-numerical)))


def main(frozen,out,floor_reference=None):
    rows=[];info=dict(gradient_max_abs_err=check())
    comparisons=[('asymmetric',r) for r in ('default','temperature','rss_miss','symmetric','sign_only','sign_swapped',
                                              'huber','half_tail','positive_half_tail','fixed_weak_core','fixed_cool','remove_direction','period_asymmetric','device_asymmetric','strong_wknn')]
    comparisons += [('symmetric',r) for r in ('default','temperature','half_tail')]
    if floor_reference is not None:
        comparisons.append(('asymmetric','floor_aware_wknn'))
    for mode in ('official','phone'):
        d=pd.read_csv(out/(mode+'.csv')).set_index(INDEX).sort_index()
        if mode=='official':
            r=pd.read_csv(frozen/'wknn_events.csv').query("method=='joint_tuned'")
        else:
            r=pd.read_csv(frozen/'device_stress_events.csv').query("method=='strong_wknn'").rename(columns={'seed':'draw'})
        d['strong_wknn']=r.set_index(INDEX).mde
        if floor_reference is not None:
            wk=pd.read_csv(floor_reference/('floor_wknn_'+mode+'.csv')).query("method=='gap_fit'")
            d['floor_aware_wknn']=wk.set_index(INDEX).mde
        f=d.groupby(['building','floor','K']).mean();b=f.groupby(['building','K']).mean()
        for method,ref in comparisons:
            paired=d[[method,ref]].rename(columns={method:'core'})
            simultaneous=intervals(paired,ref,'d')
            lo,hi=uncertainty(d,method,ref)
            row=dict(mode=mode,method=method,reference=ref,mde=b[method].mean(),ref_mde=b[ref].mean(),
                     delta=(b[method]-b[ref]).mean(),macro_lower95=lo,macro_upper95=hi,
                     building_K_simultaneous_upper_below_zero=sum(z[4]<0. for z in simultaneous))
            for name,tab,groups in [('building',b,['building']),('floor',f,['building','floor']),('draw',d,['building','floor','draw'])]:
                delta=tab[method]-tab[ref]
                adj=tab[method].groupby(groups).diff().dropna()
                row[name+'_K_wins']=int((delta< -1e-8).sum())
                row[name+'_K_ties']=int((abs(delta)<=1e-8).sum())
                row[name+'_K_count']=len(delta)
                row[name+'_K_improve']=int((adj< -1e-8).sum())
                row[name+'_adj_count']=len(adj)
            rows.append(row)
    pd.DataFrame(rows).to_csv(out/'tiers.csv',index=False)
    info['interval_scope']='Conditional on the three buildings, observed floors/Q and all fitted parameters. Equal building/floor weighting, resample whole support draws within floor across K. Macro: two-sided percentile; per-building/K family uses existing one-sided simultaneous procedure; no multiple-family correction.'
    (out/'checks.json').write_text(json.dumps(info,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('frozen',type=Path);p.add_argument('out',type=Path)
    p.add_argument('--floor-reference',type=Path)
    args=p.parse_args()
    main(args.frozen,args.out,args.floor_reference)
