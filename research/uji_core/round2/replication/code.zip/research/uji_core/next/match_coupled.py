"""Follow-up for a receive-gain shift that affects both RSS and AP detection.

In contrast to the reporting-offset control, this finite latent state moves
each candidate's RSS mean BEFORE censoring. The same device has one gain on
the entire scan. The discrete integral is exact for the stated prior.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import log_ndtr, logsumexp

from ..protocol import read_floors
from .match import DEFAULT, decode, risk, terms
from .match_episodes import eval_tasks, maps, source_tasks

GAINS = np.arange(-18., 19., 3.)
SCALES = (0.,3.,6.,12.)


def conditional_scores(q, m, common=DEFAULT):
    sigma,theta,_,discount,_ = common
    t=terms(q,m)
    seen=1.-t['missed']
    residual=(np.where(seen,np.asarray(q,dtype=float)+75.,0.).sum(1,keepdims=True)
              -seen@(m+75.).T)
    scores=[]
    for b in GAINS:
        detected=-(t['residual2']-2*b*residual+b*b*t['n'])/(2*sigma**2)
        missing=t['missed']@log_ndtr((theta-m-b)/sigma).T
        scores.append(detected+discount*missing)
    return np.stack(scores)


def marginal(scores, scale):
    if scale == 0:
        return scores[len(GAINS)//2]
    log_prior=-.5*(GAINS/scale)**2
    log_prior-=logsumexp(log_prior)
    return logsumexp(scores+log_prior[:,None,None],axis=0)


def losses(e, common, scales=SCALES):
    scores=conditional_scores(e['query'],e['prototypes'],common)
    origin=e['xy'][0]
    args=e['xy']-origin,e['truth']-origin,e['weight']
    return np.asarray([risk(marginal(scores,s)/common[4],*args) for s in scales])


def main(data,frozen,out):
    train=read_floors(data,'trainingData.csv')
    meta=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID','TIMESTAMP'])
    phone,time=meta.PHONEID.to_numpy(),meta.TIMESTAMP.to_numpy()
    original=json.loads((out/'selection.json').read_text())['selections']
    bases={b:{'default':DEFAULT,'global':tuple(decode(arms['global_fit']))} for b,arms in original.items()}
    distinct=set(x for arms in bases.values() for x in arms.values())
    records=[]
    for b,f in train:
        tasks=source_tasks(train,phone,time,b,f)
        for e in maps(train,b,f,tasks):
            for common in distinct:
                for sd,err in zip(SCALES,losses(e,common)):
                    records.append((b,f,e['phone'],common,sd,err))
    tab=pd.DataFrame(records,columns=['building','floor','phone','base','scale','mde'])
    byg=tab.groupby(['building','floor','phone','base','scale']).mde.mean().groupby(
        ['building','floor','base','scale']).mean().groupby(['building','base','scale']).mean()
    choice,allrisk={},{}
    for held,arms in bases.items():
        source=byg.drop(index=int(held),level='building').groupby(['base','scale']).mean()
        choice[held]={}
        allrisk[held]={}
        for n,common in arms.items():
            risks=[source.at[(common,s)] for s in SCALES]
            choice[held][n]=SCALES[int(np.argmin(risks))]
            allrisk[held][n]=list(map(float,risks))
    selection=dict(folds=choice,source_risks=allrisk,rss_states=GAINS.tolist(),scale_candidates=SCALES,
        prior='Symmetric truncated discrete prior proportional to exp(-b*b/(2*s*s)). Scale zero is the original readout.',
        source='Same strict source episodes as match.py. Train just one scale, separately for default and training-selected global matcher. Two-stage on the latter. No official or held phone outcomes select scale.',
        scope='Mechanism follow-up after inspecting reporting-only candidate. Shared receive gain shifts both observed RSS mean and nondetection threshold. No stacking across experimental laws.')
    cfg=out/'coupled_selection.json'
    cfg.write_text(json.dumps(selection,indent=2,allow_nan=False)+'\n')
    choice=json.loads(cfg.read_text())['folds']
    official=read_floors(data,'validationData.csv')
    for mode,filename in [('official','manifest.json'),('device','device_stress_design.json')]:
        manifest=json.loads((frozen/filename).read_text())
        rows=[]
        for b,f in train:
            jobs=eval_tasks(train,official,phone,manifest,b,f,mode)
            for e in maps(train,b,f,jobs):
                row={k:e[k] for k in ('building','floor','draw','K','phone')}
                for name,common in bases[str(b)].items():
                    v=losses(e,common)
                    row[name+'_zero']=v[0]
                    row[name+'_fixed6']=v[SCALES.index(6.)]
                    row[name+'_source']=v[SCALES.index(choice[str(b)][name])]
                rows.append(row)
        result=pd.DataFrame(rows)
        keys=['building','floor','draw','K']
        zero=pd.read_csv(out/(mode+'_events.csv')).set_index(keys).sort_index()
        actual=result.set_index(keys).sort_index()
        np.testing.assert_allclose(actual[['default_zero','global_zero']],zero[['default','global_fit']],rtol=0.,atol=1e-9)
        if len(result)!=650 or not np.isfinite(actual.iloc[:,1:].to_numpy()).all():
            raise ValueError('Missing or nonfinite result')
        result.to_csv(out/('coupled_'+mode+'.csv'),index=False)
        print(mode,actual.drop(columns='phone').groupby(['building','K']).mean().groupby('building').mean(),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('data','frozen','out'):p.add_argument(n,type=Path)
    a=p.parse_args()
    main(a.data,a.frozen,a.out)
