"""Learn a cross-AP Wiener correction from registered historical floors.

Within-position repeat deviations estimate nuisance covariance. Predicting
each historical floor using the other H floors gives a second moment for
repeatable between-floor change. Their competition filters each *one-scan*
support innovation before the existing spatial update. No target labels enter
estimation of these two matrices.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.linalg import solve
from scipy.spatial.distance import cdist
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, smooth_history
from .transport import source_design
from ..protocol import BUDGETS, SEEDS, read_floors, position_weights, split_rows
from ..smooth_scale import local_rows

LAM=(0., .25, 1., 4.)
SHAPE=(0., .5, 1.)
GRID=[(l,s) for l in LAM for s in (SHAPE if l else (0.,))]


class ChangeBank:
    def __init__(self,hist,unit=1.):
        self.unit=unit
        self.seen=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hist])
        self.m,self.xy=smooth_history(tpm.history_map(hist,None,None),10.*unit,.5)
        self.cov,self.noise=[],[]
        self.operators={}
        for j,h in enumerate(hist):
            rss=tpm.dbm(h['rss'][:,self.seen])
            xy,idx,counts=np.unique(h['xy'],axis=0,return_inverse=True,return_counts=True)
            idx=idx.ravel()
            proto,_=tpm.position_map(rss,h['xy'])
            others=[dict(rss=z['rss'][:,self.seen],xy=z['xy']) for i,z in enumerate(hist) if i!=j]
            if others:
                prior,coords=smooth_history(tpm.history_map(others,None,None),10.*unit,.5)
                err=proto-tpm.lookup(xy,coords,prior)
                self.cov.append(err.T@err/len(err))
            repeats=counts>1
            if repeats.any():
                w=np.sqrt(1/(np.maximum(counts[idx]-1,1)*repeats.sum()))
                centered=(rss-proto[idx])*w[:,None]
                self.noise.append(centered.T @ centered)
        self.cov=np.mean(self.cov,axis=0) if self.cov else None
        # When a site provides only pre-averaged prototypes, repeated-scan
        # variance is unidentified. Use a fixed diagonal 6 dB fallback.
        self.noise=np.mean(self.noise,axis=0) if self.noise else np.eye(self.seen.sum())*36.

    def operator(self,lam,shape):
        key=lam,shape
        if key not in self.operators:
            n=self.seen.sum()
            if not lam or self.cov is None:
                self.operators[key]=np.eye(n)
            else:
                c=shape*self.cov+(1-shape)*np.diag(np.diag(self.cov))
                v=shape*self.noise+(1-shape)*np.diag(np.diag(self.noise))
                # Added positive diagonals in dB^2 keep the same prior scale
                # for rare APs and ensure the computation has full rank.
                c=c+4.*np.eye(n)
                v=v+4.*np.eye(n)
                self.operators[key]=solve(c+lam*v,c,assume_a='pos')
        return self.operators[key]

    def predict_maps(self,srss,sxy,arms):
        mask=self.seen | (srss!=100).any(0)
        sy,sx=tpm.position_map(tpm.dbm(srss[:,mask]),sxy)
        m=self.m[:,mask]
        e=sy-tpm.lookup(sx,self.xy,m)
        cross=np.exp(-cdist(self.xy,sx,'sqeuclidean')/(2*(40*self.unit)**2))
        ss=np.exp(-cdist(sx,sx,'sqeuclidean')/(2*(40*self.unit)**2))
        proj=np.linalg.solve(ss+np.eye(len(sx)),cross.T).T
        known=self.seen[mask]
        for name,params in arms.items():
            lam,shape=params
            pe=e.copy()
            if name=='scalar':
                if self.cov is not None:
                    g=(np.trace(self.cov)+4*sum(known))/(np.trace(self.cov)+4*sum(known)+lam*(np.trace(self.noise)+4*sum(known)))
                    pe[:,known]*=g
            elif lam:
                a=self.operator(lam,shape)
                if name=='shuffled':
                    # Preserve every diagonal gain, scramble which AP pairs
                    # exchange off-diagonal evidence, using an H-only order.
                    rng=np.random.default_rng(2317)
                    order=np.argsort(self.m[:,self.seen].mean(0),kind='stable')
                    ix=np.arange(len(order))
                    for g in np.array_split(order,5): ix[g]=rng.permutation(g)
                    diag=a.diagonal().copy()
                    a=a[np.ix_(ix,ix)].copy()
                    np.fill_diagonal(a,diag)
                pe[:,known]=e[:,known] @ a
            yield name,FingerprintMap(np.vstack((np.clip(m+proj@pe,-110,0),sy)),np.vstack((self.xy,sx)),mask)


def measure(train,phones,jobs,arms=None,valid=None,limit=None):
    rows=[]
    for j in jobs:
        b,f=j['building'],j['floor']
        t=train[b,f]
        hist=[h for (hb,hf),h in train.items() if hb==b and hf!=f]
        if valid is not None:
            q=valid[b,f]
            orders=[split_rows(t,b,f,s)[0] for s in SEEDS]
        else:
            hist=[{k:v[phones[h['ids']]!=j['phone']] for k,v in h.items()} for h in hist]
            hist=[h for h in hist if len(h['rss'])]
            iq=local_rows(t,np.asarray(j['query_ids']))
            q={k:v[iq] for k,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))
        bank=ChangeBank(hist)
        qw=position_weights(q['xy'])
        models=arms[str(b)] if arms else {str(p):p for p in GRID}
        for draw,sr in enumerate(orders[:limit]):
            for k in BUDGETS:
                for name,m in bank.predict_maps(t['rss'][sr[:k]],t['xy'][sr[:k]],models):
                    err=qw @ np.linalg.norm(m.predict(q['rss'])-q['xy'],axis=1)
                    rows.append((b,f,draw,k,name,*models[name],err))
    return pd.DataFrame(rows,columns=['building','floor','draw','K','method','lambda','shape','mde'])


def main(data,design,out):
    out.mkdir(parents=True,exist_ok=True)
    tr=read_floors(data,'trainingData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    src=measure(tr,phone,source_design(tr,phone),limit=3)
    keys=['lambda','shape']
    risk=src.groupby(['building','floor',*keys]).mde.mean().groupby(['building',*keys]).mean()
    risk.to_csv(out/'source.csv')
    cfg={}
    for b in (0,1,2,'external'):
        r=(risk if b=='external' else risk.drop(b,level='building')).groupby(keys).mean()
        best=min(GRID,key=lambda k:r.loc[k])
        diag=min([k for k in GRID if k[1]==0],key=lambda k:r.loc[k])
        cfg[str(b)]=dict(identity=(0,0),empirical=(1.,.5),diagonal=diag,source_fit=best,
                         shuffled=best,scalar=best)
    file=out/'fit.json';file.write_text(json.dumps(cfg,indent=2)+'\n')
    arms=json.loads(file.read_text())
    va=read_floors(data,'validationData.csv')
    measure(tr,phone,[dict(building=b,floor=f) for b,f in tr],arms,va).to_csv(out/'official.csv',index=False)
    measure(tr,phone,json.loads(design.read_text())['events'],arms).to_csv(out/'phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('data','design','out'): p.add_argument(key,type=Path)
    a=p.parse_args();main(a.data,a.design,a.out)
