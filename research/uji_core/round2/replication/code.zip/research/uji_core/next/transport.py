"""Can source cross-device tasks teach how much of a common anchor shift to spread?

A direct post-support MDE fit. Two scalar gains act on a robust common shift
and the remaining innovation. The components add up to the observed residual.
No inference input contains a query phone ID or target label. Global IDs in
manifests are 0-based raw training CSV data rows.
"""
import argparse
import hashlib
import json
from itertools import product
from pathlib import Path
import random

import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist

from external_baselines import tpm_adapter as tpm
from refi import smooth_history
from ..forward import FIXED_RADIUS, MATCH, RIDGE
from ..protocol import BUDGETS, SEEDS, HASHES, read_floors, position_weights, history_floors, split_rows
from ..smooth_scale import local_rows
from residual_probe.episode_rows import nested_rows

A = (.5, 1., 1.5, 2.)
B = (0., .5, 1., 1.5, 2.)
GRID = tuple(product(A,B))
FIXED = {'identity':(1.,1.), 'remove':(1.,0.), 'half_common':(1.,.5),
         **{f'tied{g}':(g,g) for g in A}, 'boost_remainder':(1.5,1.)}


def source_design(train, phone):
    """Two eligible query devices per floor, geometry-only selection and split.

    Unlike the stress test, both device groups and support/query draws are
    enrolled anew for training. Exclude the given phone from all H and S.
    """
    jobs=[]
    for (b,f),t in train.items():
        devs=phone[t['ids']]
        counts={int(d):len(np.unique(t['xy'][devs==d],axis=0)) for d in np.unique(devs)}
        enrolled=0
        for d in sorted(counts,key=lambda j:(-counts[j],j)):
            if counts[d]<12:
                continue
            by_xy={}
            for i in np.flatnonzero(devs==d):
                by_xy.setdefault(tuple(t['xy'][i]),[]).append(i)
            key=f'transport-source-v1/{b}/{f}/{d}'
            rng=random.Random(key)
            qpoints=rng.sample(sorted(by_xy),12)
            q=[rng.choice(by_xy[xy]) for xy in qpoints]
            qset=set(qpoints)
            eligible=[i for i,x in enumerate(t['xy']) if devs[i]!=d and tuple(x) not in qset]
            if len(np.unique(t['xy'][eligible],axis=0))<max(BUDGETS):
                continue
            orders=[nested_rows(t['xy'],eligible,BUDGETS,0,key+f'/S/{seed}')['support_rows'][max(BUDGETS)]
                    for seed in SEEDS]
            jobs.append(dict(building=b,floor=f,phone=d,query_ids=t['ids'][q].tolist(),
                             support_orders=[t['ids'][s].tolist() for s in orders]))
            enrolled+=1
            if enrolled==2:
                break
    return jobs


def history_basis(histories):
    raw,xy=tpm.history_map(histories,None,None)
    m,_=smooth_history((raw,xy),10.,.5)
    # Same per-floor, per-position aggregation as the historical field. The
    # conditional detected RSS is derived from E[filled RSS] and Pr(detected).
    hist_mask=[]
    for h in histories:
        values,loc=tpm.position_map((h['rss']!=100).astype(float),h['xy'])
        hist_mask.append((values,loc))
    p,pxy=tpm.position_map(np.vstack([v for v,_ in hist_mask]),np.vstack([loc for _,loc in hist_mask]))
    if not np.array_equal(xy,pxy):
        raise ValueError('Mismatched historical coordinate aggregation')
    p,_=smooth_history((p,xy),10.,.5)
    return m,xy,p,np.logical_or.reduce([(h['rss']!=100).any(0) for h in histories])


def common_shift(rss, expected, frequency):
    seen=rss!=100
    # expected = p*E[detected RSS]+(1-p)*(-110) under this very same smoothing.
    mu=np.divide(expected+110.,frequency,out=np.zeros_like(expected),where=frequency>1e-9)-110.
    # Order statistics avoid dependence on how missing AP columns are ordered.
    weights=np.where(seen & (frequency>1e-9),frequency,0.)
    offsets=rss-mu
    order=np.argsort(offsets,axis=1,kind='stable')
    w=np.take_along_axis(weights,order,axis=1)
    total=w.sum(1)
    idx=(np.cumsum(w,axis=1)<total[:,None]/2.).sum(1).clip(max=w.shape[1]-1)
    median=np.take_along_axis(offsets,order,axis=1)[np.arange(len(rss)),idx]
    # Three overlapping historical detections give half reliability.
    u=total/(total+3.)*median
    return seen*u[:,None], u, total


def transport_bases(m,xy,p,rss,sxy):
    # R=1, sort identically to the original anchor aggregation.
    sxy, inverse = np.unique(sxy,axis=0,return_inverse=True)
    if len(sxy)!=len(rss):
        raise ValueError('R=1 distinct support XY required by these episodes')
    rss=rss[np.argsort(inverse.ravel())]
    sy=tpm.dbm(rss)
    expected=tpm.lookup(sxy,xy,m)
    cm,u,overlap=common_shift(rss,expected,tpm.lookup(sxy,xy,p))
    residual=sy-expected
    cross=np.exp(-cdist(xy,sxy,'sqeuclidean')/(2.*FIXED_RADIUS**2))
    ss=np.exp(-cdist(sxy,sxy,'sqeuclidean')/(2.*FIXED_RADIUS**2))
    proj=np.linalg.solve(ss+RIDGE*np.eye(len(sxy)),cross.T).T
    return sy,sxy,proj@residual,proj@cm,u,overlap


def measure(train,phone,jobs,*,model=None,official=None):
    records=[]
    for j in jobs:
        b,f=j['building'],j['floor']
        t=train[b,f]
        hs=history_floors(train,b,f)
        if official is None:
            d=j['phone']
            hs=[{key:arr[phone[h['ids']]!=d] for key,arr in h.items()} for h in hs]
            hs=[h for h in hs if len(h['ids'])]
            qr=local_rows(t,np.asarray(j['query_ids']))
            q={key:v[qr] for key,v in t.items()}
            orders=local_rows(t,np.asarray(j['support_orders']))
            if (phone[t['ids'][orders]]==d).any() or not (phone[q['ids']]==d).all():
                raise ValueError('Invalid phone partition')
        else:
            d=-1
            q=official[b,f]
            orders=[split_rows(t,b,f,seed)[0] for seed in SEEDS]
        qw=position_weights(q['xy'])
        full,hxy,prob,visible=history_basis(hs)
        methods={str(pair):pair for pair in GRID} if model is None else model[str(b)]
        for seed,srows in zip(SEEDS,orders):
            for k in BUDGETS:
                sr=srows[:k]
                mask=visible | (t['rss'][sr]!=100).any(0)
                m=full[:,mask]
                sy,sxy,delta,cm,u,overlap=transport_bases(m,hxy,prob[:,mask],t['rss'][sr][:,mask],t['xy'][sr])
                xy=np.vstack([hxy,sxy])-hxy[0]
                qrss=q['rss'][:,mask]
                cache={}
                for method,(a,beta) in methods.items():
                    if (a,beta) not in cache:
                        field=np.clip(m+a*delta+(beta-a)*cm,-110.,0.)
                        w=tpm.tobit_weights(qrss,np.vstack([field,sy]),*MATCH)
                        err=np.linalg.norm(w@xy+hxy[0]-q['xy'],axis=1)
                        if not np.isfinite(err).all():
                            raise ValueError('Nonfinite location error')
                        cache[a,beta]=float(qw@err)
                    records.append((b,f,d,seed,k,method,a,beta,float(np.abs(u).mean()),float(overlap.mean()),cache[a,beta]))
        print(f'B{b}F{f} phone={d} complete',flush=True)
    return pd.DataFrame(records,columns=['building','floor','phone','draw','K','method','remainder_gain','common_gain',
                                         'mean_abs_common','mean_overlap','mde'])


def main(data,output,phone_path):
    output.mkdir(exist_ok=True,parents=True)
    train=read_floors(data,'trainingData.csv')
    phone=pd.read_csv(data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    jobs=source_design(train,phone)
    (output/'transport_source_design.json').write_text(json.dumps(jobs)+'\n')
    src=measure(train,phone,jobs)
    src.groupby(['building','floor','phone','K','remainder_gain','common_gain'],as_index=False).mde.mean().to_csv(output/'transport_source.csv',index=False)
    pairs=['remainder_gain','common_gain']
    risk=src.groupby(['building','floor','phone',*pairs]).mde.mean().groupby(['building','floor',*pairs]).mean().groupby(['building',*pairs]).mean()
    selected={}
    for held in sorted({b for b,_ in train}):
        r=risk.drop(index=held,level='building').groupby(pairs).mean()
        # Prefer the unmodified rule in the event of a numerical tie.
        fit=lambda opts:min(opts,key=lambda p:(r.loc[p],abs(p[0]-1)+abs(p[1]-1)))
        selected[held]={**FIXED,'source_tied':fit([(g,g) for g in A]),'source_common':fit([(1.,g) for g in B]),'source_both':fit(GRID)}
    file=output/'transport_selection.json'
    file.write_text(json.dumps(dict(choices=selected,grid=GRID,source_objective='Cross-device post-support MDE, Q and H/S device disjoint, equal buildings/floors/devices/draws/K; whole evaluation building held out.',
                                    source_design_sha256=hashlib.sha256((output/'transport_source_design.json').read_bytes()).hexdigest(),
                                    phone_design_sha256=hashlib.sha256(phone_path.read_bytes()).hexdigest(),csv_sha256=HASHES),indent=2)+'\n')
    chosen=json.loads(file.read_text())['choices']
    official=read_floors(data,'validationData.csv')
    measure(train,phone,[dict(building=b,floor=f) for b,f in train],model=chosen,official=official).to_csv(output/'transport_official.csv',index=False)
    frozen=json.loads(phone_path.read_text())
    if frozen['train_sha256']!=HASHES['trainingData.csv']:
        raise ValueError('Wrong phone manifest')
    measure(train,phone,[j for j in frozen['events'] if not j.get('unavailable')],model=chosen).to_csv(output/'transport_phone.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('data','output','phone_manifest'):
        p.add_argument(key,type=Path)
    args=p.parse_args()
    main(args.data,args.output,args.phone_manifest)
