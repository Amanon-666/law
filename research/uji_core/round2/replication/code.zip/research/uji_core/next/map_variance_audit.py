"""Check finite mixture moments and supplied candidate comparisons."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import fit_map,smooth_history
from ..summarize import INDEX,intervals
from .map_variance import VarianceBank,QueryTerms,variance
from .score_shape_audit import uncertainty


def check():
    # Two histories, two coordinates, unequal numbers of repeats at a source.
    h=[dict(rss=np.array([[-50,100],[-62,-75],[-75,100]]),xy=np.array([[0,0],[0,0],[10,0]])),
       dict(rss=np.array([[-70,-55],[-68,-60],[-65,100]]),xy=np.array([[0,0],[10,0],[10,0]]))]
    bank=VarianceBank(h)
    # Enumerate every raw scan of the finite mixture directly.
    kernel,_=smooth_history((np.eye(2),bank.xy),10.,.5)
    expected_mean=[];expected_var=[];within=[]
    for smoothing in kernel:
        m0=np.zeros(2);m2=np.zeros(2);w=np.zeros(2)
        for floor in h:
            for i,point in enumerate(bank.xy):
                y=tpm.dbm(floor['rss'][(floor['xy']==point).all(1)])
                p=.5*smoothing[i]
                m0+=p*y.mean(0);m2+=p*(y*y).mean(0);w+=p*np.var(y,axis=0)
        expected_mean.append(m0);expected_var.append(m2-m0*m0);within.append(w)
    np.testing.assert_allclose(bank.mean,expected_mean,atol=2e-11,rtol=0.)
    np.testing.assert_allclose(bank.within,within,atol=2e-11,rtol=0.)
    np.testing.assert_allclose(bank.within+bank.between,expected_var,atol=2e-11,rtol=0.)
    s=dict(rss=np.array([[-65,100]]),xy=np.array([[5,0]]))
    q=np.array([[-70,100],[-58,-63],[100,100]])
    f=bank.condition(s);base=fit_map(h,s)
    gap=float(np.abs(f.predict(q,(12.,0.,0.))-base.predict(q)).max())
    if gap>1e-10:raise AssertionError('Constant variance neutral reduction')
    np.testing.assert_allclose(f.within[-1],tpm.lookup(s['xy'],bank.xy,bank.within)[0])
    for coeff in [(6.,1.,1.),(9.,.25,1.)]:
        w,b=f.statistics('local');v=variance(w,b,coeff)
        # Independent brute-force Gaussian and censor likelihood over APs.
        from scipy.special import log_ndtr
        m=f.prototypes
        explicit=[]
        for y in q:
            seen=y!=100
            explicit.append((-.5*((y[seen]-m[:,seen])**2/v[:,seen]+np.log(v[:,seen]))).sum(1)
                    +log_ndtr((-85.-m[:,~seen])/np.sqrt(v[:,~seen])).sum(1))
        np.testing.assert_allclose(QueryTerms(q).scores(m,v),explicit,rtol=0.,atol=1e-10)
        w1,b1=f.statistics('shuffled')
        np.testing.assert_array_equal(np.sort(variance(w1,b1,coeff),axis=0),np.sort(v,axis=0))
    return dict(direct_finite_mixture_moments=True,per_AP_normalized_loglik=True,
                unchanged_histogram=True,constant12_coordinate_gap=gap)


def main(frozen,out,floor_reference):
    rows=[];checks=check()
    for mode in ('official','phone'):
        d=pd.read_csv(out/(mode+'.csv')).set_index(INDEX).sort_index()
        if floor_reference:
            wk=pd.read_csv(floor_reference/('floor_wknn_'+mode+'.csv')).query("method=='gap_fit'")
            d['floor_aware_wknn']=wk.set_index(INDEX).mde
        b=d.groupby(['building','K']).mean();f=d.groupby(['building','floor','K']).mean()
        controls=['default','constant','physical','moderate','AP_mean_fit','AP_mean_same','shuffle_same','tied','repeat_fit','between_fit',
                  'without_repeat','without_between','period_fit','device_fit']
        if floor_reference:controls.append('floor_aware_wknn')
        for ref in controls:
            sub=d[['full',ref]].rename(columns={'full':'core'})
            point=intervals(sub,ref,'d');lo,hi=uncertainty(d,'full',ref)
            r=dict(mode=mode,method='full',reference=ref,mde=b.full.mean(),ref_mde=b[ref].mean(),
                delta=(b.full-b[ref]).mean(),macro_lower95=lo,macro_upper95=hi,
                simultaneous_building_K_upper_below_zero=sum(p[4]<0 for p in point))
            for name,frame,by in [('building',b,['building']),('floor',f,['building','floor']),('draw',d,['building','floor','draw'])]:
                diff=frame.full-frame[ref]
                adj=frame.full.groupby(by).diff().dropna()
                r[name+'_K_wins']=int((diff< -1e-8).sum());r[name+'_K_ties']=int((np.abs(diff)<=1e-8).sum())
                r[name+'_K_count']=len(diff);r[name+'_K_improve']=int((adj< -1e-8).sum());r[name+'_adj_count']=len(adj)
            rows.append(r)
    pd.DataFrame(rows).to_csv(out/'tiers.csv',index=False)
    checks['interval_scope']='Support draw randomness conditional on observed sites, held queries and the fixed source-fitted coefficients.'
    (out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('frozen',type=Path);p.add_argument('out',type=Path)
    p.add_argument('--floor-reference',type=Path)
    a=p.parse_args();main(a.frozen,a.out,a.floor_reference)
