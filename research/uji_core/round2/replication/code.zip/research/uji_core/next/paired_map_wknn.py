"""Matched readouts of exactly the same gap-aware ReFi map on UJI.

Both source regimes, nested draws and k grid reproduce external_period_wknn.
The source labels of the held building never tune its k. Each H prototype
uses the minimum original row at its XY to break exact ties, each S prototype
the minimum original S row at its XY. No model selection on final results.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, fit_map, historical_prior
from residual_probe.episode_rows import nested_rows
from ..protocol import BUDGETS, SEEDS, read_floors, split_rows, position_weights, HASHES
from ..study import NEIGHBORS
from ..inverse import squared, order, vote
from ..smooth_scale import local_rows
from .transport import source_design


def group_ids(xy,ids):
    u,g=np.unique(xy,axis=0,return_inverse=True)
    minima=np.full(len(u),np.iinfo(np.int64).max,dtype=np.int64)
    np.minimum.at(minima,g.ravel(),ids)
    return u,minima


def measure(train,valid,phones,jobs,mode,choices=None):
    rows=[];checks=[]
    source=choices is None
    for job in jobs:
        b,f=job['building'],job['floor'];dev=job.get('phone',-1);t=train[b,f]
        hs=[];gaps=[]
        for (bb,ff),h in sorted(train.items()):
            if bb!=b or ff==f:continue
            if mode=='device':h={key:values[phones[h['ids']]!=dev] for key,values in h.items()}
            if len(h['ids']):hs.append(h);gaps.append(abs(ff-f))
        if mode=='device':
            qr=local_rows(t,np.asarray(job['query_ids']));q={key:values[qr] for key,values in t.items()}
            orders=local_rows(t,np.asarray(job['support_orders']))
            if not (phones[q['ids']]==dev).all() or (phones[t['ids'][orders]]==dev).any():raise ValueError('Phone split violation')
        else:
            q=valid[b,f]
            if source:orders=[nested_rows(t['xy'],range(len(t['rss'])),BUDGETS,0,f'early-late-src/{b}/{f}/{d}')['support_rows'][max(BUDGETS)] for d in range(3)]
            else:orders=[split_rows(t,b,f,d)[0] for d in SEEDS]
        # AP columns are independent in this historical transform, so it is
        # algebraically identical to applying the current mask before pooling.
        full,hh=historical_prior(hs,10.,.5,gaps)
        hseen=np.logical_or.reduce([(h['rss']!=100).any(0) for h in hs])
        hxy,hids=group_ids(np.vstack([h['xy'] for h in hs]),np.concatenate([h['ids'] for h in hs]))
        if not np.array_equal(hxy,hh):raise ValueError('Historical coordinate order mismatch')
        qw=position_weights(q['xy'])
        for draw,sr in enumerate(orders):
            for k in BUDGETS:
                sel=sr[:k];s={key:values[sel] for key,values in t.items()}
                mask=hseen|(s['rss']!=100).any(0)
                proto,xy=tpm.calibrate((full[:,mask],hh),dict(rss=s['rss'][:,mask],xy=s['xy']),(40.,1.))
                sxy,sids=group_ids(s['xy'],s['ids'])
                if not np.array_equal(xy[len(hh):],sxy):raise ValueError('S coordinate order mismatch')
                qrss=tpm.dbm(q['rss'][:,mask]);dist=squared(qrss+110.,proto+110.)
                ids=np.concatenate([hids,sids]);ix=order(dist,ids,max(NEIGHBORS));ds=np.take_along_axis(dist,ix,axis=1)
                centered=xy[ix]-xy[0]
                losses={}
                for n in NEIGHBORS:
                    yp=vote(ds[:,:n],centered[:,:n],int(mask.sum()))[0]+xy[0]
                    losses[n]=float(qw@np.linalg.norm(yp-q['xy'],axis=1))
                if source:
                    rows.extend(dict(building=b,floor=f,phone=dev,draw=draw,K=k,k=n,mde=v) for n,v in losses.items())
                else:
                    bank=FingerprintMap(proto,xy,mask);yp=bank.predict(q['rss'])
                    if draw==0 and k in (1,max(BUDGETS)):
                        ref=fit_map(hs,s,floor_gaps=gaps);direct=ref.predict(q['rss'])
                        if not np.array_equal(mask,ref.visible) or not np.array_equal(xy,ref.xy):raise AssertionError('Public map mismatch')
                        pdiff=float(np.max(np.abs(proto-ref.prototypes)));ydiff=float(np.max(np.abs(yp-direct)))
                        if pdiff>1e-10 or ydiff>1e-8:raise AssertionError('Public predictions differ')
                        checks.append(dict(building=b,floor=f,phone=dev,draw=draw,K=k,prototype_max_difference=pdiff,xy_prediction_max_difference=ydiff))
                    fitted=choices[str(b)]
                    rows.append(dict(building=b,floor=f,phone=dev,draw=draw,K=k,n_queries=len(q['ids']),
                                     n_query_positions=len(np.unique(q['xy'],axis=0)),candidates=len(xy),fitted_k=fitted,
                                     field_tobit=float(qw@np.linalg.norm(yp-q['xy'],axis=1)),field_wknn=losses[fitted],
                                     **{f'field_wknn_k{n}':v for n,v in losses.items()}))
    return pd.DataFrame(rows),checks


def main(args):
    p=args.out;p.mkdir(parents=True,exist_ok=True);train=read_floors(args.data,'trainingData.csv');valid=read_floors(args.data,'validationData.csv')
    phones=pd.read_csv(args.data/'trainingData.csv',usecols=['PHONEID']).PHONEID.to_numpy()
    periods=[dict(building=b,floor=f) for b,f in train]
    ds=source_design(train,phones)
    for x in ds:x['support_orders']=x['support_orders'][:3]
    tables=[]
    for regime,jobs in [('period',periods),('device',ds)]:
        table,_=measure(train,valid,phones,jobs,regime)
        tables.append(table.assign(regime=regime))
    risk=pd.concat(tables).groupby(['regime','building','floor','phone','k']).mde.mean()
    risk.to_csv(p/'paired_map_source.csv')
    bybuilding=risk.groupby(['regime','building','floor','k']).mean().groupby(['regime','building','k']).mean()
    choices={}
    for held in [0,1,2,'external']:
        available=bybuilding if held=='external' else bybuilding.drop(held,level='building')
        mean=available.groupby(['regime','k']).mean().groupby('k').mean()
        choices[str(held)]=int(min(NEIGHBORS,key=lambda n:(mean.loc[n],n)))
    cfg=p/'paired_map_parameters.json'
    cfg.write_text(json.dumps(dict(choices=choices,k_grid=NEIGHBORS,sha256=HASHES,
        map='Public refi.fit_map(H,S,floor_gaps=abs(floors-target)); history exponential gap coefficient 2, half10, residual40, ridge1.',
        source='Reuses the exact jobs, early-late draws, phones and aggregation of external_period_wknn.py; selected k uses labels from other two buildings only. External fit for documentation only.',
        readout='RMS on H+S AP catalogue, 100 to -110 dBm, inverse-distance vote. Exact-distance ties broken by earliest original CSV row represented by a historical or support prototype.'),indent=2)+'\n')
    choices=json.loads(cfg.read_text())['choices'];summary={};allchecks=[]
    stress=json.loads((args.old/'device_stress_design.json').read_text())['events']
    for stage,regime,jobs in [('official','period',periods),('phone','device',[j for j in stress if not j.get('unavailable')])]:
        data,checks=measure(train,valid,phones,jobs,regime,choices);allchecks.extend(dict(stage=stage,**row) for row in checks)
        keys=['building','floor','draw','K']
        old=pd.read_csv(args.old/f'smooth_scale_{stage}.csv').query('method=="half10"').set_index(keys).mde
        direct=pd.read_csv(args.rivals/f'period_wknn_{stage}.csv').pivot(index=keys,columns='method',values='mde').add_prefix('old_wknn_')
        merged=data.set_index(keys).join(old.rename('old_refi_nogap'),validate='one_to_one').join(direct,validate='one_to_one')
        if len(merged)!=650 or merged.isna().any().any():raise AssertionError('Unpaired evaluation')
        merged.to_csv(p/f'paired_map_{stage}.csv')
        names=['field_tobit','field_wknn','field_wknn_k3','old_refi_nogap','old_wknn_gap_fit','old_wknn_no_gap_refit']
        floor=merged[names].groupby(['building','floor','K']).mean();b=floor.groupby(['building','K']).mean()
        floor.to_csv(p/f'paired_map_{stage}_floor.csv');b.to_csv(p/f'paired_map_{stage}_building.csv')
        diff=floor.field_wknn-floor.field_tobit
        summary[stage]=dict(events=len(merged),macro=b.mean().to_dict(),curves=b.groupby('K').mean().to_dict(),
            same_map_WKNN_minus_Tobit_paired_floor_K_median=diff.median(),same_map_WKNN_beats_Tobit_floor_K=int((diff<0).sum()),
            same_map_WKNN_minus_Tobit_paired_event_median=(merged.field_wknn-merged.field_tobit).median())
    pd.DataFrame(allchecks).to_csv(p/'paired_map_public_parity.csv',index=False)
    (p/'paired_map_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('data','old','rivals','out'):ap.add_argument(name,type=Path)
    main(ap.parse_args())
