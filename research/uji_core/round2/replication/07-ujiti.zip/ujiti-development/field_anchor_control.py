"""One UJITI development counterfactual. Replace only the K appended RSS rows."""
import argparse, gzip, json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import historical_prior
from research.uji_core.next.anchor_measure import build
from research.uji_core.protocol import position_weights
from replay import ALLOW, R1, R2, KS, UNIT, digest, canonical, axishash, extract


def evaluate(archive, design, out):
    p=json.loads((design/'protocol.json').read_text())
    assert digest((design/'protocol.json').read_bytes())=='b7b5483b7c401ecb9ee5061c64021bbf3fb3f293c0f8ac25ffe414295c6c2e1d'
    assert digest(archive.read_bytes())==p['input_archive_sha256']
    frozen=(design/'route_manifest.json').read_bytes()
    blob=(design/'scan_metadata.json.gz').read_bytes();plain=gzip.decompress(blob)
    assert digest(frozen)==p['manifest_sha256'] and digest(blob)==p['scan_metadata_sha256'] and digest(plain)==p['scan_metadata_plain_sha256']
    meta={r['id']:r for r in json.loads(plain) if r['file'] in (R1,R2)}
    permitted={s['member']:s for s in p['allowed_members'] if s['member'] in ALLOW}
    with ZipFile(archive) as z:
        rss={}
        for name in sorted(ALLOW):rss.update(extract(z,name,permitted[name],meta))
    baseline=pd.read_csv(out/'factorial_events.csv').set_index(['floor','draw','K'])
    records=[]
    for e in [v for v in json.loads(frozen) if v['site']=='UJITI']:
        f=e['floor'];qids=e['ordered_Q_ids']
        by_floor={int(n):ids for n,ids in e['H_by_floor'].items()}
        hids=sum(by_floor.values(),[])
        included=hids+e['eligible_target_S_ids']+qids
        xy={rid:((meta[rid]['lon']-e['lon0'])*e['east_m_per_degree'],(meta[rid]['lat']-e['lat0'])*111320.) for rid in included}
        assert digest(canonical([(rid,xy[rid][0].hex(),xy[rid][1].hex()) for rid in sorted(xy)]))==e['coordinate_frame_sha256']
        hseen=set().union(*(rss[i] for i in hids))
        for draw in e['draws']:
            d=draw['draw']
            for k in KS:
                sr=draw['ordered_S_scan_ids'][:k]
                ap=sorted(hseen.union(*(rss[i] for i in sr)))
                assert axishash(ap)==draw['permitted_AP_axis'][str(k)]['sha256']
                col={a:j for j,a in enumerate(ap)}
                def pack(ids):
                    arr=np.full((len(ids),len(col)),100.,float)
                    for i,rid in enumerate(ids):
                        for a,v in rss[rid].items():
                            if a in col:arr[i,col[a]]=v
                    return dict(rss=arr,xy=np.array([xy[i] for i in ids])/UNIT)
                hs=[pack(by_floor[n]) for n in sorted(by_floor)]
                s=pack(sr);q=pack(qids);weights=position_weights(q['xy'])
                h,x=historical_prior(hs,10.,.5,[abs(n-f) for n in sorted(by_floor)])
                field=build((h,x,np.array([a in hseen for a in ap])),s)
                # Score both counterfactuals with identical H rows from the actual
                # public propagation implementation, regardless of BLAS roundoff.
                full,locations=tpm.calibrate((h,x),s,(40.,1.));nh=len(x)
                assert np.array_equal(locations,field.xy) and np.array_equal(full[nh:],field.raw)
                hdiff=np.max(np.abs(full[:nh]-field.historical))
                if hdiff>1e-9 or not field.visible.all():raise ValueError('Historical update mismatch')
                def mde(prototypes,candidates):
                    prob=tpm.tobit_weights(q['rss'],prototypes,12.,-85.)
                    pred=prob@(candidates-candidates[0])+candidates[0]
                    return float(weights@np.linalg.norm(pred-q['xy'],axis=1)*UNIT)
                control=mde(np.vstack((full[:nh],field.posterior)),locations)
                original=baseline.loc[(f,d,k)]
                np.testing.assert_allclose([mde(full,locations),mde(full[:nh],x)],
                                           [original.C_parent,original.D_correct_H],rtol=0.,atol=1e-9)
                difference=field.raw-field.posterior
                records.append(dict(floor=f,draw=d,K=k,D=original.D_correct_H,Cfield=control,C=original.C_parent,
                                    field_candidates_minus_D=control-original.D_correct_H,
                                    raw_template_minus_field=original.C_parent-control,
                                    H_row_max_difference=hdiff,S_template_rms_dBm=np.sqrt(np.mean(difference**2)),
                                    S_template_max_abs_dBm=np.max(np.abs(difference)),H_S_XY_coincidences=field.n_collision))
    data=pd.DataFrame(records)
    if len(data)!=600: raise ValueError('Incomplete replay')
    data.to_csv(out/'field_anchor_events.csv',index=False)
    return data


def summarize(data,out):
    cols=['D','Cfield','C','field_candidates_minus_D','raw_template_minus_field']
    curves=[];changes=[];store=[];draws=[];rng=np.random.default_rng(261101)
    def add(label,est,boot):
        for i,k in enumerate(KS): curves.append(dict(floor=label,K=k,**dict(zip(cols,est[i]))))
        delta=est[4]-est[2]
        for i,col in enumerate(cols):
            q=np.quantile(boot[:,4,i]-boot[:,2,i],[.025,.975])
            changes.append(dict(floor=label,measure=col,K20_minus_K5=delta[i],lo95=q[0],hi95=q[1]))
    for f,floor in data.groupby('floor'):
        v=floor.sort_values(['draw','K'])[cols].to_numpy().reshape(40,5,len(cols))
        boot=v[rng.integers(40,size=(10000,40))].mean(1)
        store.append(v.mean(0));draws.append(boot);add(f,v.mean(0),boot)
    add('all',np.mean(store,axis=0),np.mean(draws,axis=0))
    pd.DataFrame(curves).to_csv(out/'field_anchor_curves.csv',index=False)
    pd.DataFrame(changes).to_csv(out/'field_anchor_5_to_20.csv',index=False)
    diagnostic=data.groupby('K').S_template_rms_dBm.agg(['min','mean','max'])
    diagnostic.to_csv(out/'field_anchor_templates.csv')
    (out/'field_anchor_receipt.json').write_text(json.dumps(dict(events=len(data),
        H_update_max_abs=float(data.H_row_max_difference.max()),no_H_S_collisions=bool((data.H_S_XY_coincidences==0).all()),
        template_rms_min=float(data.S_template_rms_dBm.min()),field_identical_to_raw_events=int((data.S_template_max_abs_dBm<1e-9).sum()),
        scope='Only UJITI R1/R2. Existing gap2 historical prior, anchor_measure.build prior lookup and fixed RBF40 ridge=1. '
        'All three arms scored on the same H union current S AP set. Cfield vs D jointly adds coordinates and their field-predicted templates. '
        'C vs Cfield holds all coordinates, multiplicities and H templates fixed. No fitting, no new default.'),indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('archive','design','out'):p.add_argument(n,type=Path)
    a=p.parse_args();summarize(evaluate(a.archive,a.design,a.out),a.out)
