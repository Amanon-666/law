"""Development-only IPIN UJITI replay: PYTHONPATH=REPO python replay.py ZIP DESIGN REPO OUT."""
import argparse
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile
import gzip
import hashlib
import json
import math
import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import fit_map
from research.uji_core.protocol import position_weights
from research.uji_core.next.external_floor_wknn import GapReference
from research.uji_core.next.paired_map_wknn import group_ids
from research.uji_core.inverse import squared,order,vote

BASE='2016_IPIN_Competition_Track03/01-Logifles/01-Training/'
R1='logfile_UJITI_R1_NEXUS5.txt'
R2='logfile_UJITI_R2_NEXUS5.txt'
ALLOW=frozenset([BASE+R1,BASE+R2])
KS=(1,3,5,10,20)
UNIT=.766


def digest(data):return hashlib.sha256(data).hexdigest()


def canonical(data):
    return (json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')


def axishash(aps):return digest(('\n'.join(sorted(aps))+'\n').encode('ascii'))


def extract(z, path, published, expected_meta):
    if path not in ALLOW:
        raise ValueError('Archive member is not an authorized UJITI route')
    # This is the only ZipFile member read in this program.
    with z.open(path) as fid:raw=fid.read()
    if digest(raw)!=published['sha256'] or f'{z.getinfo(path).CRC:08x}'!=published['zip_crc32']:
        raise ValueError('Member content mismatch')
    lines=raw.splitlines()
    header=lines[1].decode('latin-1').split(': ',1)[1].strip().replace('GMT','').replace('CEST','+02:00').replace('CET','+01:00')
    origin=datetime.strptime(header,'%a %b %d %H:%M:%S %z %Y').timestamp()
    landmarks=[];scans={};stem=Path(path).stem
    for line_no,line in enumerate(lines,1):
        if line.startswith(b'POSI;'):
            v=line.strip().rstrip(b';').split(b';')
            landmarks.append((float(v[1]),float(v[3]),float(v[4]),int(float(v[5])),int(float(v[6])),line_no))
        elif line.startswith(b'WIFI;'):
            v=line.strip().rstrip(b';').split(b';');t=float(v[1])
            identifier=v[4].decode('ascii').lower();value=float(v[-1])
            if not np.isfinite(value) or value>0:raise ValueError('Malformed RSS')
            hit=scans.setdefault(t,[f'{stem}@W{line_no}',line_no,{}]); hit[2][identifier]=value
    accepted={}
    landmarks.sort()
    for a,b in zip(landmarks[:-1],landmarks[1:]):
        if a[3:5]!=b[3:5] or not 0<b[0]-a[0]<=120:continue
        for t,(rid,line_no,rss) in scans.items():
            if not a[0]<=t<b[0]:continue
            frac=(t-a[0])/(b[0]-a[0])
            record=dict(id=rid,file=Path(path).name,first_WIFI_line=line_no,app_s=t,capture_unix_s=origin+t,
               lat=a[1]+frac*(b[1]-a[1]),lon=a[2]+frac*(b[2]-a[2]),floor=a[3],building=a[4],
               POSI_lines=[a[5],b[5]],POSI_app_s=[a[0],b[0]],interpolation=frac)
            if record!=expected_meta.get(rid) or rid in accepted:raise ValueError(f'Metadata mismatch {rid}')
            accepted[rid]=rss
    if len(accepted)!=published['accepted_WIFI_scans']:raise ValueError('Scan count mismatch')
    return accepted


def summarize(ev,out):
    rng=np.random.default_rng(261101);records=[];all_boot=[];all_curves=[]
    columns=['parent','floor_wknn','map_wknn']
    def report(label,c,b):
        for i,k in enumerate(KS):
            d=dict(floor=label,K=k,**dict(zip(columns,c[i])))
            for n,comp in enumerate(columns[1:],1):
                delta=b[:,i,0]-b[:,i,n];d['delta_'+comp]=c[i,0]-c[i,n]
                d[comp+'_lo'],d[comp+'_hi']=np.quantile(delta,[.025,.975])
            if i:
                d['adjacent']=c[i,0]-c[i-1,0]
                d['adjacent_lo'],d['adjacent_hi']=np.quantile(b[:,i,0]-b[:,i-1,0],[.025,.975])
            records.append(d)
    for f,g in ev.groupby('floor'):
        x=g.sort_values(['draw','K'])[columns].to_numpy().reshape((40,5,3))
        boot=x[rng.integers(40,size=(10000,40))].mean(1)
        c=x.mean(0);all_curves.append(c);all_boot.append(boot);report(f,c,boot)
    c=np.mean(all_curves,axis=0);boot=np.mean(all_boot,axis=0)
    report('all',c,boot)
    result={'means_m':dict(zip(columns,c.mean(0))), 'K_decreases_parent':int((np.diff(c[:,0])<0).sum()),
            'beats_direct_K':int((c[:,0]<c[:,1]).sum()), 'beats_mapped_K':int((c[:,0]<c[:,2]).sum())}
    for i,k in enumerate(columns[1:],1):
        result['parent_minus_'+k]=float(np.mean(c[:,0]-c[:,i]))
        result[k+'_diff95']=np.quantile((boot[:,:,0]-boot[:,:,i]).mean(1),[.025,.975]).tolist()
    pd.DataFrame(records).to_csv(out/'curves.csv',index=False);return result


def main(archive,design,repo,out):
    out.mkdir(exist_ok=True,parents=True)
    protocol=json.loads((design/'protocol.json').read_text())
    pins={'protocol':digest((design/'protocol.json').read_bytes()),'refi':digest((repo/'refi.py').read_bytes()),
          'direct':('prototype',.35,3),'mapped_k':7,'opened_members':sorted(ALLOW)}
    if pins['protocol']!='b7b5483b7c401ecb9ee5061c64021bbf3fb3f293c0f8ac25ffe414295c6c2e1d' or pins['refi']!='c27cf82d35aecb8fd16cad4d4f8711a94533a34cd9c700c053b22d190500e84f':raise ValueError('Pre-score pin mismatch')
    assert digest(archive.read_bytes())==protocol['input_archive_sha256']
    assert digest((design/'freeze_uji_routes.py').read_bytes())==protocol['generator_sha256']
    meta_file=(design/'scan_metadata.json.gz').read_bytes();raw=gzip.decompress(meta_file)
    assert digest(meta_file)==protocol['scan_metadata_sha256'] and digest(raw)==protocol['scan_metadata_plain_sha256']
    meta={x['id']:x for x in json.loads(raw) if x['file'] in (R1,R2)}
    manifest=(design/'route_manifest.json').read_bytes();assert digest(manifest)==protocol['manifest_sha256']
    jobs=[e for e in json.loads(manifest) if e['site']=='UJITI']
    assert len(jobs)==3 and all(e['role']=='development' and e['historical_files']==[R1] and e['next_query_file']==R2 for e in jobs)
    members={i['member']:i for i in protocol['allowed_members'] if i['member'] in ALLOW}
    with ZipFile(archive) as z:
        rss={}
        for member in sorted(ALLOW): rss.update(extract(z,member,members[member],meta))
    assert rss.keys()==meta.keys();pins['accepted_route_scans']=len(rss)
    (out/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
    evidence=[];scores=[];predictions=[]
    for e in jobs:
        f=e['floor'];hi={int(j):v for j,v in e['H_by_floor'].items()};pool=e['eligible_target_S_ids'];qi=e['ordered_Q_ids']
        all_h=sum(hi.values(),[])
        included={i for i,r in meta.items() if r['file']==R1 or r['floor']==f}
        assert set(all_h+pool+qi)==included and all(meta[i]['file']==R2 and meta[i]['floor']==f for i in qi)
        assert all(meta[i]['file']==R1 and meta[i]['floor']==f for i in pool)
        assert all(meta[i]['file']==R1 and meta[i]['floor']==hf and hf!=f for hf in hi for i in hi[hf])
        assert max(meta[i]['capture_unix_s'] for i in all_h+pool)<min(meta[i]['capture_unix_s'] for i in qi)
        key=min(all_h,key=lambda i:(meta[i]['capture_unix_s'],i))
        assert key==e['origin_from_H'] and meta[key]['lat']==e['lat0'] and meta[key]['lon']==e['lon0']
        xcoef=111320.*math.cos(math.radians(e['lat0']));assert xcoef==e['east_m_per_degree'] and e['north_m_per_degree']==111320.
        xy={i:((r['lon']-e['lon0'])*xcoef,(r['lat']-e['lat0'])*111320.) for i,r in meta.items() if i in included}
        geometry=[(i,xy[i][0].hex(),xy[i][1].hex()) for i in sorted(xy)]
        assert digest(canonical(geometry))==e['coordinate_frame_sha256']
        aps_h=set().union(*(rss[i].keys() for i in all_h));assert e['H_only_AP_axis']=={'N':len(aps_h),'sha256':axishash(aps_h)}
        for draw in e['draws']:
            s20=draw['ordered_S_scan_ids'];assert len(s20)==len({xy[i] for i in s20})==20 and set(s20)<=set(pool)
            for k in KS:
                sr=s20[:k];aps=sorted(aps_h.union(*(rss[i] for i in sr)))
                a=digest(('\n'.join(aps)+'\n').encode('ascii'));assert draw['permitted_AP_axis'][str(k)]=={'N':len(aps),'sha256':a}
                idx={v:i for i,v in enumerate(aps)}
                def pack(ids):
                    arr=np.full((len(ids),len(aps)),100.,float)
                    for row,rid in enumerate(ids):
                        for name,value in rss[rid].items():
                            col=idx.get(name)
                            if col is not None:arr[row,col]=value
                    return dict(xy=np.asarray([xy[i] for i in ids])/UNIT,rss=arr,
                                ids=np.asarray([meta[i]['first_WIFI_line'] for i in ids]))
                source_floors=sorted(hi);h=[pack(hi[j]) for j in source_floors];s=pack(sr);q=pack(qi)
                gaps=[abs(j-f) for j in source_floors]
                bank=GapReference(h,gaps,'prototype')
                direct=bank.event(bank.query(q['rss']),s,[.35])[.35,3]
                model=fit_map(h,s,floor_gaps=gaps)
                assert model.visible.all()
                parent=model.predict(q['rss'])
                hxy,hids=group_ids(np.vstack([z['xy'] for z in h]),np.concatenate([z['ids'] for z in h]))
                sxy,sids=group_ids(s['xy'],s['ids'])
                assert np.array_equal(model.xy,np.vstack([hxy,sxy]))
                dist=squared(tpm.dbm(q['rss'])+110.,model.prototypes+110.)
                ix=order(dist,np.r_[hids,sids],7)
                mapped=vote(np.take_along_axis(dist,ix,axis=1),model.xy[ix]-model.xy[0],len(aps))[0]+model.xy[0]
                w=position_weights(q['xy']);event=dict(floor=f,draw=draw['draw'],K=k)
                row=dict(**event,aps=len(aps),n_H=len(all_h),n_Q=len(qi));pred_row=dict(**event,qid=qi,weight=w)
                for name,pred in [('parent',parent),('floor_wknn',direct),('map_wknn',mapped)]:
                    err=np.linalg.norm(pred-q['xy'],axis=1)*UNIT
                    if not np.isfinite(err).all():raise ArithmeticError(('Failure',event,name))
                    row[name]=float(w@err)
                    pred_row[name+'_x_m']=pred[:,0]*UNIT;pred_row[name+'_y_m']=pred[:,1]*UNIT
                    pred_row[name+'_error_m']=err
                scores.append(row);predictions.append(pd.DataFrame(pred_row))
                evidence.append(dict(**event,permitted_AP_axis_sha256=a,frame_sha256=e['coordinate_frame_sha256']))
    assert len(scores)==600
    ev=pd.DataFrame(scores);ev.to_csv(out/'events.csv',index=False);pd.concat(predictions).to_csv(out/'predictions.csv.gz',index=False)
    pd.DataFrame(evidence).to_csv(out/'verification.csv',index=False)
    result=summarize(ev,out);result.update(pins,events=len(scores),failures=0,
        interval='10,000 within-floor paired draw bootstraps, same full K curve per draw. Locations and route/device are fixed.')
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(result)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['archive','design','repo','out']:p.add_argument(name,type=Path)
    a=p.parse_args();main(a.archive,a.design,a.repo,a.out)
