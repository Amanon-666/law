"""UJITI development route only. Propagate S residuals and append raw S candidates in a 2x2."""
import argparse, gzip, json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap, historical_prior
from research.uji_core.protocol import position_weights
from replay import ALLOW, R1, R2, KS, UNIT, digest, canonical, axishash, extract

ARMS=('A_H','B_H_plus_S','D_correct_H','C_parent')


def calculate(archive, design, out):
    manifest=(design/'route_manifest.json').read_bytes()
    proto=json.loads((design/'protocol.json').read_text())
    assert digest((design/'protocol.json').read_bytes())=='b7b5483b7c401ecb9ee5061c64021bbf3fb3f293c0f8ac25ffe414295c6c2e1d'
    assert digest(manifest)==proto['manifest_sha256'] and digest(archive.read_bytes())==proto['input_archive_sha256']
    packed=(design/'scan_metadata.json.gz').read_bytes(); plain=gzip.decompress(packed)
    assert digest(packed)==proto['scan_metadata_sha256'] and digest(plain)==proto['scan_metadata_plain_sha256']
    meta={v['id']:v for v in json.loads(plain) if v['file'] in (R1,R2)}
    members={v['member']:v for v in proto['allowed_members'] if v['member'] in ALLOW}
    with ZipFile(archive) as z:
        rss={}
        for member in sorted(ALLOW):
            rss.update(extract(z,member,members[member],meta))
    assert rss.keys()==meta.keys()
    prior_receipt=pd.read_csv(out/'verification.csv').set_index(['floor','draw','K'])
    rows=[]
    for e in [r for r in json.loads(manifest) if r['site']=='UJITI']:
        f=e['floor']; qids=e['ordered_Q_ids']
        his={int(hf):ids for hf,ids in e['H_by_floor'].items()}
        allh=sum(his.values(),[]);pool=e['eligible_target_S_ids']
        xy={i:((meta[i]['lon']-e['lon0'])*e['east_m_per_degree'],(meta[i]['lat']-e['lat0'])*e['north_m_per_degree']) for i in allh+pool+qids}
        assert digest(canonical([(i,xy[i][0].hex(),xy[i][1].hex()) for i in sorted(xy)]))==e['coordinate_frame_sha256']
        gaps=[abs(g-f) for g in sorted(his)];hseen=set().union(*(rss[i] for i in allh))
        assert axishash(hseen)==e['H_only_AP_axis']['sha256']
        for d in e['draws']:
            for k in KS:
                sr=d['ordered_S_scan_ids'][:k]; aps=sorted(hseen.union(*(rss[i] for i in sr)))
                ah=axishash(aps); assert ah==d['permitted_AP_axis'][str(k)]['sha256']==prior_receipt.at[(f,d['draw'],k),'permitted_AP_axis_sha256']
                cols={ap:j for j,ap in enumerate(aps)}
                def pack(ids):
                    v=np.full((len(ids),len(cols)),100.,float)
                    for j,i in enumerate(ids):
                        for ap,level in rss[i].items():
                            if ap in cols: v[j,cols[ap]]=level
                    return dict(rss=v,xy=np.array([xy[i] for i in ids])/UNIT)
                hs=[pack(his[g]) for g in sorted(his)];s=pack(sr);q=pack(qids)
                raw,hxy=historical_prior(hs,10.,.5,gaps)
                calibrated,coords=tpm.calibrate((raw,hxy),s,(40.,1.))
                anchors,sxy=tpm.position_map(tpm.dbm(s['rss']),s['xy'])
                nh=len(raw)
                np.testing.assert_array_equal(calibrated[nh:],anchors)
                np.testing.assert_array_equal(coords,np.vstack([hxy,sxy]))
                # Uniform prior per retained candidate row in every readout: an S candidate
                # may add another vote even where its coordinate also occurs in H.
                alternatives=[(raw,hxy),(np.vstack([raw,anchors]),coords),(calibrated[:nh],hxy),(calibrated,coords)]
                w=position_weights(q['xy'])
                result=dict(floor=f,draw=d['draw'],K=k,aps=len(aps),h_aps=len(hseen),historical_candidates=nh,
                            all_candidates=len(coords),coincident_H_S=int(sum(tuple(p) in set(map(tuple,hxy)) for p in sxy)))
                for name,(m,x) in zip(ARMS,alternatives):
                    prob=tpm.tobit_weights(q['rss'],m,12.,-85.)
                    pred=prob@(x-x[0])+x[0]
                    result[name]=float(w@np.linalg.norm(pred-q['xy'],axis=1)*UNIT)
                rows.append(result)
    result=pd.DataFrame(rows).sort_values(['floor','draw','K'])
    previous=pd.read_csv(out/'events.csv').sort_values(['floor','draw','K'])
    np.testing.assert_array_equal(result[['floor','draw','K']],previous[['floor','draw','K']])
    assert len(result)==600 and np.isfinite(result[list(ARMS)]).all().all()
    max_diff=float(np.max(abs(result.C_parent.to_numpy()-previous.parent.to_numpy())))
    if max_diff>1e-9:raise ValueError('Parent did not replay')
    result=result.assign(append_to_raw=result.B_H_plus_S-result.A_H,
                         update_H_only=result.D_correct_H-result.A_H,
                         update_with_anchors=result.C_parent-result.B_H_plus_S,
                         append_to_corrected=result.C_parent-result.D_correct_H,
                         interaction=result.C_parent-result.B_H_plus_S-result.D_correct_H+result.A_H)
    result.to_csv(out/'factorial_events.csv',index=False)
    return result,max_diff


def summarize(table,max_diff,out):
    cols=list(ARMS)+['append_to_raw','update_H_only','update_with_anchors','append_to_corrected','interaction']
    curves=[];changes=[];site=[];replicates=[];rng=np.random.default_rng(261101)
    def record(label,est,boot):
        for i,k in enumerate(KS):
            curves.append(dict(floor=label,K=k,**{c:est[i,j] for j,c in enumerate(cols)}))
        change=est[-1]-est[2];rep=boot[:,-1,:]-boot[:,2,:]
        for j,c in enumerate(cols):
            lo,hi=np.quantile(rep[:,j],[.025,.975])
            changes.append(dict(floor=label,measure=c,K20_minus_K5=change[j],lo95=lo,hi95=hi))
    for f,g in table.groupby('floor'):
        v=g.sort_values(['draw','K'])[cols].to_numpy().reshape(40,5,len(cols))
        boot=v[rng.integers(40,size=(10000,40))].mean(1)
        record(f,v.mean(0),boot);site.append(v.mean(0));replicates.append(boot)
    record('all',np.mean(site,0),np.mean(replicates,0))
    pd.DataFrame(curves).to_csv(out/'factorial_curves.csv',index=False)
    pd.DataFrame(changes).to_csv(out/'factorial_5_to_20.csv',index=False)
    ap=table.groupby(['floor','K']).agg(min_APs=('aps','min'),max_APs=('aps','max'),H_APs=('h_aps','min'),
          mean_APs=('aps','mean'),H_candidates=('historical_candidates','min'),HS_candidates=('all_candidates','min'),
          max_coincident=('coincident_H_S','max'))
    ap.to_csv(out/'factorial_coverage.csv')
    notes=dict(arms={'A_H':'Historical prior rows only, unconditioned.','B_H_plus_S':'Same prior plus actual S prototypes. No residual propagation.',
                     'D_correct_H':'Corrected H rows only.','C_parent':'Corrected H rows plus the identical actual S prototypes.'},
               events=len(table),parent_replay_max_MDE_m=max_diff,H_only_range_across_draw_and_K_m=table.groupby('floor').A_H.agg(lambda v:v.max()-v.min()).to_dict(),
               rule='No fitting. Frozen event-specific H union current S APs, candidates share equal mass per row. '
               'Cells separate changes to H prototypes from appending measured support rows. They do not separate values of appended rows from their multiplicity.',
               intervals='10,000 conditional paired resamples of 40 nested curves per fixed floor; independent floor draws, same queries. Distances in meters.')
    (out/'factorial_receipt.json').write_text(json.dumps(notes,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ['archive','design','out']:p.add_argument(n,type=Path)
    a=p.parse_args();t,delta=calculate(a.archive,a.design,a.out);summarize(t,delta,a.out)
