"""Forecast repeat-measured anchor fingerprints one week later, without localization.

Run with PYTHONPATH pointed to the law workbench containing anchor_measure.py.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from external_baselines.tpm_adapter import dbm
from residual_probe.episode_rows import nested_rows
from research.uji_core.next import anchor_measure as anchors
from research.uji_core.next import longitudinal as lib
from research.uji_core.next.external import METRES_PER_UJI_UNIT as UNIT
from research.uji_core.protocol import BUDGETS, SEEDS


def main(archive,out):
    out.mkdir(exist_ok=True,parents=True)
    h={floor:lib.on_floor(archive,25,'tst',1,floor) for floor in (3,5)}
    results=[];draws=[];cells=[]
    for floor,other in [(3,5),(5,3)]:
        old=h[floor]
        prior=anchors.history([h[other]],scale=UNIT)
        targets={}
        xyset,inv,cnt=np.unique(old['xy'],axis=0,return_inverse=True,return_counts=True)
        inv=inv.ravel()
        if len(xyset)!=24 or not np.all(cnt==12):raise ValueError('Changed grid')
        if not all(str(t).startswith('20180706') for t in old['times']):raise ValueError('Invalid July6 day')
        for phone,n in [('S3',5),('A5',10)]:
            q=lib.on_floor(archive,25,'tst',n,floor)
            np.testing.assert_array_equal(q['xy'],old['xy'])
            if set(old['ids'])&set(q['ids']) or not all(str(t).startswith('20180713') for t in q['times']):
                raise ValueError('Earlier/later campaigns not independent')
            means={tuple(xy):dbm(q['rss'][inv==j]).mean(0) for j,xy in enumerate(xyset)}
            targets[phone]=means
            cells.append(dict(floor=floor,phone=phone,campaign=n,n_scans=len(q['rss']),n_xy=len(means),
                              timestamp_min=int(q['times'].min()),timestamp_max=int(q['times'].max())))
        for seed in SEEDS:
            order=nested_rows(old['xy'],range(len(old['rss'])),BUDGETS,0,
                              f'lib-anchor-repeat-v1/{floor}/{seed}')['support_rows'][20]
            draws.append(dict(floor=floor,seed=seed,support_ids=old['ids'][order].tolist()))
            for k in BUDGETS:
                s={key:old[key][order[:k]] for key in ('rss','xy','ids')}
                model=anchors.build(prior,s,scale=UNIT)
                # This mask has no input from July 13, and is identical for all templates/phones.
                mask=(h[other]['rss']!=100).any(0)|(s['rss']!=100).any(0)
                np.testing.assert_array_equal(mask,model.visible)
                loc,first=np.unique(s['xy'],axis=0,return_index=True)
                np.testing.assert_allclose(loc,model.xy[-k:],rtol=0,atol=1e-11)
                np.testing.assert_array_equal(dbm(s['rss'][first][:,mask]),model.raw)
                if len(loc)!=k:raise ValueError('Repeated support position')
                templates={'raw':model.raw,'field':model.posterior,'half':(model.raw+model.posterior)*.5}
                for phone,means in targets.items():
                    truth=np.stack([means[tuple(x)] for x in loc])[:,mask]
                    losses={a:np.mean((t-truth)**2,axis=1) for a,t in templates.items()}
                    for j,p in enumerate(loc):
                        row=dict(floor=floor,seed=seed,K=k,phone=phone,x=p[0],y=p[1],
                          scan=s['ids'][first[j]],n_AP=int(mask.sum()),n_S_colocated_with_H=model.n_collision)
                        row.update({a:v[j] for a,v in losses.items()})
                        row.update(field_minus_raw=row['field']-row['raw'],half_minus_raw=row['half']-row['raw'],
                                   half_minus_field=row['half']-row['field'])
                        results.append(row)
    rows=pd.DataFrame(results)
    arms=['raw','half','field','field_minus_raw','half_minus_raw','half_minus_field']
    if len(rows)!=2*2*10*sum(BUDGETS) or not np.isfinite(rows[arms].to_numpy()).all():
        raise ValueError('Missing anchor template comparisons')
    # Within event, each selected anchor has one vote. Then equal draws, floors, and budgets.
    events=rows.groupby(['phone','floor','seed','K'])[arms].mean().reset_index()
    by_k=events.groupby(['phone','K'])[arms].mean()
    macro=events.groupby('phone')[arms].mean()
    intervals=[]
    for phone,t in events.groupby('phone'):
        rng=np.random.default_rng(700136)
        b=[]
        for floor,g in t.groupby('floor'):
            a=g.sort_values(['seed','K'])[arms].to_numpy().reshape(len(SEEDS),len(BUDGETS),len(arms))
            b.append(a[rng.integers(len(SEEDS),size=(10000,len(SEEDS)))].mean(1))
        boots=np.mean(b,axis=0)
        for i,arm in enumerate(arms[3:], start=3):
            lo,hi=np.quantile(boots[:,:,i].mean(axis=1),[.025,.975])
            intervals.append(dict(phone=phone,contrast=arm,paired_mean=macro.loc[phone,arm],
                support_only_lo=lo,support_only_hi=hi))
    rows.to_csv(out/'anchor_sites.csv.gz',index=False)
    by_k.to_csv(out/'by_K.csv');macro.to_csv(out/'summary.csv')
    events.groupby(['phone','floor'])[arms].mean().to_csv(out/'by_floor.csv')
    pd.DataFrame(intervals).to_csv(out/'paired.csv',index=False)
    design=dict(dataset=lib.SHA256,doi='10.5281/zenodo.3748719',history='July 6 S3 tst01 opposite floor, all 12 scans at each of 24 positions',
        support='July 6 S3 tst01 target floor, nested sample of unique XY and one scan per site. Selection depends on positions and a frozen string seed only. Same S for both target phones.',
        truth='July13 S3 tst05 and A5 tst10 target floor. At each selected S site, arithmetic mean over all 12 independent future scans, coded −110 dBm on misses before averaging. Complete target grid match in both floors/phones.',
        axis='Current H union current K support detected APs; use all these APs unweighted for every template and both phones. Excludes true July13-only APs, includes common misses; no target-driven selection or filling.',
        field='anchor_measure.history/build; H spatial half-smoothing at 10 U, S residual kernel 40 U unit ridge, exact corrected H value if co-located; input metric XY through scale 0.766 m/U. Field template uses the very same anchor to estimate the residual.',
        score='Mean squared dBm error of each predicted template to the future same-position vector. Average APs, then K positions, draws, floors and budgets. Paired bootstrap resamples complete nested draw curves within fixed floors; not a site or future-session confidence interval. This estimates prototype repeatability only.',
        n_ap_range=[int(rows.n_AP.min()),int(rows.n_AP.max())],distinct_anchor_positions_over_draws=int(len(rows[['floor','x','y']].drop_duplicates())),
        n_all_colocated_events=int((rows.groupby(['floor','seed','K']).first().n_S_colocated_with_H.values==np.tile(BUDGETS,2*len(SEEDS))).sum()),
        receipts=draws,query=cells)
    (out/'design.json').write_text(json.dumps(design,indent=2)+'\n')
    print(by_k.round(3));print(macro.round(3));print(pd.DataFrame(intervals).round(3))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive',type=Path);p.add_argument('out',type=Path);args=p.parse_args()
    main(args.archive,args.out)
