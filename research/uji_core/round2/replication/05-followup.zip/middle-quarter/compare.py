"""One post-hoc UJI-only counterfactual. Run with the repository root on PYTHONPATH.

python compare.py {official,phone,summary} UJI_DATA EXISTING_FRESH EXISTING_CONDITIONAL_FRESH FROZEN_FIT OUTPUT
Only one extra coefficient vector is introduced. Every original gate is reused.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from external_baselines import tpm_adapter as tpm
from refi import FingerprintMap
from research.uji_core.round2.conditional_map import ConditionalMeanMap, historical_moments, BAND_EDGES
from research.uji_core.protocol import BUDGETS, read_floors, position_weights
from research.uji_core.smooth_scale import local_rows

KEYS = ["building", "floor", "draw", "K"]
QUARTER = (0.0, 0.25, 0.0)
FIT_SHA = "0b36024f6832eddde20c044739b2b48edcbf8c8e107fd51c24ecbdcbfc1e2386"
MANIFEST_SHA = "13091aa0b9c105e14de3e1498fa760851fb701d77a7590943fcb60966e59e0b8"


def read_frozen(path, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError(f"Frozen file changed: {path}")
    return json.loads(raw)


def score(mode, data, fresh, previous, fit, out):
    design = read_frozen(fresh / "freeze.json", MANIFEST_SHA)
    gates = read_frozen(fit, FIT_SHA)["folds"]
    t = read_floors(data, "trainingData.csv")
    v = read_floors(data, "validationData.csv")
    phone = pd.read_csv(data / "trainingData.csv", usecols=["PHONEID"]).PHONEID.to_numpy()
    rows = []
    for job in [j for j in design["jobs"] if j["mode"] == mode]:
        b, f, dev = job["building"], job["floor"], job["device"]
        target = t[b, f]
        source_q = v[b, f] if dev is None else target
        qrows = local_rows(source_q, np.asarray(job["qids"]))
        q = {key: z[qrows] for key, z in source_q.items()}
        w = position_weights(q["xy"])
        histories, gaps = [], []
        for (bb, ff), bank in sorted(t.items()):
            if bb != b or ff == f:
                continue
            if dev is not None:
                bank = {key: z[phone[bank["ids"]] != dev] for key, z in bank.items()}
            if len(bank["ids"]):
                histories.append(bank)
                gaps.append(abs(ff - f))
        mean, xy, p, cond = historical_moments(histories, gaps)
        hseen = np.logical_or.reduce([(h["rss"] != 100).any(0) for h in histories])
        orders = local_rows(target, np.asarray(job["orders"]))
        fixed_gate = tuple(gates[str(b)]["values"]["gate"])
        for draw, order in zip(design["new_draws"], orders):
            for k in BUDGETS:
                sr = order[:k]
                visible = hseen | (target["rss"][sr] != 100).any(0)
                s = dict(rss=target["rss"][sr][:, visible], xy=target["xy"][sr])
                prototypes, positions = tpm.calibrate((mean[:, visible], xy), s, (40., 1.))
                base = FingerprintMap(prototypes, positions, visible)
                bands = np.searchsorted(BAND_EDGES, p[:, visible], side="right")
                model = ConditionalMeanMap(base, cond[:, visible] - mean[:, visible], bands, fixed_gate)
                error = lambda g: float(w @ np.linalg.norm(model.predict(q["rss"], g) - q["xy"], axis=1))
                rows.append(dict(building=b, floor=f, draw=draw, K=k, gate=error(fixed_gate),
                                 middle_quarter=error(QUARTER)))
    result = pd.DataFrame(rows).set_index(KEYS).sort_index()
    original = pd.read_csv(previous / f"{mode}.csv").set_index(KEYS).sort_index()
    if len(result) != 2600 or not result.index.equals(original.index):
        raise ValueError("Unpaired UJI rows")
    np.testing.assert_allclose(result.gate, original.gate, rtol=0., atol=1e-8)
    result["gate_replay_delta"] = result.gate - original.gate
    result["gate_minus_quarter"] = result.gate - result.middle_quarter
    result.to_csv(out / f"{mode}.csv")


def summary(out):
    summaries, cells = {}, []
    for mode in ("official", "phone"):
        d = pd.read_csv(out/f"{mode}.csv")
        floor = d.groupby(["building","floor","K"]).mean(numeric_only=True)
        centers, boots = [], []
        rng = np.random.default_rng(261101)
        for b, group in d.groupby("building"):
            floor_boot = []
            for _, part in group.groupby("floor"):
                curve = part.sort_values(["draw","K"]).gate_minus_quarter.to_numpy().reshape(40,5)
                resamples = rng.integers(40,size=(10000,40))
                floor_boot.append(curve[resamples].mean(axis=1))
            delta = group.groupby(["floor","K"]).gate_minus_quarter.mean().groupby("K").mean().to_numpy()
            draws = np.mean(floor_boot, axis=0)
            centers.append(delta); boots.append(draws)
            for i,k in enumerate(BUDGETS):
                low,high = np.quantile(draws[:,i],[.025,.975])
                cells.append(dict(mode=mode,building=b,K=k,delta=delta[i],lo=low,hi=high))
        rep = np.mean(boots,axis=(0,2)); center = np.asarray(centers)
        means = floor.groupby(["building","K"]).mean().mean()
        summaries[mode] = dict(events=len(d), learned=float(means.gate), fixed=float(means.middle_quarter),
                              delta=float(center.mean()), conditional_95=np.quantile(rep,[.025,.975]).tolist(),
                              building_deltas=center.mean(axis=1).tolist(),building_K_wins=int((center< -1e-9).sum()),
                              floor_K_wins=int((floor.gate_minus_quarter< -1e-9).sum()),
                              draw_K_wins=int((d.gate_minus_quarter< -1e-9).sum()),
                              max_archived_gate_replay_gap=float(d.gate_replay_delta.abs().max()))
    summary = dict(post_hoc=True, new_fixed=QUARTER, learned_minus_fixed=True, fitted=False,
                   manifest_sha256=MANIFEST_SHA, fit_sha256=FIT_SHA,
                   uncertainty="Paired support draws within each fixed floor, a whole nested K curve per draw; equal building, floor and K; 10000 draws. Fixed queries and phones.",
                   results=summaries)
    pd.DataFrame(cells).to_csv(out/"building_K.csv",index=False)
    (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(summaries)


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode",choices=["official","phone","summary"])
    for name in ("data","fresh","previous","fit","out"): p.add_argument(name,type=Path)
    a=p.parse_args()
    if a.mode=="summary": summary(a.out)
    else: score(a.mode,a.data,a.fresh,a.previous,a.fit,a.out)
