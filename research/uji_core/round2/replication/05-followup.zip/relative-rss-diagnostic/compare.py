"""Compare absolute and centered RSS margins at known library grid coordinates."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
import pandas as pd


SHA = '0a74d814be48359dc4b9f7aee26cf8905574d4999db722aa477cfd571a2ce505'
CAMPAIGNS = {
    'Jul06': {'S3': 1, 'A5': 6},
    'Jul13': {'S3': 5, 'A5': 10},
}


def read(z, campaign):
    def matrix(suffix, dtype):
        with z.open(f'db/25/tst{campaign:02d}{suffix}.csv') as f:
            return pd.read_csv(f, header=None, dtype=dtype, float_precision='round_trip').values
    return (matrix('crd', float), matrix('rss', np.int16),
            matrix('ids', str).ravel(), matrix('tms', np.int64).ravel())


def median(values, weights):
    # Inverse CDF median; take the midpoint if exactly half the mass is below a gap.
    values = np.asarray(values)
    order = np.argsort(values, kind='stable')
    weights = np.asarray(weights)[order]
    acc = np.cumsum(weights)
    half = .5 * acc[-1]
    j = max(0, int(np.searchsorted(acc, half - 1e-11)))
    if np.isclose(acc[j], half, atol=1e-11, rtol=0) and j+1<len(order):
        return float(.5*(values[order[j]]+values[order[j+1]]))
    return float(values[order[j]])


def summary(z):
    kept = z[z.n_common >= 3].copy()
    if len(kept) == 0:
        raise ValueError('No eligible scan')
    geom = ['floor', 'position']
    weight = 1./kept.groupby(geom).scan.transform('count')
    n_xy = len(z[geom].drop_duplicates())
    n_kept = len(kept[geom].drop_duplicates())
    def mean(x):
        return float(np.average(x, weights=weight))
    def med(x):
        return median(x, weight)
    return dict(total=len(z),kept=len(kept),fraction_kept=len(kept)/len(z),
        locations=n_xy,eligible_locations=n_kept,median_common_AP=med(kept.n_common),
        raw_truth_win=mean(kept.raw_margin>0),centered_truth_win=mean(kept.centered_margin>0),
        raw_ties=mean(kept.raw_margin==0),centered_ties=mean(kept.centered_margin==0),
        raw_median_margin=med(kept.raw_margin),centered_median_margin=med(kept.centered_margin),
        paired_median_margin_change=med(kept.centered_margin-kept.raw_margin),
        true_query_minus_H_median_dB=med(kept.delta_true),
        true_query_minus_H_median_abs_dB=med(kept.delta_true.abs()),
        true_MSE_raw=mean(kept.true_MSE),true_MSE_centered=mean(kept.true_centered_MSE))


def main(path, out):
    if hashlib.sha256(path.read_bytes()).hexdigest() != SHA:
        raise ValueError('Expected UJI LIB v2.2 only')
    out.mkdir(parents=True,exist_ok=True)
    with ZipFile(path) as z:
        tables = {n:read(z, n) for n in (1,6,5,10)}
    base = tables[1]
    for n, (coord, rss, ids, tm) in tables.items():
        np.testing.assert_array_equal(coord, base[0])
        np.testing.assert_array_equal([s[4:] for s in ids], [s[4:] for s in base[2]])
        ymd = '20180706' if n in (1,6) else '20180713'
        if not all(str(t).startswith(ymd) for t in tm) or rss.shape != (576,620):
            raise ValueError('Changed month-25 campaign coverage')
    results=[];geometry=[]
    for floor in (3,5):
        on=base[0][:,2]==floor
        xy,inv,cnt=np.unique(base[0][on,:2],axis=0,return_inverse=True,return_counts=True)
        inv=inv.ravel()
        if len(xy)!=24 or not np.all(cnt==12):
            raise ValueError('Changed survey grid or repeats')
        dist=((xy[:,None]-xy[None,:])**2).sum(-1);np.fill_diagonal(dist,np.inf)
        neighbors=[]  # positions sorted lexicographically in physical x,y
        for a,d in enumerate(dist):
            tied=np.flatnonzero(np.isclose(d,np.min(d),rtol=1e-12,atol=1e-12))
            b=int(tied[0]);neighbors.append(b)
            geometry.append(dict(floor=floor,position=a,x=xy[a,0],y=xy[a,1],foil=b,
                                 foil_x=xy[b,0],foil_y=xy[b,1],distance_m=np.sqrt(d[b]),n_ties=len(tied)))
        for H_date,Q_date in [('Jul06','Jul13'),('Jul13','Jul06')]:
            H=tables[CAMPAIGNS[H_date]['S3']][1][on]
            mean=np.full((24,H.shape[1]),np.nan)
            for a in range(len(xy)):
                r=H[inv==a];seen=r!=100
                mean[a]=np.divide(np.where(seen,r,0).sum(0),seen.sum(0),
                                  out=np.full(H.shape[1],np.nan),where=seen.any(0))
            for phone in ('S3','A5'):
                _,Q,ids,_=tables[CAMPAIGNS[Q_date][phone]]
                for a,q,scan in zip(inv,Q[on],ids[on]):
                    b=neighbors[a];use=(q!=100)&np.isfinite(mean[a])&np.isfinite(mean[b])
                    row=dict(history=H_date,query=Q_date,phone=phone,floor=floor,
                             position=a,x=xy[a,0],y=xy[a,1],foil=b,scan=scan,n_common=int(use.sum()))
                    if use.sum()>=3:
                        et=q[use]-mean[a,use]; ef=q[use]-mean[b,use]
                        tc=np.mean((et-et.mean())**2);fc=np.mean((ef-ef.mean())**2)
                        t=np.mean(et**2);f=np.mean(ef**2)
                        row.update(raw_margin=f-t,centered_margin=fc-tc,delta_true=et.mean(),
                                   delta_foil=ef.mean(),true_MSE=t,true_centered_MSE=tc)
                        np.testing.assert_allclose((f-t)-(fc-tc),ef.mean()**2-et.mean()**2,atol=1e-10)
                    results.append(row)
    frame=pd.DataFrame(results);rows=[]
    for by,group in frame.groupby(['history','query','phone']):
        for level, part in [('all',group),*group.groupby('floor')]:
            rows.append(dict(zip(['history','query','phone'],by),floor=level,**summary(part)))
    summed=pd.DataFrame(rows)
    frame.to_csv(out/'scans.csv.gz',index=False)
    pd.DataFrame(geometry).to_csv(out/'geometry.csv',index=False)
    summed.to_csv(out/'summary.csv',index=False)
    manifest=dict(archive_sha256=SHA,archive_doi='10.5281/zenodo.3748719',motivation_doi='10.1109/PERCOM.2008.75',
        input_files={d:{p:f'db/25/tst{n:02}' for p,n in v.items()} for d,v in CAMPAIGNS.items()},
        primary='History is 12 real S3 scans per XY on 2018-07-06; Q is independent S3 or A5 data on 2018-07-13. The reverse date direction (later S3 H to earlier Q) is a retrospective sensitivity, not a prospective deployment.',
        reference='Per-AP mean over measured dBm among the 12 H scans sharing each physical XY (ignore 100 sentinel). Missing if never detected. The foil is nearest other coordinate Euclidean within the target floor. Distances tied at 1e-12 relative/absolute on squared metres resolve to smaller lexicographically sorted XY, independent of RSS.',
        AP='Q detected, true H mean observed, and foil H mean observed; at least 3 common APs. Raw and centered compare exactly these same three vectors on exactly the same dimensions; query usages of unmatched APs / misses are discarded. AP intersections may differ from scan to scan or phone to phone.',
        score='MSE(foil,Q) minus MSE(true,Q) in dB squared. Positive favors truth; zero is a tie, reported separately. Center each of the three vectors by its own mean on the intersection; centered MSE is unchanged by any additive per-vector shift. Raw minus centered margin equals squared foil offset minus squared true offset, verified scan by scan.',
        weighting='A position has unit weight divided equally among eligible scans at that site/floor/XY, all 24 locations on each equal-sized floor. The median is the resulting weighted scan median, not median of position medians. Coverage reports all eligible scans and positions.',
        limits='Development-only retrospective within one fixed library and two sequentially collected phone sessions on each date. Oracle choice of true-vs-nearest candidate and common AP set is diagnostic only, not a query-time method or a localization MDE. Source paper developed pairwise ratio features; centering here specifically tests the common additive dB offset intuition.')
    (out/'design.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(summed[summed.floor=='all'].round(4).to_string(index=False))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive',type=Path);p.add_argument('out',type=Path)
    args=p.parse_args();main(args.archive,args.out)
