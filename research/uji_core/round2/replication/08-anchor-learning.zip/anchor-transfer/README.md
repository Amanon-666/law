# Library-fitted anchor reliability on UJIndoorLoc

The only learned candidate mixes a singleton anchor scan with its smoothed posterior fingerprint, with five budget-indexed fractions fit on early library date pairs. It reuses the public gap-2 field, calibration, coordinate multiplicity and matcher.

The original (0–9) and additional (10–49) support draws are reported separately. All 50 use the same target queries and histories. Paired intervals cover support-order variability on those queries. Errors use the original UJIndoorLoc coordinate units.

## Reproduce

Run from the directory containing the local law checkout and data_raw. Pass the location of the archived event tables for the three prespecified comparison procedures. The score script checks the immutable Git receipt and the parameter checksums before calculation.

```sh
OUT=/tmp/uji-round2/anchor-transfer
SRC=/tmp/uji-round2/anchor-learning
ROOT=/tmp/uji-round2
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python "$OUT/score_uji.py" \
  --repo law --data data_raw/UJIndoorLoc --old law/research/uji_core/results \
  --fresh "$ROOT/fresh-draws" --paired "$ROOT/paired-map" --out "$OUT" \
  --params "$SRC/frozen.json" --params-sha ed3ae84fd08d2286b7c754937d0d1c50b9304e8c339c3a3a5487689eea481162 \
  --knn-params "$SRC/wknn_frozen.json" --knn-sha 552c15bbb106718ac1994564ba00691c168621208052911b657b51894ca77fab \
  --freeze-commit 90b24f3b02a916191533b3a3888cb0dc235da1e8 \
  --freeze-receipt research/uji_core/round2/route/anchor_trial/frozen.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python "$OUT/verify.py" \
  --repo law --data data_raw/UJIndoorLoc --old law/research/uji_core/results \
  --fresh "$ROOT/fresh-draws" --out "$OUT" --period "$ROOT/period-wknn" \
  --fixed-phone "$ROOT/decision-audit/fixed_wknn_phone.csv"
```

## Output

- `*_old.csv` and `*_new.csv` carry every paired floor, support draw and budget.
- `macro_K.csv`, `building_K.csv` and `floor_K.csv` retain the budget curves. The macro gives all three buildings equal weight, and every floor in a building equal weight.
- `contrasts.csv` gives signed candidate-minus-control deltas and paired intervals. `summary.json` records the three gates. `all_archived_WKNN.csv` adds all pre-existing original WKNN arms to the head-to-head check.
- `committed_api_parity.json` compares four mixtures against the actual anchor trial API at both ends of the K curve and both support splits. `parity.csv` checks the raw anchor and original same-map WKNN against archived event-level MDEs.

Across all four regimes the budget-indexed fit improves slightly over its matched learned scalar. Fixed 0.75 gives smaller pooled error in all four, and held-phone B1 still has two budget cells worse than the strongest WKNN in each support split. These results do not qualify the learned rule for deployment.
