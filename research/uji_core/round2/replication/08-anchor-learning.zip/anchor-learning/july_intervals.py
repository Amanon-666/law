"""Fixed-site, support-draw uncertainty for genuinely frozen future-template forecasts."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import fit


def main(archive,out):
    receipt='ed3ae84fd08d2286b7c754937d0d1c50b9304e8c339c3a3a5487689eea481162'
    frozen=out/'frozen.json'
    if fit.digest(frozen)!=receipt:raise ValueError('Expected pre-release freeze')
    conf=json.loads(frozen.read_text())
    early={f:fit.library.on_floor(archive,25,'tst',1,f) for f in (3,5)}
    q={phone:{f:fit.library.on_floor(archive,25,'tst',n,f) for f in (3,5)} for phone,n in [('S3',5),('A5',10)]}
    stats,_=fit.sufficient(early,q,'20180706-20180713','repeat')
    ev=stats.groupby(['phone','floor','draw','K'])[['a','b','c']].mean().reset_index()
    g=ev.K.map({int(k):v for k,v in conf['g_by_K'].items()})
    e=lambda t:ev.c-2*ev.a*t+ev.b*t*t
    refs={**fit.FIXED,'pooled':conf['g_scalar']}
    for name,v in refs.items():ev[name]=e(g)-e(v)
    results=[]
    for phone,t in ev.groupby('phone'):
        obs=[];boots=[];rng=np.random.default_rng(6112016)
        for _,f in t.groupby('floor'):
            cube=f.sort_values(['draw','K'])[list(refs)].to_numpy().reshape(10,5,len(refs))
            obs.append(cube.mean((0,1)));boots.append(cube[rng.integers(10,size=(10000,10))].mean((1,2)))
        mean=np.mean(obs,axis=0);ci=np.quantile(np.mean(boots,axis=0),[.025,.975],axis=0)
        for j,name in enumerate(refs):
            results.append(dict(phone=phone,ref=name,by_K_minus_ref=mean[j],fixed_pool_support_only_lo=ci[0,j],fixed_pool_support_only_hi=ci[1,j]))
    table=pd.DataFrame(results);table.to_csv(out/'july_paired.csv',index=False)
    print(table[table.ref.isin(['half','pooled'])].round(4).to_string(index=False))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive',type=Path);p.add_argument('out',type=Path)
    a=p.parse_args();main(a.archive,a.out)
