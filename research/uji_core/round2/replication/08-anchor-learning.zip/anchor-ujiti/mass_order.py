"""UJITI diagnostic. Attribute fully-field F -> learned L in error space, swapping mass first.

Run from the law checkout with PYTHONPATH=. and OPENBLAS_NUM_THREADS=1.
Arguments: IPIN_ZIP FROZEN_ROUTE_DIR FIT_JSON OLD_REPLAY_DIR RESULT_DIR.
"""
import argparse
import gzip
import json
from pathlib import Path
import sys
from zipfile import ZipFile

import numpy as np
import pandas as pd
from scipy.special import expit, log_ndtr, logsumexp
from external_baselines import tpm_adapter as tpm
from research.uji_core.protocol import position_weights
from anchor_readout import fit_anchor_readout

KS = (1, 3, 5, 10, 20)
CELLS = ('FF', 'LF', 'FL', 'LL')  # first letter total support mass, second within-support distribution
MEASURES = (*CELLS, 'mass_first', 'within_second', 'L_minus_F', 'interaction', 'pS_F', 'pS_L')


def logits(query, fingerprints):
    """Exact unnormalized tobit_weights score before subtracting a row maximum."""
    seen = (query != 100).astype(float)
    x = tpm.dbm(query) * seen
    sq = (x*x).sum(1, keepdims=True) + seen @ (fingerprints*fingerprints).T - 2*x @ fingerprints.T
    return (-.5/12**2) * sq + (1-seen) @ log_ndtr((-85-fingerprints)/12).T


def group(scores, xy):
    """Normalize inside the group even if its global mass underflows to zero."""
    if not len(xy):
        return np.full(len(scores), -np.inf), np.zeros((len(scores), 2))
    partition = logsumexp(scores, axis=1)
    conditional = np.exp(scores - partition[:, None])
    return partition, conditional @ xy


def separate(route, field_fraction, q, metre):
    models = {'F': route.map_for(1.), 'L': route.map_for(field_fraction)}
    nh = len(route.historical)
    origin = route.xy[0]
    xy = route.xy - origin
    data = q['rss'][:, route.visible]
    h_log, h_xy = group(logits(data, route.historical), xy[:nh])
    probs, centroids = {}, {}
    for arm, model in models.items():
        np.testing.assert_array_equal(model.prototypes[:nh], route.historical)
        s_log, centroids[arm] = group(logits(data, model.prototypes[nh:]), xy[nh:])
        probs[arm] = expit(s_log - h_log)
    weights = position_weights(q['xy'])
    result = {}
    max_error = 0.
    for cell in CELLS:
        mass, conditional = cell
        pred = origin + h_xy + probs[mass][:, None] * (centroids[conditional] - h_xy)
        result[cell] = float(metre * (weights @ np.linalg.norm(pred-q['xy'], axis=1)))
        if mass == conditional:
            error = np.max(np.linalg.norm(pred-models[mass].predict(q['rss']), axis=1))*metre
            max_error = max(max_error, error)
    result.update(pS_F=float(weights @ probs['F']), pS_L=float(weights @ probs['L']),
                  mass_first=result['LF']-result['FF'], within_second=result['LL']-result['LF'],
                  L_minus_F=result['LL']-result['FF'],
                  interaction=result['LL']-result['LF']-result['FL']+result['FF'])
    return result, max_error


def episodes(a):
    sys.path.insert(0, str(a.original))
    from replay import ALLOW, R1, R2, UNIT, axishash, canonical, digest, extract
    spec = json.loads((a.design/'protocol.json').read_text())
    assert digest((a.design/'protocol.json').read_bytes()) == 'b7b5483b7c401ecb9ee5061c64021bbf3fb3f293c0f8ac25ffe414295c6c2e1d'
    assert digest(a.archive.read_bytes()) == spec['input_archive_sha256']
    manifest = (a.design/'route_manifest.json').read_bytes()
    assert digest(manifest) == spec['manifest_sha256']
    blob = (a.design/'scan_metadata.json.gz').read_bytes()
    plain = gzip.decompress(blob)
    assert digest(blob) == spec['scan_metadata_sha256'] and digest(plain) == spec['scan_metadata_plain_sha256']
    meta = {r['id']: r for r in json.loads(plain) if r['file'] in (R1, R2)}
    files = {r['member']: r for r in spec['allowed_members'] if r['member'] in ALLOW}
    data = {}
    with ZipFile(a.archive) as archive:
        for path in sorted(ALLOW):
            data.update(extract(archive, path, files[path], meta))
    assert data.keys() == meta.keys()
    for floor in (r for r in json.loads(manifest) if r['site'] == 'UJITI'):
        f = floor['floor']
        groups = sorted((int(n), ids) for n, ids in floor['H_by_floor'].items())
        hids = [i for _, items in groups for i in items]
        queries = floor['ordered_Q_ids']
        ids = hids + queries + floor['eligible_target_S_ids']
        xy = {i: ((meta[i]['lon']-floor['lon0'])*floor['east_m_per_degree'],
                  (meta[i]['lat']-floor['lat0'])*111320.) for i in ids}
        assert digest(canonical([(i, xy[i][0].hex(), xy[i][1].hex()) for i in sorted(xy)])) == floor['coordinate_frame_sha256']
        hseen = set().union(*(data[i] for i in hids))
        gaps = [abs(n-f) for n, _ in groups]
        for draw in floor['draws']:
            for k in KS:
                rows = draw['ordered_S_scan_ids'][:k]
                aps = sorted(hseen.union(*(data[i] for i in rows)))
                assert axishash(aps) == draw['permitted_AP_axis'][str(k)]['sha256']
                columns = {ap: j for j, ap in enumerate(aps)}
                def pack(ids):
                    r = np.full((len(ids), len(aps)), 100.)
                    for j, i in enumerate(ids):
                        for ap, val in data[i].items():
                            if ap in columns:
                                r[j, columns[ap]] = val
                    return dict(rss=r, xy=np.array([xy[i] for i in ids]) / UNIT)
                h = [pack(items) for _, items in groups]
                route = fit_anchor_readout(h, pack(rows), floor_gaps=gaps)
                yield (f, draw['draw'], k), route, pack(queries), UNIT


def summary(rows):
    rng = np.random.default_rng(261101)
    stats = []
    point, boot = [], []
    def add(floor, est, samples):
        entries = [(str(k), est[i], samples[:, i]) for i, k in enumerate(KS)]
        entries.extend([('mean_K', est.mean(0), samples.mean(1)), ('K20_minus_K5', est[4]-est[2], samples[:,4]-samples[:,2])])
        for k, value, resamples in entries:
            for j, name in enumerate(MEASURES):
                low, high=np.quantile(resamples[:,j], [.025,.975])
                stats.append(dict(floor=floor, K=k, quantity=name, estimate=value[j], lo95=low, hi95=high))
    for f, part in rows.groupby('floor', sort=True):
        matrix=part.sort_values(['draw','K'])[list(MEASURES)].to_numpy().reshape((40,5,len(MEASURES)))
        estimate=matrix.mean(0)
        samples=matrix[rng.integers(40,size=(10000,40))].mean(1)
        add(f, estimate, samples)
        point.append(estimate)
        boot.append(samples)
    add('all', np.mean(point,0), np.mean(boot,0))
    return pd.DataFrame(stats)


def run(a):
    import hashlib
    fit_blob = a.fit.read_bytes()
    assert hashlib.sha256(fit_blob).hexdigest() == 'ed3ae84fd08d2286b7c754937d0d1c50b9304e8c339c3a3a5487689eea481162'
    lookup = json.loads(fit_blob)['g_by_K']
    keys = ['floor','draw','K']
    scored = pd.read_csv(a.out/'events.csv').set_index(keys)
    records = []
    count = 0
    max_error = 0.
    for key, route, q, units in episodes(a):
        f,d,k = key
        result, endpoint_error = separate(route, lookup[str(k)], q, units)
        np.testing.assert_allclose([result['FF'], result['LL']], scored.loc[key,['fixed100','source_K']],
                                   rtol=0., atol=1e-9)
        assert abs(result['mass_first'] + result['within_second'] - result['L_minus_F']) < 1e-12
        records.append(dict(floor=f, draw=d, K=k, **result))
        count += len(q['xy'])
        max_error = max(max_error, endpoint_error)
    rows = pd.DataFrame(records)
    assert rows.set_index(keys).index.equals(scored.index) and len(rows)==600
    assert count == 22600 and max_error < 1e-9
    rows.to_csv(a.out/'mass_order_events.csv.gz', index=False)
    summary(rows).to_csv(a.out/'mass_order_summary.csv', index=False)
    receipt = dict(events=len(rows),query_exposures=count,max_endpoint_reconstruction_m=max_error,
                   baseline='F fully field-predicted; L=immutable library g[K]. Group labels refer to appended rows vs historical rows.',
                   path='FF -> LF changes total S mass; LF -> LL changes within-S distribution. FL is the reverse-path cell. Interaction=LL-LF-FL+FF.',
                   interpretation='Error changes depend on the path because Euclidean error is nonlinear. All comparisons conditional on fixed route, query locations and floor weights.')
    (a.out/'mass_order_receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('archive','design','fit','original','out'):
        parser.add_argument(name,type=Path)
    run(parser.parse_args())
