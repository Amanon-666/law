from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import joblib
import numpy as np
from candidates.scale_gamma_20261111.frozen_hurdle_translator import FrozenHurdleTranslator

root = Path.cwd()
source = root/'results/claude_hurdle_b0_scale_gamma_ens5_20261111_source'
base_path = root/'results/claude_hurdle_b0_ens5_20261110'
new_path = root/'results/claude_hurdle_b0_scale_gamma_ens5_20261111'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
result = dict(passed=False, created=datetime.now(timezone.utc).isoformat(),
    base_freeze_sha256=sha(base_path/'freeze.json'), new_freeze_sha256=sha(new_path/'freeze.json'),
    checked_seeds=[], reader_loaded=False, seeds=[], deployment_prediction_calls=0,
    additional_fits=0, verification_code_sha256=sha(Path(__file__)))
try:
    original = FrozenHurdleTranslator(base_path)
    candidate = FrozenHurdleTranslator(new_path)
    result['reader_loaded'] = True
    assert candidate.scale_output == 'variance'
    assert [m['seed'] for m in original.models] == [1,2,3,4,5]
    assert [m['seed'] for m in candidate.models] == [1,2,3,4,5]
    for old, new in zip(original.models, candidate.models):
        hashes = {name: dict(base=joblib.hash(old[name]),new=joblib.hash(new[name])) for name in ('det','mean')}
        old_parameters = old['scale']['estimator'].get_params()
        new_parameters = new['scale']['estimator'].get_params()
        assert old_parameters['loss'] == 'squared_error' and new_parameters['loss'] == 'gamma'
        old_parameters['loss'] = 'gamma'
        row = dict(seed=old['seed'],det_state_equal=hashes['det']['base']==hashes['det']['new'],
            mean_state_equal=hashes['mean']['base']==hashes['mean']['new'],
            model_cols_equal=bool(np.array_equal(old['cols'],new['cols'])),
            scale_cols_equal=bool(np.array_equal(old['scale']['cols'],new['scale']['cols'])),
            scale_parameters_equal_except_loss=old_parameters==new_parameters,
            scale_output=new['scale_output'],state_hashes=hashes)
        result['seeds'].append(row)
        result['checked_seeds'].append(old['seed'])
    fields=('det_state_equal','mean_state_equal','model_cols_equal','scale_cols_equal','scale_parameters_equal_except_loss')
    result['passed'] = result['reader_loaded'] and result['checked_seeds']==[1,2,3,4,5] and all(row[name] for row in result['seeds'] for name in fields)
finally:
    (new_path/'inheritance_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert result['passed']
