#!/bin/bash
set -u
cd /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031
export PYTHONPATH=/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2 CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
trace_dir=results/ipin2025_positive_evidence_20261111_source
printf '%s\n' "$$" > "$trace_dir/driver.pid"
run_stage() {
  local stage_name="$1"
  shift
  date -u +%FT%TZ > "$trace_dir/$stage_name.started"
  /usr/bin/time -v -o "$trace_dir/$stage_name.resources.txt" nice -n 10 timeout --signal=TERM --kill-after=5s 900s /home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u -B -m candidates.positive_evidence_ipin2025_20261111 "$@" --seconds 780 > "$trace_dir/$stage_name.log" 2>&1
  local stage_rc=$?
  printf '%s\n' "$stage_rc" > "$trace_dir/$stage_name.exit.status"
  date -u +%FT%TZ > "$trace_dir/$stage_name.ended"
  printf '%s exit=%s\n' "$stage_name" "$stage_rc"
  return "$stage_rc"
}
run_stage freeze freeze
run_rc=$?
if [ "$run_rc" != 0 ]; then exit "$run_rc"; fi
run_stage predict predict
run_rc=$?
if [ "$run_rc" = 2 ]; then
  run_stage predict_resume1 predict --resume
  run_rc=$?
fi
if [ "$run_rc" != 0 ]; then exit "$run_rc"; fi
run_stage score score
run_rc=$?
printf '%s\n' "$run_rc" > "$trace_dir/run.exit.status"
exit "$run_rc"
