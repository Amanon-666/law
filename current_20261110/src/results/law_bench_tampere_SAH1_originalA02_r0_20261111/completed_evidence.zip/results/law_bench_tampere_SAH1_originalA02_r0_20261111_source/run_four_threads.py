"""Explicit resource-only override around the unchanged benchmark main entry."""
import os,sys,json,hashlib
from pathlib import Path
PREP=Path(__file__).resolve().parent
sys.path.insert(0,str(PREP/'source_snapshot'))
import frozen_hurdle_translator as F
from law_bench import run as R
import sklearn.ensemble
from threadpoolctl import threadpool_info,threadpool_limits
assert Path(F.__file__).resolve()==PREP/'source_snapshot/frozen_hurdle_translator.py'
floor=int(sys.argv[sys.argv.index('--floors')+1]);out=Path(sys.argv[sys.argv.index('--output')+1]);segment=os.environ['LAW_EXECUTION_SEGMENT']
pending=[]
for method in ('wknn_S','wknn_HS','original_A'):
 for k in (1,3,5):
  task=f'tampere/SAH1/F{floor}/K{k}/r0';p=out/'events'/method/(task+'.json')
  if not p.exists() or json.loads(p.read_text())['status']!='completed':pending.append(dict(method=method,task_id=task))
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='4'
with threadpool_limits(limits=4):
 info=dict(CPU_threads=4,effective_threadpools=threadpool_info(),pending_events=pending,wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),snapshot_run_sha256=hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest(),resource_change_only=True)
 (PREP/f'{segment}.threadpools.json').write_text(json.dumps(info,indent=2)+'\n')
 print('threadpools',json.dumps(info),flush=True)
 R.main()
