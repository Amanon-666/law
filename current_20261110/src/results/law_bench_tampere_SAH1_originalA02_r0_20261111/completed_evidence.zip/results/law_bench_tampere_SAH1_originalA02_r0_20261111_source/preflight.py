import sys,json
from pathlib import Path
import numpy as np
ROOT=Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
PREP=ROOT/'results/law_bench_tampere_SAH1_originalA02_r0_20261111_source'
SNAP=PREP/'source_snapshot';sys.path.insert(0,str(SNAP))
from law_bench.data import load
from law_bench.protocol import make_tasks
from law_bench.run import _data_identity,_method,_write,_sha
read=lambda p:json.loads(p.read_text())
assets=ROOT/'results/claude_hurdle_sources02_ens5_20261111'
freeze=read(assets/'freeze.json');complete=read(assets/'complete.json')
assert complete['complete'] and complete['freeze_sha256']==_sha(assets/'freeze.json')=='f852bd606eb1e1e67e5a2e965aa4f86f3da0ed3128bcc865b018fcc1562e0bd3'
options=dict(original_A=dict(generation_dir=str(assets),freeze_sha256=complete['freeze_sha256']))
_write(PREP/'method_options.json',options)
target,aps=load('tampere');source,source_aps=load('uji')
assert sorted(target['SAH1'])==[1,2,3] and len(aps['SAH1'])==775
sources=[dict(dataset='uji',building=b,floors=source[b],ap_ids=source_aps[b]) for b in ('B0','B2')]
model=_method('original_A',options,ROOT/'results/law_bench_tampere_SAH1_originalA02_F2_r0_20261111');model.fit_source(sources)
checks=[]
for floor in (1,2,3):
 for task,truth in make_tasks('tampere','SAH1',target['SAH1'],aps['SAH1'],floor,budgets=(1,3,5),repeat=0,seed=20261111,R=3,query_positions=60):
  assert task.meta['support_scans_per_position']==[1]*task.K and len(truth['row_indices'])==60
  assert not task.meta['acquisition_separated']
  checks.append(dict(task_id=task.task_id,meta=task.meta,H_rows={str(f):len(h['rss']) for f,h in task.H.items()},support_rows=len(task.S['rss']),query_rows=truth['row_indices'].tolist(),query_groups=truth['groups'].tolist()))
frame=Path('/home/panyushuo/projects/panyushuo/multifloor-check-20261026/results/frame_check.log')
paths=[assets/'freeze.json',assets/'complete.json',SNAP/'frozen_hurdle_translator.py',frame,*sorted((SNAP/'law_bench').glob('*.py'))]
_write(PREP/'preflight.json',dict(complete=True,target_data=_data_identity({'SAH1':target['SAH1']},{'SAH1':aps['SAH1']}),
 source_data=_data_identity({b:source[b] for b in ('B0','B2')},source_aps),tasks=checks,
 target_floors={str(f):dict(rows=len(d['rss']),positions=len(np.unique(d['xy'],axis=0)),AP_columns=d['rss'].shape[1]) for f,d in target['SAH1'].items()},
 inputs_code_sha256={str(p):_sha(p) for p in paths},
 protocol='Static recorded-position resampling, R requested3 actual1, acquisition identity unknown; already studied data, no cross-device or blind-test claim',
 frame='Original shared XY metres, no fitted registration. Layers1/2/3 have Z0/3.5/7; model consumes layer-index differences only.',
 scope='Original full55 features, original five states and full H/S candidates; no source training or GP fitting',evaluation_started=False))
print(json.dumps(dict(preflight=True,tasks=len(checks),floors={str(f):len(d['rss']) for f,d in target['SAH1'].items()})))
