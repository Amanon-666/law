#!/usr/bin/env bash
floor=$1
segment=$2
resume_flag=$3
export LAW_EXECUTION_SEGMENT="$segment"
core=/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031
prep="$core/results/law_bench_tampere_SAH1_originalA02_r0_20261111_source"
cd "$prep/source_snapshot" || exit 1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2 CUDA_VISIBLE_DEVICES= PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1
export PYTHONPATH=/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages:$core
start=$(date -u +%Y-%m-%dT%H:%M:%SZ)
start_epoch=$(date +%s)
/usr/bin/time -v -o "$prep/${segment}.resources.txt" timeout --signal=TERM --kill-after=5s 895s /home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u "$prep/run_four_threads.py" --dataset tampere --building SAH1 --source-dataset uji --source-buildings B0 B2 --floors "$floor" --budgets 1 3 5 --repeats 0 --R 3 --query-positions 60 --seed 20261111 --methods wknn_S wknn_HS original_A --method-options "$prep/method_options.json" --output "$core/results/law_bench_tampere_SAH1_originalA02_F${floor}_r0_20261111" $resume_flag &
child=$!
printf '{"floor":%s,"runner_pid":%s,"time_pid":%s,"started_at":"%s","state":"running","outer_timeout_seconds":900}\n' "$floor" "$$" "$child" "$start" > "$prep/${segment}.runtime.json"
wait "$child"
code=$?
end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
end_epoch=$(date +%s)
/usr/bin/python3 - "$prep" "$segment" "$floor" "$$" "$child" "$start" "$end" "$code" "$((end_epoch-start_epoch))" <<'PY'
import sys,json,re
from pathlib import Path
prep=Path(sys.argv[1]);segment=sys.argv[2];floor,runner,child=map(int,sys.argv[3:6]);start,end=sys.argv[6:8];code,seconds=map(int,sys.argv[8:])
text=(prep/f'{segment}.resources.txt').read_text();m=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text)
(prep/f'{segment}.runtime.json').write_text(json.dumps(dict(floor=floor,runner_pid=runner,time_pid=child,started_at=start,ended_at=end,exit_code=code,elapsed_seconds=seconds,state='exited',outer_timeout_seconds=900,peak_RSS_kbytes=int(m.group(1)) if m else None),indent=2)+'\n')
PY
exit "$code"
