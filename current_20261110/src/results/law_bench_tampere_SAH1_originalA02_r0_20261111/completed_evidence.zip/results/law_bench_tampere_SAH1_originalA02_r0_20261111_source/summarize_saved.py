"""Aggregate the original frozen SAH1 runs and their actual execution segments."""
import sys,json,re
from pathlib import Path
import numpy as np
ROOT=Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
PREP=ROOT/'results/law_bench_tampere_SAH1_originalA02_r0_20261111_source'
OUT=ROOT/'results/law_bench_tampere_SAH1_originalA02_r0_20261111'
sys.path.insert(0,str(PREP/'source_snapshot'))
from law_bench.score import aggregate
from law_bench.run import _write,_sha
read=lambda p:json.loads(p.read_text())
records={name:[] for name in ('wknn_S','wknn_HS','original_A')};inputs=[PREP/'preflight.json']
for floor in (1,2,3):
 folder=ROOT/f'results/law_bench_tampere_SAH1_originalA02_F{floor}_r0_20261111'
 inputs.append(folder/'freeze.json')
 for k in (1,3,5):
  task=f'tampere/SAH1/F{floor}/K{k}/r0'
  group={}
  for name in records:
   p=folder/'events'/name/(task+'.json')
   if p.exists():
    r=read(p);inputs.append(p);group[name]=r
    records[name].append({v:r[v] for v in ('task_id','floor','K','repeat','status','scores','seconds') if v in r})
   else:records[name].append(dict(task_id=task,floor=floor,K=k,repeat=0,status='not_completed'))
  if len(group)==3:
   a=group['original_A']
   for r in group.values():assert r['query_row_indices']==a['query_row_indices'] and r['query_groups']==a['query_groups'] and r['meta']==a['meta']
common=set.intersection(*[{r['task_id'] for r in rs if r['status']=='completed'} for rs in records.values()])
def summary(rs):
 done=[r for r in rs if r['status']=='completed'];errors=[e for r in done for e in r['scores']['position_errors']]
 return dict(requested_tasks=len(rs),completed_tasks=len(done),complete=len(rs)==len(done),mean=float(np.mean(errors)) if errors else None,
 p90=float(np.quantile(errors,.9)) if errors else None,by_K=aggregate(rs))
segments=[]
for p in sorted(PREP.glob('F*.runtime.json')):
 r=read(p);txt=p.with_name(p.name.replace('.runtime.json','.resources.txt'))
 if txt.exists():
  s=txt.read_text()
  r['CPU_user_seconds']=float(re.search(r'User time \(seconds\):\s*([\d.]+)',s).group(1))
  r['CPU_system_seconds']=float(re.search(r'System time \(seconds\):\s*([\d.]+)',s).group(1))
 r['segment']=p.name.removesuffix('.runtime.json');r['record_path']=str(p);inputs.append(p)
 tp=p.with_name(p.name.replace('.runtime.json','.threadpools.json'))
 if tp.exists():r['thread_configuration']=read(tp);inputs.append(tp)
 else:r['thread_configuration']=dict(CPU_threads=2)
 segments.append(r)
gp_prep=ROOT/'results/law_bench_tampere_SAH1_legacyGP_F2_r0_20261111_source'
gp_runtime=read(gp_prep/'F2.runtime.json');gp_text=(gp_prep/'F2.resources.txt').read_text()
gp_runtime['CPU_seconds']=sum(float(re.search(label+r' time \(seconds\):\s*([\d.]+)',gp_text).group(1)) for label in ('User','System'))
inputs.append(gp_prep/'F2.runtime.json')
f2=ROOT/'results/law_bench_tampere_SAH1_legacyGP_F2_r0_20261111/F2_comparison.json';inputs.append(f2)
_write(OUT/'task_scores.json',records)
_write(OUT/'comparison.json',dict(complete=all(summary(rs)['complete'] for rs in records.values()),methods={n:summary(rs) for n,rs in records.items()},
 by_floor={str(f):{n:summary([r for r in rs if r['floor']==f]) for n,rs in records.items()} for f in (1,2,3)},
 common_completed_tasks=dict(task_ids=sorted(common),methods={n:summary([r for r in rs if r['task_id'] in common]) for n,rs in records.items()}),
 F2_existing_GP_and_coordinate_control=read(f2),execution_segments=segments,
 cumulative_wall_seconds=sum(r['elapsed_seconds'] for r in segments),
 cumulative_CPU_seconds=sum(r.get('CPU_user_seconds',0)+r.get('CPU_system_seconds',0) for r in segments),
 peak_RSS_kbytes=max(r['peak_RSS_kbytes'] for r in segments),GP_execution=gp_runtime,
 total_A_and_GP_wall_seconds=sum(r['elapsed_seconds'] for r in segments)+gp_runtime['elapsed_seconds'],
 total_A_and_GP_CPU_seconds=sum(r.get('CPU_user_seconds',0)+r.get('CPU_system_seconds',0) for r in segments)+gp_runtime['CPU_seconds'],
 identity='Fixed original five-model HurdleField trained on UJI B0+B2, unmodified55 features and full H/S candidate atoms; resource-only thread override on recorded resumed/later events',
 scope='External SAH1, already studied data, static recorded-position resampling, actualR1, acquisitions unknown, fixed same Query across K. Not cross-device or blind validation.',
 boundaries='GP available only F2:4m aggregation of all3998 H scans and B0-only fitted parameters. Coordinate_half is fixed saved-coordinate averaging, not a log-score probability pool.',
 inputs_sha256={str(p):_sha(p) for p in inputs},code_sha256=_sha(__file__),new_training=0,new_history_fits=0))
_write(OUT/'complete.json',dict(complete=all(summary(rs)['complete'] for rs in records.values()),expected_tasks=9,
 completed_tasks={n:sum(r['status']=='completed' for r in rs) for n,rs in records.items()},comparison_sha256=_sha(OUT/'comparison.json')))
print(json.dumps(dict(complete=all(summary(rs)['complete'] for rs in records.values()),methods={n:summary(rs) for n,rs in records.items()})))
