import sys,json
from pathlib import Path
import numpy as np
ROOT=Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
PREP=ROOT/'results/law_bench_tampere_SAH1_legacyGP_F2_r0_20261111_source'
OUT=ROOT/'results/law_bench_tampere_SAH1_legacyGP_F2_r0_20261111'
A=ROOT/'results/law_bench_tampere_SAH1_originalA02_F2_r0_20261111'
sys.path.insert(0,str(PREP/'source_snapshot'))
from law_bench.data import load
from law_bench.score import score,aggregate
from law_bench.run import _write,_sha
read=lambda p:json.loads(p.read_text())
buildings,_=load('tampere');records={name:[] for name in ('wknn_S','wknn_HS','original_A02','legacy_GP','coordinate_half')};inputs=[A/'freeze.json',OUT/'freeze.json']
for k in (1,3,5):
 task=f'tampere/SAH1/F2/K{k}/r0'
 ap=A/'events/original_A'/(task+'.json');gp=OUT/'events/tampere_legacy_gp'/(task+'.json')
 a,g=read(ap),read(gp);inputs.extend([ap,gp]);assert a['status']==g['status']=='completed'
 assert a['query_row_indices']==g['query_row_indices'] and a['query_groups']==g['query_groups'] and a['meta']==g['meta']
 truth=dict(xy=buildings['SAH1'][2]['xy'][a['query_row_indices']],groups=np.asarray(a['query_groups']))
 half=.5*(np.asarray(a['prediction'])+np.asarray(g['prediction']))
 for method,pred in [('original_A02',a['prediction']),('legacy_GP',g['prediction']),('coordinate_half',half)]:
  records[method].append(dict(task_id=task,floor=2,K=k,repeat=0,status='completed',scores=score(pred,truth),prediction=np.asarray(pred).tolist(),query_row_indices=a['query_row_indices'],query_groups=a['query_groups']))
 for method in ('wknn_S','wknn_HS'):
  p=A/'events'/method/(task+'.json');r=read(p);inputs.append(p)
  assert r['query_row_indices']==a['query_row_indices'] and r['query_groups']==a['query_groups']
  records[method].append(r)
summary={}
for method,rs in records.items():
 errors=[v for r in rs for v in r['scores']['position_errors']]
 summary[method]=dict(tasks=3,mean=float(np.mean(errors)),p90=float(np.quantile(errors,.9)),by_K=aggregate(rs))
_write(OUT/'F2_same_output_scores.json',records)
_write(OUT/'F2_comparison.json',dict(complete=True,methods=summary,coordinate_half='.5*(saved original A02 projected + saved original GP posterior mean); fixed coordinate combination',
 identities=dict(A='Original B0+B2 five-model HurdleField, full55 features/full candidate positions',GP='Original4m aggregation of all3998 H scans, existing756 fields and B0-source parameters',sources='A uses B0+B2 training; GP parameters fitted only B0 F0-F2'),
 scope='SAH1 F2 static recorded-position resampling, actualR1, unknown acquisition/device identity, already studied external dataset',
 new_A_GP_inference_calls=0,inputs_sha256={str(p):_sha(p) for p in inputs},code_sha256=_sha(__file__)))
print(json.dumps({k:{n:v[n] for n in ('mean','p90')} for k,v in summary.items()}))
