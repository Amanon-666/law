import sys,json
from pathlib import Path
ROOT=Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
PREP=ROOT/'results/law_bench_tampere_SAH1_legacyGP_F2_r0_20261111_source'
sys.path.insert(0,str(PREP/'source_snapshot'))
from law_bench.method_tampere_legacy_gp import TampereLegacyGP,LEGACY_ROOT,PARAMETERS_SHA,CODE_SHA
from law_bench.data import load
from law_bench.protocol import make_tasks
from law_bench.run import _sha,_write
import pypmc
b,aps=load('tampere');u,ua=load('uji')
model=TampereLegacyGP();model.fit_source([dict(dataset='uji',building=n,floors=u[n],ap_ids=ua[n]) for n in ('B0','B2')])
checks=[]
for task,truth in make_tasks('tampere','SAH1',b['SAH1'],aps['SAH1'],2,budgets=(1,3,5),repeat=0,seed=20261111,R=3,query_positions=60):
 for method in ('original_A','wknn_S','wknn_HS'):
  p=ROOT/'results/law_bench_tampere_SAH1_originalA02_F2_r0_20261111/events'/method/(task.task_id+'.json')
  r=json.loads(p.read_text());assert r['status']=='completed' and task.meta==r['meta']
  assert r['query_row_indices']==truth['row_indices'].tolist() and r['query_groups']==truth['groups'].tolist()
 checks.append(dict(task_id=task.task_id,same_Query_rows_groups_meta=True))
_write(PREP/'preflight.json',dict(complete=True,tasks=checks,parameters_sha256=PARAMETERS_SHA,legacy_code_sha256=CODE_SHA,
 code_sha256={str(p):_sha(p) for p in (PREP/'source_snapshot/law_bench/run.py',PREP/'source_snapshot/law_bench/method_tampere_legacy_gp.py')},
 pypmc_path=pypmc.__file__,identity='Original 4m aggregation of all3998 raw H scans, existing756 fields, original UJI B0 parameters and M-PMC; not raw-position full-H GP',
 evaluation_started=False,history_fits=0,model_training=0))
print('GP preflight complete')
