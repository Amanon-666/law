"""Reaggregate saved errors only, retaining the original position/hierarchy weights."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from hurdle_gp_pool_trial import METHODS

read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
OUT = ROOT/'results/uji54_count_conditioned_20261111'
paths = dict(original=ROOT/'results/hurdle_gp_pool_20261110/complete.json', count_conditioned=OUT/'complete.json')
manifest = read(ROOT/'results/building_information_assets_20261109/manifest.json')
events = {e['id']: e for e in manifest['events']}
versions = {}
paired_keys = None
for label, path in paths.items():
    complete = read(path)
    assert complete['complete'] and len(complete['records']) == 54
    samples = []
    for record in complete['records']:
        event = events[record['event']]
        scored = ROOT/record['scored_path']
        assert sha(scored) == record['scored_sha256']
        with np.load(scored, allow_pickle=False) as saved:
            xy, group = np.unique(saved['truth'], axis=0, return_inverse=True)
            group = group.ravel()
            errors = {m: np.bincount(group, weights=saved[m])/np.bincount(group) for m in METHODS}
        nf = sum(f.startswith(event['building']) for f in manifest['floors'])
        samples.append(dict(event=event, xy=xy, errors=errors, weight=.5/nf/2/3/len(xy)))
    def aggregate(selected, method):
        values = np.concatenate([s['errors'][method] for s in selected])
        weights = np.concatenate([np.full(len(s['xy']), s['weight']) for s in selected])
        weights /= weights.sum()
        order = np.argsort(values)
        return dict(mean=float(weights@values), position_mean_p90=float(values[order[np.searchsorted(np.cumsum(weights[order]), .9)]]))
    for method in METHODS:
        actual = aggregate(samples, method)
        assert all(abs(actual[k]-complete['summary'][method][k]) < 1e-10 for k in actual)
    groups = {}
    for floor in ['overall', *manifest['floors']]:
        selected = [s for s in samples if floor == 'overall' or s['event']['floor'] == floor]
        entry = dict(methods={})
        pairing = {k:{} for k in (1,3,5)}
        query_bindings = {}
        for sample in selected:
            e = sample['event']
            task = (e['floor'], e['direction'])
            if task in query_bindings:
                assert query_bindings[task] == e['query_rows']
            query_bindings[task] = e['query_rows']
            for i, xy in enumerate(sample['xy']):
                key = (*task, *xy)
                pairing[e['K']][key] = {m: float(sample['errors'][m][i]) for m in METHODS}
        assert pairing[1].keys() == pairing[3].keys() == pairing[5].keys()
        entry['paired_positions'] = len(pairing[1])
        for method in METHODS:
            by_k = {str(k): aggregate([s for s in selected if s['event']['K'] == k], method) for k in (1,3,5)}
            deltas = [pairing[5][key][method]-pairing[1][key][method] for key in pairing[1]]
            entry['methods'][method] = dict(by_K=by_k, K1_to_K5=dict(
                improved=sum(v < 0 for v in deltas), worsened=sum(v > 0 for v in deltas), tied=sum(v == 0 for v in deltas),
                hierarchical_mean_delta=by_k['5']['mean']-by_k['1']['mean'], position_mean_p90_delta=by_k['5']['position_mean_p90']-by_k['1']['position_mean_p90']))
        groups[floor] = entry
        if floor == 'overall':
            keys = set(pairing[1])
            if paired_keys is not None:
                assert keys == paired_keys
            paired_keys = keys
    versions[label] = groups
result = dict(complete=True, created=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status='Existing saved-error reaggregation only, no predictions/fits/statistical tests',
    pairing='Same floor, acquisition direction and exact query position across K; identical query row lists checked',
    metric='Original scan error averaged within position, original equal-building/floor/direction/K/position hierarchy; p90 is weighted inverse empirical CDF',
    count_definition='Unweighted counts of paired floor/direction/positions; K5 minus K1 strictly below/above zero means improved/worsened, no pointwise monotonicity requirement',
    inputs={label:dict(path=str(path),sha256=sha(path)) for label,path in paths.items()},
    computation_source=dict(path=str(Path(__file__)),sha256=sha(Path(__file__))), versions=versions)
(OUT/'paired_K.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print('Paired query positions',len(paired_keys))
print('Current overall', json.dumps(versions['count_conditioned']['overall']))
