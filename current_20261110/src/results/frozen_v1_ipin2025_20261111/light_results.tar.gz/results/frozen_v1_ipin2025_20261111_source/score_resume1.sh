#!/bin/bash
cd /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031
export PYTHONPATH=/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2 CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
date -u +%FT%TZ > /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/frozen_v1_ipin2025_20261111_source/score_resume1.started
/usr/bin/time -v -o /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/frozen_v1_ipin2025_20261111_source/score_resume1.resources.txt nice -n 10 timeout --signal=TERM --kill-after=5s 900s /home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u -m candidates.frozen_v1_ipin2025_20261111 score --output /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/frozen_v1_ipin2025_20261111 --seconds 780 --resume
run_rc=$?
printf "%s\n" "$run_rc" > /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/frozen_v1_ipin2025_20261111_source/score_resume1.exit.status
date -u +%FT%TZ > /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/frozen_v1_ipin2025_20261111_source/score_resume1.ended
exit "$run_rc"
