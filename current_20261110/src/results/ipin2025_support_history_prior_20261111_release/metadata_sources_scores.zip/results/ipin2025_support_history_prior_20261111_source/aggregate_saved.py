"""Reuse IPIN saved-error pairing and summarize actual H-only count inputs."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import ipin2025_confirmation as original
read = lambda path: json.loads(Path(path).read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
OUT = ROOT/'results/ipin2025_support_history_prior_20261111'
paths = dict(original=ROOT/'results/ipin2025_confirmation_20261110/scores.json', support_history_prior=OUT/'scores.json')
scores = {label:read(path) for label,path in paths.items()}
indexed = {label:{k:{(row['log_id'],row['gt_row']):row for row in data['points'] if row['K']==k} for k in (1,3,5)} for label,data in scores.items()}
keys = set(indexed['original'][1])
assert len(keys)==102
for label in indexed:
    for k in (1,3,5):
        assert set(indexed[label][k])==keys
        for key in keys:
            a,b = indexed[label][k][key], indexed['original'][1][key]
            assert a['covered'] and (a['floor'],a['time'])==(b['floor'],b['time'])
methods = scores['original']['methods']
versions = {}
for label,data in scores.items():
    groups = {}
    for group in ['overall', *map(str, sorted({r['floor'] for r in indexed[label][1].values()}))]:
        selected = sorted(key for key in keys if group=='overall' or indexed[label][1][key]['floor']==int(group))
        entry = dict(points=len(selected), methods={})
        for method in methods:
            by_k = {}
            for k in (1,3,5):
                summary = data['by_K'][str(k)]['overall'] if group=='overall' else data['by_K'][str(k)]['by_floor'][group]
                value = summary['methods'][method]
                assert value['count']==len(selected)
                by_k[str(k)] = {name:value[name] for name in ('count','mean','p90')}
            delta = [indexed[label][5][key]['errors'][method]-indexed[label][1][key]['errors'][method] for key in selected]
            entry['methods'][method] = dict(by_K=by_k,K1_to_K5=dict(improved=sum(x<0 for x in delta),worsened=sum(x>0 for x in delta),tied=sum(x==0 for x in delta),mean_error_delta=by_k['5']['mean']-by_k['1']['mean'],p90_error_delta=by_k['5']['p90']-by_k['1']['p90']))
        groups[group] = entry
    versions[label] = groups
paired = dict(complete=True,created=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='Saved-error reaggregation only',pairing=['log_id','gt_row'],point_count=102,K=[1,3,5],methods=methods,metric='Existing point-weighted mean and inverse-empirical-CDF p90, metres',change_definition='K5 minus K1, strictly negative/positive means improvement/worsening; descriptive counts, not pointwise monotonicity',inputs={label:dict(path=str(path),sha256=sha(path)) for label,path in paths.items()},versions=versions)
(OUT/'paired_K.json').write_text(json.dumps(paired,indent=2)+'\n')
checks = read(OUT/'support_prior_checks.json')
manifest = read(original.ASSETS/'manifest.json')
counts = {}
for record in read(OUT/'contexts_complete.json')['contexts']:
    histories,support,ap_ids = original.context(manifest,record['floor'],record['K'])
    detail = checks['contexts'][record['event']]
    complete = read(record['path'])
    with np.load(complete['hurdle']['path'],allow_pickle=False) as field:
        aps = field['aps']
    nH = sum(len(h['rss']) for h in histories.values())
    dH = sum((h['rss'][:,aps]!=100).sum(0) for h in histories.values())
    p0 = (dH+.5)/(nH+1.)
    assert nH==detail['nH'] and np.isclose(p0.sum(),detail['prior_expected_detections'],rtol=0,atol=1e-10)
    counts[record['event']] = dict(nH=nH,H_rows_by_source=detail['H_rows_by_source'],AP_count=len(aps),H_detected_count_min=int(dH.min()),H_detected_count_max=int(dH.max()),zero_H_detected_APs=int((dH==0).sum()),p0_min=float(p0.min()),p0_max=float(p0.max()),prior_expected_detections=float(p0.sum()),support_candidates=detail['support_candidates'],support_rows_per_location=detail['support_rows_per_location'],max_p_change=detail['max_p_change'])
prior = dict(complete=True,created=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='Read-only summary of the same actual H/S arrays, no model predictions or field construction',source_check=dict(path=str(OUT/'support_prior_checks.json'),sha256=sha(OUT/'support_prior_checks.json')),contexts=counts)
(OUT/'support_prior_counts.json').write_text(json.dumps(prior,indent=2)+'\n')
print('H count range', min(x['nH'] for x in counts.values()), max(x['nH'] for x in counts.values()))
print('H detected count range', min(x['H_detected_count_min'] for x in counts.values()), max(x['H_detected_count_max'] for x in counts.values()))
print('p0 range', min(x['p0_min'] for x in counts.values()), max(x['p0_max'] for x in counts.values()))
print('Prior expected detections range',min(x['prior_expected_detections'] for x in counts.values()), max(x['prior_expected_detections'] for x in counts.values()))
print('Current paired K overall',json.dumps(versions['support_history_prior']['overall']))
