#!/bin/bash
cd /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031
export PYTHONPATH=/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2 CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
trace=results/uts_official_A02_20261111_source
printf '%s\n' "$$" > "$trace/baselines.pid"
date -u +%FT%TZ > "$trace/baselines.started"
/usr/bin/time -v -o "$trace/baselines.resources.txt" nice -n 10 timeout --signal=TERM --kill-after=5s 900s /home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u -B -m candidates.uts_official_evaluation_20261111 baselines > "$trace/baselines.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$trace/baselines.exit.status"
date -u +%FT%TZ > "$trace/baselines.ended"
cat "$trace/baselines.log"
exit "$rc"
