from pathlib import Path
import datetime
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
RESULT = ROOT/'results/ipin2025_finite_observation_20261111'
SOURCE = ROOT/'results/ipin2025_finite_observation_20261111_source'
BASELINE = ROOT/'results/ipin2025_confirmation_20261110'
MODELS = ROOT/'results/claude_hurdle_b0_finite_obs_ens5_20261111'
RELEASE = ROOT/'results/ipin2025_finite_observation_20261111_release'


def read(path):
    return json.loads(path.read_text())


def binding(path):
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)


RELEASE.mkdir(exist_ok=False)
check = read(SOURCE/'execution_check.json')
assert check['complete'] and check['contexts'] == 15 and check['streams'] == 30
for name, record in check['output_bindings'].items():
    assert binding(RESULT/name)['sha256'] == record['sha256']

predictions = read(RESULT/'predictions.json')['predictions']
archives = []
for k in (1, 3, 5):
    rows = [r for r in predictions if r['K'] == k]
    assert len(rows) == 10
    target = RELEASE/f'full_streams_K{k}.zip'
    members = []
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_STORED) as archive:
        for row in rows:
            path = Path(row['path'])
            item = binding(path)
            assert item['sha256'] == row['sha256']
            archive.write(path, path.name)
            members.append(dict(**item, member=path.name, log_id=row['log_id'], floor=row['floor'], K=k))
        archive.writestr('manifest.json', json.dumps(dict(K=k, files=members), indent=2)+'\n')
    assert target.stat().st_size <= 1_000_000
    archives.append(dict(**binding(target), role='Unmodified full stream predictions', K=k, files=members))

metadata = sorted(RESULT.rglob('*.json')) + sorted(p for p in SOURCE.rglob('*') if p.is_file())
metadata += [BASELINE/name for name in ('freeze.json', 'contexts_complete.json', 'predictions.json', 'scores.json', 'cached_readout_check.json', 'cached_readout_execution.json', 'training_readout_cost.json', 'query_stream_inventory.json')]
metadata += [Path(r['path']) for r in read(BASELINE/'contexts_complete.json')['contexts']]
metadata += sorted(MODELS.glob('*.json'))
metadata += sorted((ROOT/'results/ipin2025_count_conditioned_20261111').glob('*.json'))
for name in ('claude_hurdle_b0_finite_obs_ens5_20261111_source', 'claude_hurdle_b0_finite_obs_ens5_20261111_source_v2', 'claude_hurdle_b0_finite_obs_ens5_20261111_source_v3'):
    metadata += sorted(p for p in (ROOT/'results'/name).rglob('*') if p.is_file() and p.suffix != '.joblib')
metadata = list(dict.fromkeys(metadata))
server_inventory = []
for path in sorted(p for p in RESULT.rglob('*') if p.is_file()):
    role = 'server_only_probability_field' if path.name == 'hurdle.npz' else 'released_metadata_or_stream'
    server_inventory.append(dict(**binding(path), role=role))
manifest = dict(created=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status='Exposed IPIN post-hoc Finite-observation five-model recipe with the same exact count reader mechanism confirmation, no parameter selection',
    result=str(RESULT), source=str(SOURCE), original_baseline=str(BASELINE), candidate_models=str(MODELS),
    excluded='Original GP state/grid/fields, new 15 hurdle probability fields, trained model files remain at bound server paths',
    server_result_files=server_inventory,
    metadata_files=[dict(**binding(p), member=str(p.relative_to(ROOT))) for p in metadata])
metadata_manifest = RELEASE/'metadata_manifest.json'
metadata_manifest.write_text(json.dumps(manifest, indent=2)+'\n')
target = RELEASE/'metadata_sources_scores.zip'
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in metadata:
        archive.write(path, str(path.relative_to(ROOT)))
    archive.write(metadata_manifest, 'metadata_manifest.json')
archives.append(dict(**binding(target), role='Actual source, logs, metadata, both scored point results and full provenance'))
release = dict(complete=True, created=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    archives=archives, manifest=binding(metadata_manifest), models_included=False,
    GP_fields_included=False, hurdle_probability_fields_included=False)
(RELEASE/'release.json').write_text(json.dumps(release, indent=2)+'\n')
for record in archives:
    with zipfile.ZipFile(record['path']) as archive:
        assert archive.testzip() is None
    print(Path(record['path']).name, record['bytes'], record['sha256'])
