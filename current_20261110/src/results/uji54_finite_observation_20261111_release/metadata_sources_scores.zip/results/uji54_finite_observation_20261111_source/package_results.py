"""Archive full saved strict54 readouts and provenance, excluding model/field binaries."""
from pathlib import Path
import datetime
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'results/uji54_finite_observation_20261111'
SOURCE = ROOT/'results/uji54_finite_observation_20261111_source'
RELEASE = ROOT/'results/uji54_finite_observation_20261111_release'
read = lambda path: json.loads(path.read_text())

def binding(path):
    return dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)

complete = read(OUT/'complete.json')
assert complete['complete'] and len(complete['records']) == 54 and complete['parity']['passed']
RELEASE.mkdir(exist_ok=False)
archives = []
for k in (1,3,5):
    target = RELEASE/f'full_results_K{k}.zip'
    files = []
    records = [r for r in complete['records'] if r['K'] == k]
    assert len(records) == 18
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_STORED) as archive:
        for record in records:
            for kind in ('prediction','scored'):
                path = Path(record[kind+'_path'])
                item = binding(path)
                assert item['sha256'] == record[kind+'_sha256']
                archive.write(path,path.name)
                files.append(dict(**item,member=path.name,event=record['event'],floor=record['floor'],K=k,kind=kind))
        archive.writestr('manifest.json',json.dumps(dict(K=k,files=files),indent=2)+'\n')
    archives.append(dict(**binding(target),K=k,role='18 unmodified unscored and18 scored NPZ',files=files))

metadata = sorted(OUT.glob('*.json')) + sorted(p for p in SOURCE.rglob('*') if p.is_file())
for folder in ('uji54_count_conditioned_20261111','hurdle_gp_pool_20261110'):
    metadata += sorted((ROOT/'results'/folder).glob('*.json'))
models = ROOT/'results/claude_hurdle_b0_finite_obs_ens5_20261111'
metadata += [models/name for name in ('freeze.json','complete.json','portable_load.json','mode_coverage.json')]
metadata += [ROOT/'results/building_information_assets_20261109'/name for name in ('manifest.json','complete.json')]
metadata = list(dict.fromkeys(metadata))
fields = complete['fields']
manifest = dict(created=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status='Exposed strict54 retention comparison, unchanged original hierarchy and same exact count reader',
    original_server_output=str(OUT),model_freeze_sha256=complete['model_freeze_sha256'],
    field_binaries='Remain at original server paths; model files excluded',server_only_fields=fields,
    metadata_files=[dict(**binding(path),member=str(path.relative_to(ROOT))) for path in metadata])
manifest_path = RELEASE/'metadata_manifest.json'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
target = RELEASE/'metadata_sources_scores.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in metadata:
        archive.write(path,str(path.relative_to(ROOT)))
    archive.write(manifest_path,'metadata_manifest.json')
archives.append(dict(**binding(target),role='All comparison summaries, paired-K, actual sources/logs and provenance'))
release = dict(complete=True,created=datetime.datetime.now(datetime.timezone.utc).isoformat(),archives=archives,
    manifest=binding(manifest_path),models_included=False,field_binaries_included=False)
(RELEASE/'release.json').write_text(json.dumps(release,indent=2)+'\n')
for record in archives:
    with zipfile.ZipFile(record['path']) as archive:
        assert archive.testzip() is None
        assert not any(n.endswith('.joblib') or n.endswith('_field.npz') for n in archive.namelist())
    print(Path(record['path']).name,record['bytes'],record['sha256'])
