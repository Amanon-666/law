#!/bin/bash
cd /home/panyushuo/projects/panyushuo/paper_bench_wt/current_20261110/src
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2 CUDA_VISIBLE_DEVICES=''
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1
export PYTHONPATH=/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages
export VT_DIR=$PWD/claude_hurdle_20261110 LAW_UJI_CSV=/home/panyushuo/projects/panyushuo/UJIIndoorLoc/data/raw/UJIndoorLoc/trainingData.csv
/home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u -m paper_bench_20261111.ext_gp --dataset uji --building B0 --protocol static-resample-v2 --seed 20261111 --repeats 0 1 2 --budgets 1 3 5 --R 3 --query-positions 60 --methods refi_GP --method-options ../results/paper_uji_B0_ext_execution_20261111/options.json --output ../results/paper_uji_B0_ext_20261111 > ../results/paper_uji_B0_ext_execution_20261111/run.log 2>&1
status=$?
printf '%s\n' "$status" > ../results/paper_uji_B0_ext_execution_20261111/run.exit.status
exit "$status"
