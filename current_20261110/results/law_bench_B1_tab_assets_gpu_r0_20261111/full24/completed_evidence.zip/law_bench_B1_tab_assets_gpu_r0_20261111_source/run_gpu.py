import json,hashlib,sys,signal
from pathlib import Path
import numpy as np
from law_bench import run
from law_bench.data import load
from law_bench.protocol import make_tasks
root=Path('/data/users/yanrongen/projects/panyushuo/TabAssets-B1-20261111')
payload=root/'payload';cpu=payload/'ReFi-UJI-Core-20261031/results/law_bench_B1_tab_assets_r0_20261111';reference=json.loads((root/'reference_bindings.json').read_text())
pre=json.loads((payload/'ReFi-UJI-Core-20261031/results/law_bench_B1_tab_assets_r0_20261111_source/preflight.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for info in pre['weights'].values():
 p=payload/str(info['path']).split('/home/panyushuo/projects/panyushuo/',1)[1]
 assert sha(p)==info['sha256'],p
csv=payload/'UJIIndoorLoc/data/raw/UJIndoorLoc/trainingData.csv';assert sha(csv)=='45ca0128bd12019c976bb4793e407c979c82995d7a5940ab7288620247905168'
buildings,axes=load('uji',root=csv)
for floor in buildings['B1']:
 for t,truth in make_tasks('uji','B1',buildings['B1'],axes['B1'],floor,budgets=(1,3,5),repeat=0,seed=20261111,R=3,query_positions=60):
  assert truth['row_indices'].tolist()==reference[t.task_id]['query_row_indices'] and truth['groups'].tolist()==reference[t.task_id]['query_groups']
print('Weights, CSV and all 12 original Query row/group bindings verified',flush=True)
import torch
print('runtime',torch.__version__,'GPU',torch.cuda.get_device_name(0),flush=True)
original_write=run._write
variant=sys.argv[1];sys.argv.pop(1)
def write(path,value):
 original_write(path,value)
 if path.name=='freeze.json':
  (path.parent/'device_provenance.json').write_text(json.dumps({'execution_device':'Slurm single RTX4090','CPU_reference':str(cpu),'source_changes':json.loads((root/'source_changes.json').read_text()),'torch':torch.__version__,'CPU_completed_records_reused':variant=='public'},indent=2)+'\n')
  if variant=='public':
   for source in (cpu/'public/events').rglob('*.json'):
    record=json.loads(source.read_text())
    if record['status']=='completed':
     record['device_provenance']={'device':'CPU','reused_from':str(source),'source_sha256':sha(source),'not_rerun_on_GPU':True}
     original_write(path.parent/source.relative_to(cpu/'public'),record)
 if isinstance(value,dict) and value.get('status')=='failed':raise SystemExit('Stopped after preserved failure '+str(path))
run._write=write
signal.signal(signal.SIGINT,signal.default_int_handler)
run.main()
