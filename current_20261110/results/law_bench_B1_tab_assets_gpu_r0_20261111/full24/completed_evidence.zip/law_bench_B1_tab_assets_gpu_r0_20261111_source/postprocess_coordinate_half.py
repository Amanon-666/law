import json,hashlib
from pathlib import Path
import numpy as np
from law_bench.data import load
from law_bench.protocol import make_tasks
from law_bench.score import score,aggregate
root=Path('/data/users/yanrongen/projects/panyushuo/TabAssets-B1-20261111');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();gpfile=root/'retained_GP_saved.json';gp={r['task_id']:r for r in json.loads(gpfile.read_text())['records']}
csv=root/'payload/UJIIndoorLoc/data/raw/UJIndoorLoc/trainingData.csv';buildings,axes=load('uji',root=csv);truths={}
for f in buildings['B1']:
 for t,truth in make_tasks('uji','B1',buildings['B1'],axes['B1'],f,budgets=(1,3,5),repeat=0,seed=20261111,R=3,query_positions=60):truths[t.task_id]=truth
methods={};checks=[]
for variant,name in [('public','tabicl'),('ordinary','tabicl_ordinary'),('full24','tabicl_full24')]:
 source=root/'results'/variant;summary=json.loads((source/(name+'.json')).read_text());rows=[];files=[];method=name+'_GP_coordinate_half'
 for rel in summary['task_records']:
  p=source/rel;r=json.loads(p.read_text());g=gp[r['task_id']];truth=truths[r['task_id']]
  assert r['query_row_indices']==g['query_row_indices']==truth['row_indices'].tolist();assert r['query_groups']==g['query_groups']==truth['groups'].tolist()
  tab=np.asarray(r['prediction']);point_gp=np.asarray(g['prediction']);tb=np.asarray(r['diagnostics']['bounds']);gb=np.asarray(g['bounds']);half=.5*(tab+point_gp)
  assert np.all(tab>=tb[0]-1e-8) and np.all(tab<=tb[1]+1e-8) and np.all(point_gp>=gb[0]-1e-8) and np.all(point_gp<=gb[1]+1e-8)
  assert np.all(half>=tb[0]-1e-8) and np.all(half<=tb[1]+1e-8)
  record={k:r[k] for k in ('task_id','floor','K','repeat','meta','query_row_indices','query_groups')};record.update(status='completed',prediction=half.tolist(),scores=score(half,truth),diagnostics={'formula':'.5*(saved_Tab.projected+saved_retained_GP.projected)','Tab_bounds':tb.tolist(),'GP_bounds':gb.tolist(),'additional_projection':False,'model_calls':0,'Tab_record':str(p),'Tab_sha256':sha(p),'GP_record':g['source_path'],'GP_record_sha256':g['sha256'],'Tab_device':r.get('device_provenance',{'device':'GPU'})})
  dest=root/'results/coordinate_half'/method/(r['task_id']+'.json');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(record,indent=2)+'\n');rows.append(record);files.append(str(dest.relative_to(root/'results')))
  checks.append({'method':method,'task_id':r['task_id'],'same_rows_groups':True,'original_input_bounds_retained':True})
 methods[method]={'overall':aggregate([dict(r,K=0) for r in rows])['0'],'by_K':aggregate(rows),'task_records':files}
result={'complete':True,'tasks_per_method':12,'methods':methods,'checks':checks,'formula':'.5*(Tab.projected+retained_GP.projected)','formula_sources':{str(p):sha(p) for p in (root/'context_influence_objective.py',root/'system_stability.py')},'input_GP_export_sha256':sha(gpfile),'execution_source_sha256':sha(Path(__file__)),'new_model_calls':0,'new_GP_calls':0,'new_training':False,'mechanism_boundary':'Tab+GP uses the pre-existing coordinate half mechanism. A+GP uses its pre-existing log-score probability pool. These are full-system comparisons, not a learner-only controlled substitution.'}
(root/'results/coordinate_half.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({n:{'mean':m['overall']['mean'],'p90':m['overall']['p90'],'by_K':{k:v['mean'] for k,v in m['by_K'].items()}} for n,m in methods.items()},indent=2))
