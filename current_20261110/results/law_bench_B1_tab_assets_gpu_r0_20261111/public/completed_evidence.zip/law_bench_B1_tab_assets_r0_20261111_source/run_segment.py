import signal
from law_bench import run
signal.signal(signal.SIGINT, signal.default_int_handler)
original_write = run._write

def save_and_stop_on_failure(path, value):
    original_write(path, value)
    if isinstance(value, dict) and value.get('status') == 'failed':
        print(f'Stopped after preserved failure: {path}', flush=True)
        raise SystemExit(1)

run._write = save_and_stop_on_failure
run.main()
