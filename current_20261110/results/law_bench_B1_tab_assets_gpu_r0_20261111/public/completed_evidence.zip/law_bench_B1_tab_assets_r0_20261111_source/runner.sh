#!/bin/bash
core=/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031
prep="$core/results/law_bench_B1_tab_assets_r0_20261111_source"
out="$core/results/law_bench_B1_tab_assets_r0_20261111"
mkdir -p "$out"
cd "$prep/source_snapshot" || exit 1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2 CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1
export PYTHONPATH="$prep/source_snapshot:/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages:$core"
export LAW_UJI_CSV=/home/panyushuo/projects/panyushuo/UJIIndoorLoc/data/raw/UJIndoorLoc/trainingData.csv
for pair in public:tabicl ordinary:tabicl_ordinary full24:tabicl_full24; do
 variant=${pair%%:*}
 method=${pair#*:}
 start=$(date +%s)
 echo "start=$(date -u +%FT%TZ) variant=$variant controller_pid=$$"
 timeout --signal=INT --kill-after=60s 900s /home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u "$prep/run_segment.py" --dataset uji --building B1 --source-buildings B0 B2 --budgets 1 3 5 --repeats 0 --R 3 --query-positions 60 --seed 20261111 --methods "$method" --output "$out/$variant" > "$out/$variant.log" 2>&1 &
 child=$!
 echo "timeout_pid=$child variant=$variant"
 wait "$child"
 rc=$?
 end=$(date +%s)
 echo "end=$(date -u +%FT%TZ) variant=$variant elapsed_seconds=$((end-start)) exit_code=$rc"
 /usr/bin/python3 - "$out" "$variant" "$start" "$end" "$rc" "$child" <<'PY'
import json,sys
from pathlib import Path
out=Path(sys.argv[1]);variant=sys.argv[2];start,end,rc,pid=map(int,sys.argv[3:])
(out/(variant+'.exit.json')).write_text(json.dumps(dict(variant=variant,start_epoch=start,end_epoch=end,elapsed_seconds=end-start,exit_code=rc,timeout_pid=pid,limit_seconds=900),indent=2)+'\n')
PY
 if test "$rc" -ne 0; then exit "$rc"; fi
done
