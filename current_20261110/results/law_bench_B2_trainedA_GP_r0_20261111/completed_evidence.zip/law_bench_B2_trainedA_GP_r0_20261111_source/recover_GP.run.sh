#!/usr/bin/env bash
core=/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031
prep="$core/results/law_bench_B2_trainedA_GP_r0_20261111_source"
cd "$prep/source_snapshot" || exit 1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2 CUDA_VISIBLE_DEVICES= PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1
export PYTHONPATH=/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages:$core
export LAW_UJI_CSV=/home/panyushuo/projects/panyushuo/UJIIndoorLoc/data/raw/UJIndoorLoc/trainingData.csv
start=$(date -u +%Y-%m-%dT%H:%M:%SZ)
timeout --signal=TERM --kill-after=5s 1195s /home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u -m law_bench.run --dataset uji --building B2 --source-buildings B0 B1 --budgets 1 3 5 --repeats 0 --R 3 --query-positions 60 --seed 20261111 --methods retained_gp --method-options "$prep/recovery_method_options.json" --output "$core/results/law_bench_B2_retainedGP_recovery_r0_20261111" &
child=$!
printf '{"runner_pid":%s,"timeout_pid":%s,"started_at":"%s","state":"running","outer_timeout_seconds":1200}\n' "$$" "$child" "$start" > "$prep/recovery_runtime.json"
wait "$child"
code=$?
end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
printf '{"runner_pid":%s,"timeout_pid":%s,"started_at":"%s","ended_at":"%s","exit_code":%s,"state":"exited","outer_timeout_seconds":1200}\n' "$$" "$child" "$start" "$end" "$code" > "$prep/recovery_runtime.json"
exit "$code"
