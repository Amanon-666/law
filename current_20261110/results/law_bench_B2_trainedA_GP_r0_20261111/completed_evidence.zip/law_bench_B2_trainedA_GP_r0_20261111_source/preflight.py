import sys,json
from pathlib import Path
import numpy as np
ROOT=Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
PREP=ROOT/'results/law_bench_B2_trainedA_GP_r0_20261111_source'
SNAP=PREP/'source_snapshot';sys.path.insert(0,str(SNAP))
from law_bench.data import load
from law_bench.protocol import make_tasks
from law_bench.run import _data_identity,_method,_sha,_write
from law_bench.method_retained_gp import history_key
read=lambda p:json.loads(p.read_text())
source=Path('/home/panyushuo/projects/panyushuo/claude_fp_wt/current_20261110/src/results/bench_uji_B2_A_20261111')
old=read(ROOT/'results/law_bench_B1_trainedA_GP_r0_20261111/freeze.json')
options=old['configuration']['method_options']
options['trained_A_GP']['source_run']=str(source)
assert options['trained_A_GP']['gp_options']['provenance']['parameters_sha256']=='f14dbededc1fb40630ec1c11a4ae49abd0f1098d01d31987141c99529ef369de'
assert not options['trained_A_GP']['gp_options']['fit_missing_history']
_write(PREP/'method_options.json',options)
source_freeze=read(source/'freeze.json');fit=read(source/'source_models/ours_A.json')
assert fit['status']=='completed' and fit['source_buildings']==['B0','B1']
assert _sha(source/'source_models/ours_A.joblib')==fit['sha256']
for name in ('ours.py','methods_claude.py','data.py','protocol.py'):
 assert _sha(SNAP/'law_bench'/name)==source_freeze['code'][name],name
buildings,aps=load('uji');names=['B0','B1']
identity=_data_identity({b:buildings[b] for b in names},aps)
assert identity==source_freeze['source_data']
model=_method('trained_A_GP',options,ROOT/'results/law_bench_B2_trainedA_GP_r0_20261111')
model.fit_source([dict(dataset='uji',building=b,floors=buildings[b],ap_ids=aps[b]) for b in names])
checks=[];caches={}
for floor in sorted(buildings['B2']):
 for task,truth in make_tasks('uji','B2',buildings['B2'],aps['B2'],floor,budgets=(1,3,5),repeat=0,seed=20261111,R=3,query_positions=60):
  rec=read(source/'events/ours_A'/(task.task_id+'.json'))
  assert rec['status']=='completed' and task.meta==rec['meta']
  assert rec['query_row_indices']==truth['row_indices'].tolist() and rec['query_groups']==truth['groups'].tolist()
  checks.append(dict(task_id=task.task_id,meta=task.meta,query_rows=truth['row_indices'].tolist(),query_groups=truth['groups'].tolist(),source_task_exact=True,
                     S_alignment='Identical frozen protocol code and full(1,3,5) seed stream; S arrays generated once with all budgets'))
  for h,data in task.H.items():
   key=history_key(task,h,model.gp.parameters_sha256)
   if key in caches:continue
   present=np.flatnonzero((data['rss']!=100).any(0))
   for ap in present:
    p=model.gp.cache_dir/key/f'{ap}.npz'
    assert p.is_file() and p.with_suffix('.json').is_file(),p
   caches[key]=dict(floor=h,fields=len(present),cache_path=str(model.gp.cache_dir/key))
assert len(checks)==15 and len(caches)==5
code=[SNAP/'law_bench'/n for n in source_freeze['code'] if (SNAP/'law_bench'/n).is_file()]
code += [ROOT/n for n in ('adaptation.py','fields.py','uji.py','predict.py','posterior.py','sampling.py','observations.py','history_fit.py','position_fusion_gp.py','cached_retained_readout.py','hurdle_gp_pool.py','history_reliability.py','building_information_gp_trial.py','episodic_tasks.py')]
assert _sha(ROOT/'adaptation.py')=='dc6a8a65d427fc573cf19ef0e984dedd6e15316714fb458e8d05d30d4db27fba'
_write(PREP/'preflight.json',dict(complete=True,tasks=checks,source_data=identity,source_run=str(source),source_model_sha256=fit['sha256'],
 code_sha256={str(p):_sha(p) for p in code},source_fit=fit,history_caches=caches,history_fields=sum(c['fields'] for c in caches.values()),
 evaluation_started=False,model_training=0,history_fits=0,method_identity='Generic S-feature ours_A, B0+B1, seeds1-3, original fixed reader plus retained GP half pool',
 original_source_freeze_sha256=_sha(source/'freeze.json')))
print(json.dumps(dict(preflight=True,tasks=len(checks),histories=len(caches),fields=sum(c['fields'] for c in caches.values()))))
