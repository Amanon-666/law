"""B2 same-pass A/GP/fusion scoring and complete generic-variant 39-task table."""
import json,sys
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
ROOT=Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
PREP=ROOT/'results/law_bench_B2_trainedA_GP_r0_20261111_source'
OUT=ROOT/'results/law_bench_B2_trainedA_GP_r0_20261111'
RECOVERY=ROOT/'results/law_bench_B2_retainedGP_recovery_r0_20261111'
B0=ROOT/'results/law_bench_B0_softmax_continuation_20261111'
B1=ROOT/'results/law_bench_B1_trainedA_GP_r0_20261111'
SOURCE=Path('/home/panyushuo/projects/panyushuo/claude_fp_wt/current_20261110/src/results/bench_uji_B2_A_20261111')
sys.path.insert(0,str(PREP/'source_snapshot'))
from law_bench.data import load
from law_bench.protocol import make_tasks
from law_bench.score import score,aggregate
from law_bench.run import _sha,_write
read=lambda p:json.loads(p.read_text())
def compact(r):
 return {k:r[k] for k in ('task_id','floor','K','repeat','status','scores')}
def summarize(records):
 assert all(r['status']=='completed' for r in records)
 errors=[e for r in records for e in r['scores']['position_errors']]
 return dict(tasks=len(records),complete=True,query_positions=len(errors),mean=float(np.mean(errors)),
             p50=float(np.quantile(errors,.5)),p90=float(np.quantile(errors,.9)),by_K=aggregate(records))
buildings,aps=load('uji');b2={name:[] for name in ('A','GP','A_GP')};checks=[]
inputs=[RECOVERY/'freeze.json',OUT/'freeze.json',B0/'complete.json',B0/'combined_task_scores.json',B1/'freeze.json',SOURCE/'freeze.json',SOURCE/'source_models/ours_A.json']
for floor in sorted(buildings['B2']):
 for task,truth in make_tasks('uji','B2',buildings['B2'],aps['B2'],floor,budgets=(1,3,5),repeat=0,seed=20261111,R=3,query_positions=60):
  path=OUT/'events/trained_A_GP'/(task.task_id+'.json');r=read(path)
  source_path=SOURCE/'events/ours_A'/(task.task_id+'.json');prior=read(source_path);inputs.extend([path,source_path])
  gp_path=RECOVERY/'events/retained_gp'/(task.task_id+'.json');gp_record=read(gp_path);inputs.append(gp_path)
  assert gp_record['diagnostics']['state']==r['diagnostics']['GP']['state']
  for record in (r,prior,gp_record):
   assert record['status']=='completed' and record['meta']==task.meta
   assert record['query_row_indices']==truth['row_indices'].tolist() and record['query_groups']==truth['groups'].tolist()
  delta=float(np.max(np.abs(np.asarray(r['diagnostics']['A_projected'])-np.asarray(prior['prediction']))))
  assert delta<=1e-8,(task.task_id,delta)
  for method,pred in [('A',r['diagnostics']['A_projected']),('GP',gp_record['prediction']),('A_GP',r['prediction'])]:
   b2[method].append(dict(task_id=task.task_id,floor=task.floor,K=task.K,repeat=0,status='completed',scores=score(pred,truth)))
  checks.append(dict(task_id=task.task_id,A_max_abs_difference=delta,source_Query_rows_groups_meta_exact=True,seconds=r['seconds']))
assert len(checks)==15
b2summary={name:summarize(records) for name,records in b2.items()}
_write(OUT/'same_output_scores.json',b2)
_write(OUT/'comparison.json',dict(complete=True,methods=b2summary,checks=checks,model_calls_for_rescoring=0,extra_GP_inference_tasks=15,recovery_reason='Original immutable wrapper omitted GP_projected; original A/fusion retained, only native retained GP repeated with exact same recorded S state',identity='Generic S-feature ours_A B0+B1 three models with fixed retained-GP half pool'))
b0=read(B0/'combined_task_scores.json');b1={name:[] for name in ('A','GP','A_GP')}
b1paths=sorted((B1/'events/trained_A_GP').rglob('*.json'));inputs.extend(b1paths)
for path in b1paths:
 r=read(path);task_id=r['task_id']
 gp_path=ROOT/'results/law_bench_B1_frozen_r0_20261111/events/retained_gp'/(task_id+'.json')
 gr=read(gp_path);inputs.append(gp_path)
 assert gr['query_row_indices']==r['query_row_indices'] and gr['query_groups']==r['query_groups'] and gr['meta']==r['meta']
 b1truth=dict(xy=buildings['B1'][r['floor']]['xy'][r['query_row_indices']],groups=np.asarray(r['query_groups']))
 a_record=compact(r);a_record['scores']=score(r['diagnostics']['A_projected'],b1truth)
 b1['A'].append(a_record);b1['GP'].append(compact(gr));b1['A_GP'].append(compact(r))
bybuilding={'B0':b0,'B1':b1,'B2':b2};combined={name:[] for name in b2}
for building,methods in bybuilding.items():
 for method in combined:
  rs=methods[method];assert len(rs)==(15 if building=='B2' else 12)
  combined[method].extend(dict(compact(r),building=building) for r in rs)
summary={};building_summary={}
for building,methods in bybuilding.items():
 building_summary[building]={name:summarize(methods[name]) for name in combined}
for method,records in combined.items():
 assert len(records)==39 and len({r['task_id'] for r in records})==39
 summary[method]=dict(pooled_positions=summarize(records),
  equal_building_mean=float(np.mean([building_summary[b][method]['mean'] for b in bybuilding])),
  equal_building_by_K={str(k):float(np.mean([building_summary[b][method]['by_K'][str(k)]['mean'] for b in bybuilding])) for k in (1,3,5)})
_write(OUT/'combined39_scores.json',combined)
_write(OUT/'combined39_comparison.json',dict(complete=True,created=datetime.now(timezone.utc).isoformat(),tasks=39,
 methods=summary,by_building=building_summary,aggregation='Stored per-position pooled scores and equal mean of the three full building results, including equal-building per-K means',
 identity='Generic S-feature ours_A three-model variant, with unchanged retained GP and fixed 1:1 log-score pool. B0 sources B1+B2; B1 sources B0+B2; B2 sources B0+B1.',
 boundary='B0 reader hyperparameters historically selected on B0 development; all are exposed development. B0 one same-objective numerical continuation repair is explicit. No original54 or original-A02 results included.',
 repaired_task='uji/B0/F0/K3/r0',inputs_sha256={str(p):_sha(p) for p in inputs},code_sha256=_sha(__file__),new_models=0,new_history_fits=0))
_write(OUT/'complete.json',dict(complete=True,tasks=15,combined_tasks=39,freeze_sha256=_sha(OUT/'freeze.json'),comparison_sha256=_sha(OUT/'comparison.json'),combined39_sha256=_sha(OUT/'combined39_comparison.json'),
 max_A_difference=max(c['A_max_abs_difference'] for c in checks),model_training=0,history_fits=0,extra_GP_inference_tasks=15,total_GP_inference_tasks=30,A_inference_tasks=15))
print(json.dumps(dict(complete=True,B2={k:{n:v[n] for n in ('mean','p90')} for k,v in b2summary.items()},
 equal_building_mean={k:v['equal_building_mean'] for k,v in summary.items()},max_A_difference=max(c['A_max_abs_difference'] for c in checks))),flush=True)
