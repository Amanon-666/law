"""Same saved-output scoring for the completed B1 comparison; no model calls."""
import json,sys,hashlib
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
ROOT=Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
PREP=ROOT/'results/law_bench_B1_originalA02_GP_r0_20261111_source'
OUT=ROOT/'results/law_bench_B1_originalA02_GP_r0_20261111'
OLD=ROOT/'results/law_bench_B1_frozen_r0_20261111'
VAR=ROOT/'results/law_bench_B1_trainedA_GP_r0_20261111'
sys.path.insert(0,str(PREP/'source_snapshot'))
from law_bench.data import load
from law_bench.protocol import make_tasks
from law_bench.score import score,aggregate
from law_bench.run import _write,_sha
read=lambda p:json.loads(p.read_text())
records={name:[] for name in ('original_B0_A5','original_B0_A5_GP','original_B02_A5','original_B02_A5_GP','generic_B02_A3','generic_B02_A3_GP','retained_GP')}
inputs=[OUT/'freeze.json',OLD/'freeze.json',VAR/'freeze.json',PREP/'preflight.json']
checks=[];data,aps=load('uji')
for floor in sorted(data['B1']):
 for task,truth in make_tasks('uji','B1',data['B1'],aps['B1'],floor,budgets=(1,3,5),repeat=0,seed=20261111,R=3,query_positions=60):
  paths=[OUT/'events/original_A_GP'/(task.task_id+'.json'),OLD/'events/adopted_A_GP'/(task.task_id+'.json'),VAR/'events/trained_A_GP'/(task.task_id+'.json'),OLD/'events/retained_gp'/(task.task_id+'.json')]
  inputs.extend(paths)
  new,old,var,gp=(read(p) for p in paths)
  old_a_path=OLD/'events/adopted_A'/(task.task_id+'.json')
  old_a=read(old_a_path);inputs.append(old_a_path)
  for r in (new,old,var,gp,old_a):
   assert r['status']=='completed' and r['meta']==task.meta
   assert r['query_row_indices']==truth['row_indices'].tolist() and r['query_groups']==truth['groups'].tolist()
  gp_delta=float(np.max(np.abs(np.asarray(new['diagnostics']['GP_projected'])-np.asarray(gp['prediction']))))
  assert gp_delta<=1e-8,(task.task_id,gp_delta)
  values={'original_B0_A5':old_a['prediction'],'original_B0_A5_GP':old['prediction'],
   'original_B02_A5':new['diagnostics']['A_projected'],'original_B02_A5_GP':new['prediction'],
   'generic_B02_A3':var['diagnostics']['A_projected'],'generic_B02_A3_GP':var['prediction'],
   'retained_GP':gp['prediction']}
  for method,prediction in values.items():
   records[method].append(dict(task_id=task.task_id,floor=task.floor,K=task.K,repeat=0,status='completed',scores=score(prediction,truth)))
  checks.append(dict(task_id=task.task_id,GP_projected_max_abs_difference=gp_delta,Query_rows_groups_exact=True))
summary={}
for name,rs in records.items():
 errors=[e for r in rs for e in r['scores']['position_errors']]
 summary[name]=dict(tasks=len(rs),mean=float(np.mean(errors)),p50=float(np.quantile(errors,.5)),p90=float(np.quantile(errors,.9)),by_K=aggregate(rs))
_write(OUT/'same_output_scores.json',records)
_write(OUT/'comparison.json',dict(complete=True,created=datetime.now(timezone.utc).isoformat(),methods=summary,checks=checks,
 identities={'original_B0_A5':'Original HurdleField B0, seeds1-5, draws4',
 'original_B02_A5':'Original HurdleField B0+B2, seeds1-5, draws4',
 'generic_B02_A3':'Existing generic S-feature ours_A B0+B2, default seeds1-3; modified recipe, not original HurdleField'},
 evaluation_status='Same previously exposed B1 tasks; source and recipe comparison',
 input_sha256={str(p):_sha(p) for p in inputs},code_sha256=_sha(__file__),new_model_calls_for_scoring=0))
_write(OUT/'complete.json',dict(complete=True,tasks=12,freeze_sha256=_sha(OUT/'freeze.json'),comparison_sha256=_sha(OUT/'comparison.json'),
 max_GP_projected_difference=max(c['GP_projected_max_abs_difference'] for c in checks),model_training=0,history_fits=0))
print(json.dumps(dict(complete=True,methods={k:{j:v[j] for j in ('tasks','mean','p90')} for k,v in summary.items()},GP_max_difference=max(c['GP_projected_max_abs_difference'] for c in checks))),flush=True)
