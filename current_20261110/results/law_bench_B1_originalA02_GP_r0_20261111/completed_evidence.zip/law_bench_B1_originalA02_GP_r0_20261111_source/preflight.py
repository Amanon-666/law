import sys,json,hashlib
from pathlib import Path
root=Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
prep=root/'results/law_bench_B1_originalA02_GP_r0_20261111_source'
snapshot=prep/'source_snapshot';sys.path.insert(0,str(snapshot))
from law_bench.data import load
from law_bench.protocol import make_tasks
from law_bench.run import _data_identity
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=root/'results/law_bench_B1_frozen_r0_20261111'
generic=root/'results/law_bench_B1_trainedA_GP_r0_20261111'
assets=root/'results/claude_hurdle_sources02_ens5_20261111'
f=read(old/'freeze.json');g=read(generic/'freeze.json')
gp=f['configuration']['method_options']['adopted_A_GP']['gp_options']
assert gp==f['configuration']['method_options']['retained_gp'] and not gp['fit_missing_history']
assert sha(root/'adaptation.py')=='dc6a8a65d427fc573cf19ef0e984dedd6e15316714fb458e8d05d30d4db27fba'
options=dict(original_A_GP=dict(generation_dir=str(assets),freeze_sha256=read(assets/'complete.json')['freeze_sha256'],gp_options=gp))
(prep/'method_options.json').write_text(json.dumps(options,indent=2)+'\n')
b,aps=load('uji');ident=_data_identity({n:b[n] for n in ('B0','B2')},aps)
assert ident==f['source_data']==g['source_data']
checks=[]
for floor in sorted(b['B1']):
 for task,truth in make_tasks('uji','B1',b['B1'],aps['B1'],floor,budgets=(1,3,5),repeat=0,seed=20261111,R=3,query_positions=60):
  for run,method in [(old,'adopted_A_GP'),(old,'retained_gp'),(generic,'trained_A_GP')]:
   rec=read(run/'events'/method/(task.task_id+'.json'))
   assert rec['status']=='completed' and task.meta==rec['meta']
   assert truth['row_indices'].tolist()==rec['query_row_indices'] and truth['groups'].tolist()==rec['query_groups']
  checks.append(dict(task_id=task.task_id,original_and_variant_Query_rows_groups_meta_exact=True))
paths=[snapshot/'law_bench/method_adopted.py',snapshot/'law_bench/run.py',snapshot/'frozen_hurdle_translator.py',root/'adaptation.py',old/'freeze.json',generic/'freeze.json',assets/'complete.json',assets/'freeze.json',assets/'deployment_check.json',Path(gp['parameters_path'])]
(prep/'preflight.json').write_text(json.dumps(dict(complete=True,source_data=ident,tasks=checks,gp_options_exact=True,
 actual_GP_adaptation=str(root/'adaptation.py'),parent_reported_commit='8d5c7e8b9aeccb295161fb0b9bd8149c1171c67f',
 source_sha256={str(p):sha(p) for p in paths},training=0,history_fits=0,evaluation_started=False),indent=2)+'\n')
print('preflight complete tasks',len(checks))
