import sys,json,hashlib
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent.parent
OLD=OUT.parent/'law_bench_B0_trainedA_GP_r0_20261111'
sys.path.insert(0,str(OUT/'source_snapshot'))
from law_bench.data import load
from law_bench.score import score,aggregate
from law_bench.run import _write,_sha
read=lambda p:json.loads(p.read_text())
a=read(OUT/'alignment.json'); pred=read(OUT/'predictions.json'); trace=read(OUT/'continuation_trace.json')
buildings,_=load('uji');truth=dict(xy=buildings['B0'][0]['xy'][a['query_row_indices']],groups=np.asarray(a['query_groups']))
event=read(OUT/'event.json');task=event['task_id']
assert trace['final']['stationary'] and trace['A_projected_max_abs_difference']==0
methods=read(OLD/'same_output_scores.json')
methods={k:v for k,v in methods.items() if isinstance(v,list)}
methods['A_GP']=[read(p) for p in sorted((OLD/'events/trained_A_GP').rglob('*.json'))]
for method,key in [('A','A_projected'),('GP','GP_projected'),('A_GP','fused_projected')]:
 replacement=dict(task_id=task,floor=0,K=3,repeat=0,meta=event['meta'],status='completed',scores=score(pred[key],truth))
 records=[replacement if r['task_id']==task else r for r in methods[method]]
 assert len(records)==12 and all(r['status']=='completed' for r in records)
 methods[method]=records
summary={}
for method,records in methods.items():
 errors=[e for r in records for e in r['scores']['position_errors']]
 summary[method]=dict(tasks=12,complete=True,mean=float(np.mean(errors)),p50=float(np.quantile(errors,.5)),p90=float(np.quantile(errors,.9)),by_K=aggregate(records))
event.update(status='completed',postprocess_recovery='Saved predictions only; aggregation KeyError preserved in postprocess_failure_event.json; no new model call')
event.pop('error',None)
_write(OUT/'event.json',event)
_write(OUT/'combined_task_scores.json',methods)
_write(OUT/'comparison.json',dict(complete=True,repaired_event=task,retained_old_successes=11,methods=summary,
 algorithm='Original solver plus same-objective bounded simplex continuation',old_comparison_sha256=_sha(OLD/'comparison.json'),evaluation_status='exposed_development'))
freeze=read(OUT/'freeze.json')
for p,sha in freeze['inputs_sha256'].items():assert _sha(p)==sha,p
_write(OUT/'complete.json',dict(complete=True,final=trace['final'],freeze_sha256=_sha(OUT/'freeze.json'),
 event_sha256=_sha(OUT/'event.json'),comparison_sha256=_sha(OUT/'comparison.json'),
 original_four_trial_max_abs_differences=trace['original_four_trial_max_abs_differences'],A_projected_max_abs_difference=0.,
 history_fits=0,model_training=0,numerical_task_executions=1,postprocess_recovered=True,finalize_code_sha256=_sha(__file__)))
print(json.dumps(dict(complete=True,methods=summary)))
