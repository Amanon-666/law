"""One recorded B0 failure, using same-loss simplex continuation."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import time
from datetime import datetime, timezone
from unittest.mock import patch

import numpy as np
import torch

SNAPSHOT = Path(__file__).resolve().parent
OUT = SNAPSHOT.parent
CORE = Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
OLD = CORE/'results/law_bench_B0_trainedA_GP_r0_20261111'
TASK_ID = 'uji/B0/F0/K3/r0'
sys.path.insert(0, str(SNAPSHOT))
import adaptation
assert Path(adaptation.__file__).resolve() == SNAPSHOT/'adaptation.py'
from law_bench import protocol
from law_bench.data import load
from law_bench.run import _data_identity, _method, _write, _sha
from law_bench.score import score, aggregate


def read(path):
    return json.loads(Path(path).read_text())


def run():
    started = time.monotonic()
    old_freeze = read(OLD/'freeze.json')
    config = old_freeze['configuration']
    old_path = OLD/'events/trained_A_GP'/f'{TASK_ID}.json'
    original = read(old_path)
    source_run = Path(config['method_options']['trained_A_GP']['source_run'])
    source_record = read(source_run/'events/ours_A'/f'{TASK_ID}.json')
    assert config['budgets'] == [1, 3, 5] and config['R'] == 3
    for name, expected in old_freeze['code'].items():
        assert _sha(SNAPSHOT/'law_bench'/name) == expected, name
    buildings, aps = load('uji', root=config['root'])
    source_names = config['source_buildings']
    source_data = _data_identity({b: buildings[b] for b in source_names}, aps)
    target_data = _data_identity({'B0': buildings['B0']}, {'B0': aps['B0']})
    assert source_data == old_freeze['source_data']
    assert target_data == old_freeze['target_data']
    draws = []
    original_rows = protocol._rows
    def captured_rows(*args, **kwargs):
        result = original_rows(*args, **kwargs)
        draws.append(result[0].copy())
        return result
    with patch.object(protocol, '_rows', captured_rows):
        tasks = protocol.make_tasks('uji', 'B0', buildings['B0'], aps['B0'], 0,
            budgets=(1, 3, 5), repeat=0, seed=20261111, R=3, query_positions=60)
    task, truth = next(pair for pair in tasks if pair[0].task_id == TASK_ID)
    assert task.meta == original['meta'] == source_record['meta']
    assert truth['row_indices'].tolist() == source_record['query_row_indices']
    assert truth['groups'].tolist() == source_record['query_groups']
    support_rows = draws[0][:sum(task.meta['support_scans_per_position'])]
    assert np.array_equal(draws[1], truth['row_indices'])
    for name in ('rss', 'xy', 'acq'):
        assert np.array_equal(task.S[name], buildings['B0'][0][name][support_rows])
    assert np.array_equal(task.Q_rss, buildings['B0'][0]['rss'][draws[1]])
    alignment = dict(task_id=TASK_ID, meta=task.meta, source_data=source_data,
        support_row_indices=support_rows.tolist(), query_row_indices=truth['row_indices'].tolist(),
        query_groups=truth['groups'].tolist(),
        support_csv_rows=buildings['B0'][0]['row_ids'][support_rows].tolist(),
        query_csv_rows=buildings['B0'][0]['row_ids'][truth['row_indices']].tolist(),
        support_alignment='Reconstructed from the identical original protocol code/config/full budget RNG stream; original failed record stores meta but no S row IDs',
        query_rows_groups_meta_source_data_exact=True)
    _write(OUT/'alignment.json', alignment)
    sources = [dict(dataset='uji', building=b, floors=buildings[b], ap_ids=aps[b]) for b in source_names]
    model = _method('trained_A_GP', config['method_options'], OUT)
    model.fit_source(sources)
    # Preload the original deferred GP modules with adaptation already bound.
    import predict, position_fusion_gp, cached_retained_readout
    assert predict.fit_episode is adaptation.fit_episode
    assert Path(adaptation.__file__).resolve() == SNAPSHOT/'adaptation.py'
    loaded = {str(Path(m.__file__).resolve()): _sha(Path(m.__file__))
              for m in list(sys.modules.values()) if getattr(m, '__file__', None)
              and Path(m.__file__).is_file()
              and str(Path(m.__file__).resolve()).startswith(str(CORE))
              and str(m.__file__).endswith('.py')}
    frozen_inputs = [OLD/'freeze.json', old_path, source_run/'freeze.json',
        source_run/'source_models/ours_A.joblib', source_run/'source_models/ours_A.json',
        OLD/'same_output_scores.json', OLD/'comparison.json']
    old_records = sorted((OLD/'events/trained_A_GP').rglob('*.json'))
    frozen_inputs += old_records
    freeze = dict(created=datetime.now(timezone.utc).isoformat(), task_id=TASK_ID,
        parent_reported_commit='29ec1a8872b6705f3cd1e6d3f182986c7b226745',
        actual_adaptation_import=adaptation.__file__, adaptation_sha256=_sha(SNAPSHOT/'adaptation.py'),
        driver_sha256=_sha(__file__), loaded_code_sha256=loaded,
        inputs_sha256={str(p): _sha(p) for p in frozen_inputs}, original_configuration=config,
        alignment_sha256=_sha(OUT/'alignment.json'), source_data=source_data,
        recipe='Original four starts and thresholds; bounded simplex mass transfer only after all original starts fail direct KKT with converged variational gradient',
        A_identity='Saved generic S-feature ours_A variant, not original five-seed HurdleField',
        resources=dict(CPU_threads=2, nice=10, GPU=0, downloads=0),
        history_fits=0, model_training=0, target_Q_used_for_adaptation=False)
    _write(OUT/'freeze.json', freeze)
    record = dict(task_id=TASK_ID, floor=0, K=3, repeat=0, meta=task.meta,
                  status='failed', query_row_indices=truth['row_indices'].tolist(),
                  query_groups=truth['groups'].tolist())
    try:
        prediction = model.predict(task)
        diagnostics = model.diagnostics
        current_trials = diagnostics['GP']['state']['trials']
        old_error = original['diagnostics']['GP']['error']
        old_trials = ast.literal_eval(old_error[old_error.index('[{'):old_error.rindex(']')+1])
        assert len(old_trials) == 4 and len(current_trials) > 4
        trial_differences = {}
        for key in ('objective', 'simplex_kkt_residual', 'variational_gradient', 'weights'):
            delta = max(float(np.max(np.abs(np.asarray(a[key])-np.asarray(b[key]))))
                        for a, b in zip(old_trials, current_trials[:4]))
            trial_differences[key] = delta
            assert delta < 1e-8, (key, delta)
        final = min((t for t in current_trials if t['stationary']), key=lambda t:t['objective'])
        assert final['simplex_kkt_residual'] < 1e-3 and final['variational_gradient'] < 1e-3
        assert final['objective'] <= min(t['objective'] for t in old_trials)
        a_error = float(np.max(np.abs(np.asarray(diagnostics['A_projected'])-
                                      np.asarray(original['diagnostics']['A_projected']))))
        assert a_error == 0.
        _write(OUT/'continuation_trace.json', dict(trials=current_trials, final=final,
            original_four_trial_max_abs_differences=trial_differences,
            A_projected_max_abs_difference=a_error, before_scoring=True))
        # All predictions and the acceptance checks precede truth-based scoring.
        _write(OUT/'predictions.json', dict(A_projected=diagnostics['A_projected'],
            GP_projected=diagnostics['GP_projected'], fused_projected=prediction))
        record.update(status='completed', prediction=prediction, diagnostics=diagnostics,
                      scores=score(prediction, truth), seconds=time.monotonic()-started)
        _write(OUT/'event.json', record)
        saved = read(OLD/'same_output_scores.json')
        for method, value in [('A', diagnostics['A_projected']), ('GP', diagnostics['GP_projected']),
                              ('A_GP', prediction)]:
            replacement = dict(task_id=TASK_ID, floor=0, K=3, repeat=0, meta=task.meta,
                               status='completed', scores=score(value, truth),
                               provenance='Same-task continuation repair, new algorithm version')
            records = [replacement if r['task_id']==TASK_ID else r for r in saved[method]]
            assert len(records)==12 and all(r['status']=='completed' for r in records)
            saved[method] = records
        summary = {}
        for method, records in saved.items():
            errors = [e for r in records for e in r['scores']['position_errors']]
            summary[method] = dict(tasks=12, mean=float(np.mean(errors)),
                p50=float(np.quantile(errors,.5)), p90=float(np.quantile(errors,.9)), by_K=aggregate(records))
        _write(OUT/'combined_task_scores.json', saved)
        _write(OUT/'comparison.json', dict(complete=True, repaired_event=TASK_ID,
            retained_old_successes=11, algorithm='original solver plus bounded same-objective simplex continuation',
            old_comparison_sha256=_sha(OLD/'comparison.json'), methods=summary,
            old_failed_record_preserved=str(old_path), evaluation_status='exposed_development'))
        for path, expected in freeze['inputs_sha256'].items():
            assert _sha(path) == expected, path
        _write(OUT/'complete.json', dict(complete=True, seconds=time.monotonic()-started,
            freeze_sha256=_sha(OUT/'freeze.json'), event_sha256=_sha(OUT/'event.json'),
            comparison_sha256=_sha(OUT/'comparison.json'), final=final,
            original_four_trial_max_abs_differences=trial_differences,
            A_projected_max_abs_difference=a_error, history_fits=0, model_training=0))
        print(json.dumps(dict(complete=True, seconds=time.monotonic()-started, final=final,
                              methods=summary)), flush=True)
    except Exception as error:
        record.update(error=repr(error), diagnostics=model.diagnostics, seconds=time.monotonic()-started)
        _write(OUT/'event.json', record)
        raise


if __name__ == '__main__':
    torch.set_num_threads(2)
    run()
