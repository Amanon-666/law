#!/usr/bin/env bash
out=/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/law_bench_B0_softmax_continuation_20261111
core=/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031
cd "$out/source_snapshot" || exit 1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2 CUDA_VISIBLE_DEVICES= PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1
export PYTHONPATH=/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages:$core
export LAW_UJI_CSV=/home/panyushuo/projects/panyushuo/UJIIndoorLoc/data/raw/UJIndoorLoc/trainingData.csv
export VT_DIR="$core/claude_hurdle_20261110"
start=$(date -u +%Y-%m-%dT%H:%M:%SZ)
timeout --signal=TERM --kill-after=5s 895s nice -n 10 /home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u "$out/source_snapshot/retry_task.py" &
child=$!
printf '{"runner_pid":%s,"timeout_pid":%s,"started_at":"%s","state":"running","outer_timeout_seconds":900}\n' "$$" "$child" "$start" > "$out/runtime.json"
wait "$child"
code=$?
end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
printf '{"runner_pid":%s,"timeout_pid":%s,"started_at":"%s","ended_at":"%s","exit_code":%s,"state":"exited","outer_timeout_seconds":900}\n' "$$" "$child" "$start" "$end" "$code" > "$out/runtime.json"
exit "$code"
