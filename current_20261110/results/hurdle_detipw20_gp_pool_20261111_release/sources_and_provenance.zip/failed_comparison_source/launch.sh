#!/bin/bash
cd /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031
export PYTHONPATH=/home/panyushuo/projects/panyushuo/DKT-UJI/env/lib/python3.12/site-packages:/home/panyushuo/projects/panyushuo/LAW-source-resume-20261025-01a164d0/python_dependencies:/home/panyushuo/projects/panyushuo/multifloor-check-20261026/env/lib/python3.12/site-packages
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2
export CUDA_VISIBLE_DEVICES="" PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
nice -n 10 timeout 900 /home/panyushuo/projects/panyushuo/DKT-UJI/env/bin/python -u /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/hurdle_gp_pool_trial.py --models /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/claude_hurdle_b0_detipw20_ens5_20261111 --baseline /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/hurdle_gp_pool_20261110/complete.json --output /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/hurdle_detipw20_gp_pool_20261111 --seconds 840
run_rc=$?
printf "%s\n" "$run_rc" > /home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031/results/hurdle_detipw20_gp_pool_20261111_source/exit.status
exit "$run_rc"
