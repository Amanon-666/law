"""Copy saved prediction/error fields into auditable release zips; no inference/scoring."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
import numpy as np

ROOT = Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
RELEASE = ROOT/'results/hurdle_detipw20_gp_pool_20261111_release'
METHODS = ('hurdle','GP','GP_candidates','coordinate_half','probability_half')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

def archive(folder, destination):
    with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(folder).as_posix())

RELEASE.mkdir(exist_ok=False)
compact = RELEASE/'compact_results';compact.mkdir()
manifest = dict(created=datetime.now(timezone.utc).isoformat(),purpose='Copy existing arrays for independent review of all original54 localization statistics',
    predictions_recomputed=False,errors_recomputed=False,methods=METHODS,
    fields=dict(truth='scored:truth',query_rows='prediction:query_rows',aps='prediction:aps',
        **{f'prediction_{m}':f'prediction:{m}' for m in METHODS},
        **{f'error_{m}':f'scored:{m}' for m in METHODS}),sets={})
for label, directory in [('baseline',ROOT/'results/hurdle_gp_pool_20261110'),('detection_ipw20',ROOT/'results/hurdle_detipw20_gp_pool_20261111_readerfix')]:
    complete_path=directory/'complete.json';freeze_path=directory/'freeze.json'
    complete=json.loads(complete_path.read_text())
    assert complete['complete'] and len(complete['records'])==54
    assert sha(freeze_path)==complete['freeze_sha256']
    target=compact/label;target.mkdir()
    shutil.copy2(complete_path,target/'complete.json');shutil.copy2(freeze_path,target/'freeze.json')
    records=[]
    for record in complete['records']:
        prediction_path=ROOT/record['prediction_path'];scored_path=ROOT/record['scored_path']
        assert sha(prediction_path)==record['prediction_sha256']
        assert sha(scored_path)==record['scored_sha256']
        with np.load(prediction_path,allow_pickle=False) as prediction, np.load(scored_path,allow_pickle=False) as scored:
            arrays=dict(truth=scored['truth'],query_rows=prediction['query_rows'],aps=prediction['aps'])
            arrays.update({f'prediction_{m}':prediction[m] for m in METHODS})
            arrays.update({f'error_{m}':scored[m] for m in METHODS})
        path=target/(record['event']+'.npz');np.savez_compressed(path,**arrays)
        records.append(dict(event=record['event'],floor=record['floor'],K=record['K'],
            original_prediction=dict(path=str(prediction_path),sha256=record['prediction_sha256']),
            original_scored=dict(path=str(scored_path),sha256=record['scored_sha256']),
            compact_path=path.relative_to(compact).as_posix(),compact_sha256=sha(path),bytes=path.stat().st_size,
            retained_fields={name:dict(shape=list(value.shape),dtype=str(value.dtype)) for name,value in arrays.items()}))
    manifest['sets'][label]=dict(complete_sha256=sha(complete_path),freeze_sha256=sha(freeze_path),records=records)
protocol=ROOT/'results/building_information_assets_20261109/manifest.json'
shutil.copy2(protocol,compact/'protocol_manifest.json');manifest['protocol_manifest_sha256']=sha(protocol)
write(compact/'manifest.json',manifest)
compact_zip=RELEASE/'compact_results.zip';archive(compact,compact_zip)

sources=RELEASE/'sources_and_provenance';sources.mkdir()
source_records=[]
groups=[('candidate_generation_source',ROOT/'results/claude_hurdle_b0_detipw20_ens5_20261111_source'),
        ('failed_comparison_source',ROOT/'results/hurdle_detipw20_gp_pool_20261111_source'),
        ('readerfix_comparison_source',ROOT/'results/hurdle_detipw20_gp_pool_20261111_readerfix_source')]
for label,directory in groups:
    for original in sorted(directory.rglob('*')):
        if not original.is_file() or '__pycache__' in original.parts or original.suffix in ('.joblib','.npz','.pyc'):continue
        path=sources/label/original.relative_to(directory);path.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(original,path)
        source_records.append(dict(path=path.relative_to(sources).as_posix(),original_path=str(original),sha256=sha(original),bytes=original.stat().st_size))
for label,directory,names in [
    ('candidate_metadata',ROOT/'results/claude_hurdle_b0_detipw20_ens5_20261111',('freeze.json','complete.json','inheritance_check.json','progress.json')),
    ('readerfix_comparison_metadata',ROOT/'results/hurdle_detipw20_gp_pool_20261111_readerfix',('freeze.json','complete.json')),
    ('failed_comparison_metadata',ROOT/'results/hurdle_detipw20_gp_pool_20261111',('freeze.json',))]:
    for name in names:
        original=directory/name;path=sources/label/name;path.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(original,path)
        source_records.append(dict(path=path.relative_to(sources).as_posix(),original_path=str(original),sha256=sha(original),bytes=original.stat().st_size))
write(sources/'manifest.json',dict(created=datetime.now(timezone.utc).isoformat(),files=source_records,model_files_included=False,full_probability_matrices_included=False))
source_zip=RELEASE/'sources_and_provenance.zip';archive(sources,source_zip)
index=dict(created=datetime.now(timezone.utc).isoformat(),complete=True,
    compact_contexts=dict(baseline=54,detection_ipw20=54),packages=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in (compact_zip,source_zip)],
    compact_manifest_sha256=sha(compact/'manifest.json'),source_manifest_sha256=sha(sources/'manifest.json'),
    comparison_complete=dict(path=str(ROOT/'results/hurdle_detipw20_gp_pool_20261111_readerfix/complete.json'),sha256=sha(ROOT/'results/hurdle_detipw20_gp_pool_20261111_readerfix/complete.json')),
    comparison_freeze=dict(path=str(ROOT/'results/hurdle_detipw20_gp_pool_20261111_readerfix/freeze.json'),sha256=sha(ROOT/'results/hurdle_detipw20_gp_pool_20261111_readerfix/freeze.json')))
write(RELEASE/'release.json',index)
print(json.dumps(index,indent=2))
