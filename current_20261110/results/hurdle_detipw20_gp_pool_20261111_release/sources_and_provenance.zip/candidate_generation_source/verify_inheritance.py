from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import joblib
import numpy as np

root = Path('/home/panyushuo/projects/panyushuo/ReFi-UJI-Core-20261031')
source = root/'results/claude_hurdle_b0_detipw20_ens5_20261111_source'
sys.path.insert(0, str(source/'source_snapshot'))
from frozen_hurdle_translator import FrozenHurdleTranslator
base_path = root/'results/claude_hurdle_b0_ens5_20261110'
new_path = root/'results/claude_hurdle_b0_detipw20_ens5_20261111'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
result = dict(passed=False, created=datetime.now(timezone.utc).isoformat(),
    base_freeze_sha256=sha(base_path/'freeze.json'),new_freeze_sha256=sha(new_path/'freeze.json'),
    checked_seeds=[],reader_loaded=False,seeds=[],prediction_calls=0,
    verification_code_sha256=sha(Path(__file__)))
try:
    original = FrozenHurdleTranslator(base_path)
    candidate = FrozenHurdleTranslator(new_path)
    result['reader_loaded'] = True
    for old, new in zip(original.models, candidate.models):
        assert old['seed'] == new['seed']
        hashes = {name: dict(base=joblib.hash(old[name]),new=joblib.hash(new[name]))
                  for name in ('mean','scale')}
        row = dict(seed=old['seed'],
            mean_state_equal=hashes['mean']['base']==hashes['mean']['new'],
            scale_state_equal=hashes['scale']['base']==hashes['scale']['new'],
            model_cols_equal=bool(np.array_equal(old['cols'],new['cols'])),
            det_cols_equal=bool(np.array_equal(old['det']['cols'],new['det']['cols'])),
            det_parameters_equal=old['det']['estimator'].get_params()==new['det']['estimator'].get_params(),
            state_hashes=hashes)
        result['seeds'].append(row)
        result['checked_seeds'].append(old['seed'])
    fields=('mean_state_equal','scale_state_equal','model_cols_equal','det_cols_equal','det_parameters_equal')
    result['passed'] = result['reader_loaded'] and result['checked_seeds']==[1,2,3,4,5] and all(
        row[name] for row in result['seeds'] for name in fields)
finally:
    (new_path/'inheritance_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert result['passed']
